
  # Student Panel UI/UX Design

  This is a code bundle for Student Panel UI/UX Design. The original project is available at https://www.figma.com/design/ORMVxhkdBZMzsCSoONfi9k/Student-Panel-UI-UX-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  