import { useState } from "react";
import { ThemeProvider } from "./components/ThemeProvider";
import { TopBar } from "./components/TopBar";
import { Sidebar } from "./components/Sidebar";
import { BottomNav } from "./components/BottomNav";
import { RightPanel } from "./components/RightPanel";
import { Dashboard } from "./components/screens/Dashboard";
import { MyClasses } from "./components/screens/MyClasses";
import { Homework } from "./components/screens/Homework";
import { Routine } from "./components/screens/Routine";
import { Attendance } from "./components/screens/Attendance";
import { Exams } from "./components/screens/Exams";
import { Results } from "./components/screens/Results";
import { MoreMenu } from "./components/screens/MoreMenu";
import { PlaceholderScreen } from "./components/screens/PlaceholderScreen";
import { Toaster } from "./components/ui/sonner";
import { 
  Award, 
  MessageCircle, 
  FolderOpen, 
  CalendarDays, 
  HelpCircle 
} from "lucide-react";
import { Sheet, SheetContent, SheetTitle } from "./components/ui/sheet";

function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <Dashboard onNavigate={setActiveTab} />;
      case "classes":
        return <MyClasses />;
      case "homework":
        return <Homework />;
      case "routine":
        return <Routine />;
      case "attendance":
        return <Attendance />;
      case "exams":
        return <Exams />;
      case "results":
        return <Results />;
      case "more":
        return <MoreMenu onNavigate={setActiveTab} />;
      case "achievements":
        return (
          <PlaceholderScreen
            title="Achievements"
            description="Your badges, awards, and milestones"
            icon={Award}
            message="Your achievements will appear here"
          />
        );
      case "communication":
        return (
          <PlaceholderScreen
            title="Communication"
            description="Messages, chats, and announcements"
            icon={MessageCircle}
            message="Your messages and communications will appear here"
          />
        );
      case "resources":
        return (
          <PlaceholderScreen
            title="Resources"
            description="Study materials and learning resources"
            icon={FolderOpen}
            message="Learning resources will appear here"
          />
        );
      case "planner":
        return (
          <PlaceholderScreen
            title="Planner"
            description="Plan your study schedule and tasks"
            icon={CalendarDays}
            message="Your study planner will appear here"
          />
        );
      case "help":
        return (
          <PlaceholderScreen
            title="Help & Support"
            description="Get assistance and support"
            icon={HelpCircle}
            message="Help and support resources will appear here"
          />
        );
      default:
        return <Dashboard onNavigate={setActiveTab} />;
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background">
        {/* Top Bar */}
        <TopBar onMenuClick={() => setMobileMenuOpen(true)} />

        <div className="flex h-[calc(100vh-4rem)]">
          {/* Desktop Sidebar */}
          <Sidebar 
            activeTab={activeTab} 
            onTabChange={setActiveTab} 
            className="hidden lg:block"
          />

          {/* Mobile Sidebar */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetContent side="left" className="w-64 p-0" aria-describedby={undefined}>
              <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
              <Sidebar 
                activeTab={activeTab} 
                onTabChange={(tab) => {
                  setActiveTab(tab);
                  setMobileMenuOpen(false);
                }} 
              />
            </SheetContent>
          </Sheet>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto pb-20 lg:pb-6">
            <div className="container max-w-7xl mx-auto p-6">
              {renderContent()}
            </div>
          </main>

          {/* Right Panel - Desktop Only */}
          <RightPanel />
        </div>

        {/* Bottom Navigation - Mobile Only */}
        <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

        {/* Toast Notifications */}
        <Toaster position="top-right" />
      </div>
    </ThemeProvider>
  );
}

export default App;
