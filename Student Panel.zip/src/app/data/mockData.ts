// Mock data for Student Panel

export const studentProfile = {
  name: "Alex Johnson",
  email: "alex.johnson@school.edu",
  rollNumber: "2024-CS-042",
  grade: "11th Grade",
  section: "A",
  avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
  academicYear: "2025-2026",
};

export const subjects = [
  { id: "math", name: "Mathematics", teacher: "Dr. Sarah Miller", color: "#3B82F6", room: "Room 201" },
  { id: "physics", name: "Physics", teacher: "Mr. John Davis", color: "#8B5CF6", room: "Lab 1" },
  { id: "chemistry", name: "Chemistry", teacher: "Ms. Emma Wilson", color: "#10B981", room: "Lab 2" },
  { id: "english", name: "English", teacher: "Mrs. Lisa Brown", color: "#F59E0B", room: "Room 105" },
  { id: "history", name: "History", teacher: "Mr. Robert Taylor", color: "#EF4444", room: "Room 302" },
  { id: "cs", name: "Computer Science", teacher: "Dr. Michael Chen", color: "#06B6D4", room: "Lab 3" },
];

export const routine = [
  { day: "Mon", periods: [
    { time: "08:00-09:00", subject: "math" },
    { time: "09:00-10:00", subject: "physics" },
    { time: "10:00-10:15", subject: "break" },
    { time: "10:15-11:15", subject: "chemistry" },
    { time: "11:15-12:15", subject: "english" },
    { time: "12:15-13:00", subject: "lunch" },
    { time: "13:00-14:00", subject: "history" },
    { time: "14:00-15:00", subject: "cs" },
  ]},
  { day: "Tue", periods: [
    { time: "08:00-09:00", subject: "english" },
    { time: "09:00-10:00", subject: "math" },
    { time: "10:00-10:15", subject: "break" },
    { time: "10:15-11:15", subject: "cs" },
    { time: "11:15-12:15", subject: "physics" },
    { time: "12:15-13:00", subject: "lunch" },
    { time: "13:00-14:00", subject: "chemistry" },
    { time: "14:00-15:00", subject: "history" },
  ]},
  { day: "Wed", periods: [
    { time: "08:00-09:00", subject: "chemistry" },
    { time: "09:00-10:00", subject: "english" },
    { time: "10:00-10:15", subject: "break" },
    { time: "10:15-11:15", subject: "math" },
    { time: "11:15-12:15", subject: "history" },
    { time: "12:15-13:00", subject: "lunch" },
    { time: "13:00-14:00", subject: "physics" },
    { time: "14:00-15:00", subject: "cs" },
  ]},
  { day: "Thu", periods: [
    { time: "08:00-09:00", subject: "cs" },
    { time: "09:00-10:00", subject: "chemistry" },
    { time: "10:00-10:15", subject: "break" },
    { time: "10:15-11:15", subject: "english" },
    { time: "11:15-12:15", subject: "math" },
    { time: "12:15-13:00", subject: "lunch" },
    { time: "13:00-14:00", subject: "physics" },
    { time: "14:00-15:00", subject: "history" },
  ]},
  { day: "Fri", periods: [
    { time: "08:00-09:00", subject: "physics" },
    { time: "09:00-10:00", subject: "history" },
    { time: "10:00-10:15", subject: "break" },
    { time: "10:15-11:15", subject: "chemistry" },
    { time: "11:15-12:15", subject: "cs" },
    { time: "12:15-13:00", subject: "lunch" },
    { time: "13:00-14:00", subject: "math" },
    { time: "14:00-15:00", subject: "english" },
  ]},
];

export const homework = [
  {
    id: "hw1",
    subject: "math",
    title: "Calculus Problem Set 5",
    description: "Complete exercises 1-20 from Chapter 8",
    dueDate: "2026-02-20T23:59:00",
    status: "pending",
    priority: "high",
    assignedDate: "2026-02-15T10:00:00",
  },
  {
    id: "hw2",
    subject: "physics",
    title: "Thermodynamics Lab Report",
    description: "Write a detailed lab report on the heat transfer experiment",
    dueDate: "2026-02-22T23:59:00",
    status: "pending",
    priority: "medium",
    assignedDate: "2026-02-12T09:00:00",
  },
  {
    id: "hw3",
    subject: "english",
    title: "Essay: Shakespeare Analysis",
    description: "Analyze themes in Macbeth (1500 words)",
    dueDate: "2026-02-19T23:59:00",
    status: "submitted",
    priority: "high",
    assignedDate: "2026-02-10T11:00:00",
    submittedDate: "2026-02-18T15:30:00",
    grade: "A",
    feedback: "Excellent analysis! Well-structured arguments.",
  },
  {
    id: "hw4",
    subject: "cs",
    title: "Binary Search Tree Implementation",
    description: "Implement BST with insert, delete, and search operations",
    dueDate: "2026-02-21T23:59:00",
    status: "pending",
    priority: "high",
    assignedDate: "2026-02-14T14:00:00",
  },
  {
    id: "hw5",
    subject: "chemistry",
    title: "Organic Chemistry Worksheet",
    description: "Complete reactions worksheet on alkenes",
    dueDate: "2026-02-18T23:59:00",
    status: "late",
    priority: "medium",
    assignedDate: "2026-02-11T10:00:00",
  },
];

export const exams = [
  {
    id: "exam1",
    subject: "math",
    title: "Mid-term Examination",
    date: "2026-02-25T09:00:00",
    duration: "3 hours",
    syllabus: "Chapters 1-8: Calculus, Algebra, Trigonometry",
    type: "written",
    totalMarks: 100,
    room: "Hall A",
  },
  {
    id: "exam2",
    subject: "physics",
    title: "Unit Test - Thermodynamics",
    date: "2026-02-28T10:00:00",
    duration: "2 hours",
    syllabus: "Heat transfer, Laws of thermodynamics, Entropy",
    type: "written",
    totalMarks: 50,
    room: "Room 201",
  },
  {
    id: "exam3",
    subject: "cs",
    title: "Practical Exam - Data Structures",
    date: "2026-03-05T14:00:00",
    duration: "2 hours",
    syllabus: "Arrays, Linked Lists, Trees, Graphs",
    type: "practical",
    totalMarks: 50,
    room: "Lab 3",
  },
];

export const results = [
  { subject: "math", marks: 92, total: 100, grade: "A+", teacherRemark: "Outstanding performance!" },
  { subject: "physics", marks: 85, total: 100, grade: "A", teacherRemark: "Very good work" },
  { subject: "chemistry", marks: 88, total: 100, grade: "A", teacherRemark: "Excellent understanding" },
  { subject: "english", marks: 90, total: 100, grade: "A+", teacherRemark: "Brilliant writing skills" },
  { subject: "history", marks: 82, total: 100, grade: "A", teacherRemark: "Good analytical ability" },
  { subject: "cs", marks: 95, total: 100, grade: "A+", teacherRemark: "Exceptional coding skills!" },
];

export const attendance = {
  overall: 94.5,
  bySubject: [
    { subject: "math", present: 42, total: 45, percentage: 93.3 },
    { subject: "physics", present: 43, total: 45, percentage: 95.6 },
    { subject: "chemistry", present: 41, total: 45, percentage: 91.1 },
    { subject: "english", present: 44, total: 45, percentage: 97.8 },
    { subject: "history", present: 42, total: 45, percentage: 93.3 },
    { subject: "cs", present: 45, total: 45, percentage: 100 },
  ],
  calendar: [
    { date: "2026-02-03", status: "present" },
    { date: "2026-02-04", status: "present" },
    { date: "2026-02-05", status: "present" },
    { date: "2026-02-06", status: "late" },
    { date: "2026-02-07", status: "present" },
    { date: "2026-02-10", status: "present" },
    { date: "2026-02-11", status: "present" },
    { date: "2026-02-12", status: "absent" },
    { date: "2026-02-13", status: "present" },
    { date: "2026-02-14", status: "present" },
    { date: "2026-02-17", status: "present" },
    { date: "2026-02-18", status: "present" },
  ],
};

export const achievements = [
  { id: 1, title: "Perfect Attendance", description: "100% attendance in CS", icon: "trophy", date: "2026-02-15" },
  { id: 2, title: "Top Scorer", description: "Highest marks in Math exam", icon: "star", date: "2026-02-10" },
  { id: 3, title: "Early Bird", description: "All homework submitted before deadline", icon: "clock", date: "2026-02-05" },
];

export const notices = [
  { id: 1, title: "School Sports Day", content: "Annual sports day on March 15th", date: "2026-02-18", priority: "medium" },
  { id: 2, title: "Library Closing Hours", content: "Library will close at 4 PM this week", date: "2026-02-17", priority: "low" },
  { id: 3, title: "Parent-Teacher Meeting", content: "PTM scheduled for February 28th", date: "2026-02-16", priority: "high" },
];

export const messages = [
  { id: 1, from: "Dr. Sarah Miller", subject: "Great work on the last test!", preview: "Your problem-solving approach was excellent...", time: "2h ago", unread: true },
  { id: 2, from: "Dr. Michael Chen", subject: "Project deadline reminder", preview: "Don't forget to submit your project by...", time: "5h ago", unread: false },
];

// Get today's classes
export function getTodayClasses() {
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const today = new Date();
  const dayName = days[today.getDay()];
  
  const todayRoutine = routine.find(r => r.day === dayName);
  if (!todayRoutine) return [];
  
  return todayRoutine.periods
    .filter(p => p.subject !== "break" && p.subject !== "lunch")
    .map(p => {
      const subjectData = subjects.find(s => s.id === p.subject);
      return {
        ...p,
        ...subjectData,
      };
    });
}

// Get current/next class
export function getCurrentClass() {
  const todayClasses = getTodayClasses();
  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();
  
  for (const cls of todayClasses) {
    const [start, end] = cls.time.split('-');
    const [startHour, startMin] = start.split(':').map(Number);
    const [endHour, endMin] = end.split(':').map(Number);
    const startTime = startHour * 60 + startMin;
    const endTime = endHour * 60 + endMin;
    
    if (currentTime >= startTime && currentTime <= endTime) {
      return { ...cls, status: 'ongoing' };
    }
    if (currentTime < startTime) {
      return { ...cls, status: 'upcoming' };
    }
  }
  
  return null;
}
