import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { AlertCircle, Bell, Lightbulb } from "lucide-react";
import { notices, attendance, homework } from "../data/mockData";

export function RightPanel() {
  const pendingHomework = homework.filter(h => h.status === "pending").length;
  const lowAttendance = attendance.overall < 75;

  return (
    <div className="w-80 border-l bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 hidden xl:block">
      <ScrollArea className="h-full">
        <div className="p-4 space-y-4">
          {/* Alerts */}
          {(lowAttendance || pendingHomework > 3) && (
            <Card className="border-orange-500/50 bg-orange-50 dark:bg-orange-950/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-orange-600" />
                  Alerts
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {lowAttendance && (
                  <div className="text-xs text-orange-900 dark:text-orange-200">
                    ⚠️ Attendance is below 75%. Please maintain regularity.
                  </div>
                )}
                {pendingHomework > 3 && (
                  <div className="text-xs text-orange-900 dark:text-orange-200">
                    📚 You have {pendingHomework} pending assignments. Stay on track!
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Recent Notices */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Bell className="h-4 w-4" />
                Recent Notices
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {notices.slice(0, 3).map((notice) => (
                <div key={notice.id} className="space-y-1 pb-3 border-b last:border-0 last:pb-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-medium text-sm">{notice.title}</div>
                    {notice.priority === "high" && (
                      <Badge variant="destructive" className="h-5 text-xs">High</Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{notice.content}</p>
                  <p className="text-xs text-muted-foreground">{notice.date}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* AI Study Suggestion */}
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-blue-200 dark:border-blue-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Lightbulb className="h-4 w-4 text-blue-600" />
                Study Tip
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-blue-900 dark:text-blue-200">
                💡 You have a Math exam coming up in 7 days. Consider reviewing Chapters 1-8 starting today. Aim for 2 hours of focused study per day!
              </p>
            </CardContent>
          </Card>

          {/* Motivational Quote */}
          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-purple-200 dark:border-purple-800">
            <CardContent className="pt-4">
              <div className="text-center space-y-2">
                <p className="text-sm font-medium text-purple-900 dark:text-purple-200">
                  "You're doing great! Keep going 🌟"
                </p>
                <p className="text-xs text-purple-700 dark:text-purple-300">
                  Stay focused and you'll achieve amazing things!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>
    </div>
  );
}
