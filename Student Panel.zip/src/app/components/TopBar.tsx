import { Bell, MessageSquare, Search, Sun, Moon, Menu } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Badge } from "./ui/badge";
import { studentProfile, getCurrentClass, messages } from "../data/mockData";
import { useTheme } from "next-themes";
import { useState, useEffect } from "react";

interface TopBarProps {
  onMenuClick?: () => void;
}

export function TopBar({ onMenuClick }: TopBarProps) {
  const { theme, setTheme } = useTheme();
  const [currentTime, setCurrentTime] = useState(new Date());
  const currentClass = getCurrentClass();
  const unreadMessages = messages.filter(m => m.unread).length;

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="h-full px-4 flex items-center justify-between gap-4">
        {/* Left Section */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={onMenuClick}
          >
            <Menu className="h-5 w-5" />
          </Button>
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
              SH
            </div>
            <div className="hidden md:block">
              <div className="font-semibold text-sm">Sunrise High School</div>
              <div className="text-xs text-muted-foreground">{studentProfile.academicYear}</div>
            </div>
          </div>
        </div>

        {/* Center Section - Date/Time & Active Class */}
        <div className="hidden md:flex items-center gap-6">
          <div className="text-center">
            <div className="text-sm font-medium">{formatDate(currentTime)}</div>
            <div className="text-xs text-muted-foreground font-mono">{formatTime(currentTime)}</div>
          </div>
          
          {currentClass && (
            <>
              <div className="h-8 w-px bg-border" />
              <div className="flex items-center gap-2">
                {currentClass.status === 'ongoing' && (
                  <Badge variant="destructive" className="animate-pulse">LIVE</Badge>
                )}
                <div>
                  <div className="text-sm font-medium">{currentClass.name}</div>
                  <div className="text-xs text-muted-foreground">{currentClass.time}</div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-2">
          <div className="hidden md:block relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search homework, exams..." 
              className="pl-9 h-9"
            />
          </div>

          <Button variant="ghost" size="icon" className="md:hidden">
            <Search className="h-5 w-5" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </Button>

          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full" />
          </Button>

          <Button variant="ghost" size="icon" className="relative">
            <MessageSquare className="h-5 w-5" />
            {unreadMessages > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                {unreadMessages}
              </Badge>
            )}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-accent transition-colors outline-none">
              <Avatar className="h-8 w-8">
                <AvatarImage src={studentProfile.avatar} />
                <AvatarFallback>{studentProfile.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <span className="hidden lg:inline text-sm font-medium">{studentProfile.name.split(' ')[0]}</span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium">{studentProfile.name}</p>
                  <p className="text-xs text-muted-foreground">{studentProfile.email}</p>
                  <p className="text-xs text-muted-foreground">{studentProfile.rollNumber}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>My Profile</DropdownMenuItem>
              <DropdownMenuItem>My Routine</DropdownMenuItem>
              <DropdownMenuItem>My Results</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600">Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}