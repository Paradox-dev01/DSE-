import { 
  LayoutDashboard, 
  BookOpen, 
  Calendar, 
  BookCheck, 
  FileText, 
  Trophy, 
  ClipboardList, 
  Award,
  MessageCircle,
  FolderOpen,
  CalendarDays,
  HelpCircle
} from "lucide-react";
import { cn } from "./ui/utils";

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  className?: string;
}

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "classes", label: "My Classes", icon: BookOpen },
  { id: "attendance", label: "Attendance", icon: Calendar },
  { id: "homework", label: "Homework", icon: BookCheck },
  { id: "exams", label: "Exams", icon: FileText },
  { id: "results", label: "Results", icon: Trophy },
  { id: "routine", label: "Routine", icon: ClipboardList },
  { id: "achievements", label: "Achievements", icon: Award },
  { id: "communication", label: "Communication", icon: MessageCircle },
  { id: "resources", label: "Resources", icon: FolderOpen },
  { id: "planner", label: "Planner", icon: CalendarDays },
  { id: "help", label: "Help", icon: HelpCircle },
];

export function Sidebar({ activeTab, onTabChange, className }: SidebarProps) {
  return (
    <div className={cn("w-64 border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 overflow-y-auto", className)}>
      <div className="py-4">
        <nav className="space-y-1 px-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <Icon className="h-5 w-5 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
