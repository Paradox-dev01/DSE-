import { Card, CardContent } from "../ui/card";
import { LucideIcon } from "lucide-react";

interface PlaceholderScreenProps {
  title: string;
  description: string;
  icon: LucideIcon;
  message?: string;
}

export function PlaceholderScreen({ title, description, icon: Icon, message }: PlaceholderScreenProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{title}</h1>
        <p className="text-muted-foreground">{description}</p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-12">
            <Icon className="h-16 w-16 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-lg text-muted-foreground">
              {message || `${title} feature coming soon!`}
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              This section is under development.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
