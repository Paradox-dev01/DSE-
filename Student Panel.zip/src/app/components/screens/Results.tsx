import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Download, Trophy, TrendingUp } from "lucide-react";
import { results, subjects } from "../../data/mockData";
import { toast } from "sonner";

export function Results() {
  const totalMarks = results.reduce((acc, r) => acc + r.marks, 0);
  const totalPossible = results.reduce((acc, r) => acc + r.total, 0);
  const percentage = ((totalMarks / totalPossible) * 100).toFixed(2);
  const gpa = ((totalMarks / totalPossible) * 4).toFixed(2);

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'text-green-600 bg-green-50 dark:bg-green-950/20';
    if (grade.startsWith('B')) return 'text-blue-600 bg-blue-50 dark:bg-blue-950/20';
    if (grade.startsWith('C')) return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-950/20';
    return 'text-red-600 bg-red-50 dark:bg-red-950/20';
  };

  const handleDownload = () => {
    toast.success("Result card downloaded successfully!");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Academic Results</h1>
          <p className="text-muted-foreground">Your academic performance and grades</p>
        </div>
        <Button onClick={handleDownload}>
          <Download className="mr-2 h-4 w-4" />
          Download PDF
        </Button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-blue-200 dark:border-blue-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Overall Percentage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-4xl font-bold text-blue-600">{percentage}%</div>
              <TrendingUp className="h-5 w-5 text-blue-600" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {totalMarks} out of {totalPossible} marks
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-purple-200 dark:border-purple-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">GPA</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-4xl font-bold text-purple-600">{gpa}</div>
              <span className="text-muted-foreground">/ 4.0</span>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Grade Point Average</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 border-amber-200 dark:border-amber-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Overall Grade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-4xl font-bold text-amber-600">A+</div>
              <Trophy className="h-5 w-5 text-amber-600" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Excellent Performance!</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Results Table */}
      <Card>
        <CardHeader>
          <CardTitle>Subject-wise Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead>Teacher</TableHead>
                  <TableHead className="text-center">Marks Obtained</TableHead>
                  <TableHead className="text-center">Total Marks</TableHead>
                  <TableHead className="text-center">Percentage</TableHead>
                  <TableHead className="text-center">Grade</TableHead>
                  <TableHead>Teacher's Remark</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result) => {
                  const subject = subjects.find(s => s.id === result.subject);
                  const subjectPercentage = ((result.marks / result.total) * 100).toFixed(1);
                  
                  return (
                    <TableRow key={result.subject}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: subject?.color }}
                          />
                          <span className="font-medium">{subject?.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {subject?.teacher}
                      </TableCell>
                      <TableCell className="text-center font-semibold">
                        {result.marks}
                      </TableCell>
                      <TableCell className="text-center text-muted-foreground">
                        {result.total}
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="font-medium">{subjectPercentage}%</span>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={getGradeColor(result.grade)}>
                          {result.grade}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs">
                        {result.teacherRemark}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Performance Analysis */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border-green-200 dark:border-green-800">
        <CardHeader>
          <CardTitle className="text-green-900 dark:text-green-200">Performance Summary</CardTitle>
        </CardHeader>
        <CardContent className="text-green-900 dark:text-green-200">
          <div className="space-y-2">
            <p className="text-sm">🎉 Outstanding performance across all subjects!</p>
            <p className="text-sm">⭐ You've scored above 90% in {results.filter(r => (r.marks/r.total) * 100 >= 90).length} subjects.</p>
            <p className="text-sm">💪 Keep up the excellent work and maintain this consistency!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
