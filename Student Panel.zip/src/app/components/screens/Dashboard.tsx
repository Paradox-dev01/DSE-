import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { 
  Clock, 
  BookCheck, 
  FileText, 
  Calendar, 
  Trophy,
  MessageSquare,
  Award,
  ArrowRight,
  AlertCircle,
  Sparkles,
  Zap,
  Star
} from "lucide-react";
import { getTodayClasses, homework, exams, attendance, results, messages, achievements, subjects } from "../../data/mockData";
import { format, parseISO, differenceInDays } from "date-fns";
import { motion } from "motion/react";

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const todayClasses = getTodayClasses();
  const pendingHomework = homework.filter(h => h.status === "pending");
  const upcomingExams = exams.filter(e => differenceInDays(parseISO(e.date), new Date()) >= 0).slice(0, 3);
  const avgMarks = results.reduce((acc, r) => acc + r.marks, 0) / results.length;
  const overallGPA = (avgMarks / 100 * 4).toFixed(2);
  const unreadMessages = messages.filter(m => m.unread).length;

  return (
    <div className="space-y-6">
      {/* Animated Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 dark:from-cyan-600 dark:via-blue-700 dark:to-purple-800 p-8 md:p-12 shadow-xl">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          {/* Floating Circles */}
          <motion.div
            className="absolute top-10 left-10 w-20 h-20 bg-white/20 dark:bg-white/10 rounded-full blur-xl"
            animate={{
              y: [0, -20, 0],
              x: [0, 10, 0],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute top-20 right-20 w-32 h-32 bg-emerald-300/30 dark:bg-emerald-400/20 rounded-full blur-2xl"
            animate={{
              y: [0, 30, 0],
              x: [0, -20, 0],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.5,
            }}
          />
          <motion.div
            className="absolute bottom-10 left-1/3 w-24 h-24 bg-orange-300/30 dark:bg-orange-400/20 rounded-full blur-xl"
            animate={{
              y: [0, -25, 0],
              x: [0, 15, 0],
              scale: [1, 1.15, 1],
            }}
            transition={{
              duration: 4.5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1,
            }}
          />
          
          {/* Floating Stars */}
          <motion.div
            className="absolute top-1/4 left-1/4"
            animate={{
              rotate: [0, 360],
              scale: [1, 1.3, 1],
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "linear",
            }}
          >
            <Star className="w-6 h-6 text-yellow-200 dark:text-yellow-300 fill-yellow-200 dark:fill-yellow-300" />
          </motion.div>
          <motion.div
            className="absolute top-1/3 right-1/3"
            animate={{
              rotate: [0, -360],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "linear",
              delay: 1,
            }}
          >
            <Sparkles className="w-5 h-5 text-white" />
          </motion.div>
          <motion.div
            className="absolute bottom-1/4 right-1/4"
            animate={{
              rotate: [0, 360],
              y: [0, -10, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.5,
            }}
          >
            <Zap className="w-6 h-6 text-amber-200 dark:text-amber-300 fill-amber-200 dark:fill-amber-300" />
          </motion.div>
        </div>

        {/* Content */}
        <div className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-2 mb-3">
              <motion.div
                animate={{
                  rotate: [0, 10, -10, 10, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 3,
                }}
              >
                <span className="text-4xl">👋</span>
              </motion.div>
              <h1 className="text-3xl md:text-4xl font-bold text-white drop-shadow-lg">
                Good {new Date().getHours() < 12 ? "Morning" : new Date().getHours() < 18 ? "Afternoon" : "Evening"}!
              </h1>
            </div>
            <p className="text-white/95 dark:text-white/90 text-lg md:text-xl mb-4 drop-shadow">
              Here's what's happening with your studies today
            </p>
            
            {/* Animated Stats Pills */}
            <div className="flex flex-wrap gap-3">
              <motion.div
                className="bg-white/30 dark:bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full border border-white/40 dark:border-white/30 shadow-lg hover:bg-white/40"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <span className="text-white font-semibold text-sm drop-shadow">
                  {todayClasses.length} Classes Today
                </span>
              </motion.div>
              <motion.div
                className="bg-white/30 dark:bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full border border-white/40 dark:border-white/30 shadow-lg hover:bg-white/40"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <span className="text-white font-semibold text-sm drop-shadow">
                  {pendingHomework.length} Homework Pending
                </span>
              </motion.div>
              <motion.div
                className="bg-white/30 dark:bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full border border-white/40 dark:border-white/30 shadow-lg hover:bg-white/40"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <span className="text-white font-semibold text-sm drop-shadow">
                  {attendance.overall}% Attendance
                </span>
              </motion.div>
            </div>

            {/* Motivational Text with Animation */}
            <motion.div
              className="mt-6 flex items-center gap-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  rotate: [0, 5, -5, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 2,
                }}
              >
                <Sparkles className="w-5 h-5 text-yellow-200 dark:text-yellow-300" />
              </motion.div>
              <span className="text-white/95 dark:text-white/90 text-sm font-medium drop-shadow">
                You're doing amazing! Keep up the great work 🌟
              </span>
            </motion.div>
          </motion.div>
        </div>

        {/* 3D Rotating Trophy Icon */}
        <motion.div
          className="absolute -bottom-4 -right-4 md:bottom-6 md:right-6 opacity-20 dark:opacity-15"
          animate={{
            rotateY: [0, 360],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear",
          }}
          style={{
            transformStyle: "preserve-3d",
          }}
        >
          <Trophy className="w-24 h-24 md:w-32 md:h-32 text-white" />
        </motion.div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          whileHover={{ y: -4, transition: { duration: 0.2 } }}
        >
          <Card className="border-l-4 border-l-blue-500 shadow-md hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-400">Today's Classes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{todayClasses.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Scheduled for today</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          whileHover={{ y: -4, transition: { duration: 0.2 } }}
        >
          <Card className="border-l-4 border-l-orange-500 shadow-md hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-amber-950/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-orange-700 dark:text-orange-400">Pending Homework</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">{pendingHomework.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Assignments due soon</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          whileHover={{ y: -4, transition: { duration: 0.2 } }}
        >
          <Card className="border-l-4 border-l-emerald-500 shadow-md hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-emerald-700 dark:text-emerald-400">Attendance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{attendance.overall}%</div>
              <Progress value={attendance.overall} className="mt-2" />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          whileHover={{ y: -4, transition: { duration: 0.2 } }}
        >
          <Card className="border-l-4 border-l-purple-500 shadow-md hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-purple-50 to-fuchsia-50 dark:from-purple-950/20 dark:to-fuchsia-950/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-purple-700 dark:text-purple-400">Overall GPA</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">{overallGPA}</div>
              <p className="text-xs text-muted-foreground mt-1">Out of 4.0</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Classes Timeline */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Today's Schedule
                </CardTitle>
                <CardDescription>Your classes for today</CardDescription>
              </div>
              <Button variant="ghost" size="sm" onClick={() => onNavigate("routine")}>
                View Full Routine <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {todayClasses.length > 0 ? (
                todayClasses.map((cls, index) => {
                  const now = new Date();
                  const [start] = cls.time.split('-');
                  const [startHour, startMin] = start.split(':').map(Number);
                  const classTime = new Date(now.setHours(startHour, startMin, 0));
                  const isPast = classTime < new Date();
                  const isCurrent = !isPast && differenceInDays(classTime, new Date()) === 0;

                  return (
                    <div
                      key={index}
                      className={`flex items-center justify-between p-4 rounded-lg border ${
                        isCurrent ? 'bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800' : 
                        isPast ? 'opacity-50' : ''
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div 
                          className="w-1 h-14 rounded-full" 
                          style={{ backgroundColor: cls.color }}
                        />
                        <div>
                          <div className="font-semibold">{cls.name}</div>
                          <div className="text-sm text-muted-foreground">{cls.teacher}</div>
                          <div className="text-xs text-muted-foreground mt-1">{cls.room}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium font-mono text-sm">{cls.time}</div>
                        {isCurrent && (
                          <Badge variant="default" className="mt-1">Next Class</Badge>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No classes scheduled for today
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Pending Homework */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <BookCheck className="h-5 w-5" />
                Pending Homework
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => onNavigate("homework")}>
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingHomework.slice(0, 3).map((hw) => {
                const subject = subjects.find(s => s.id === hw.subject);
                const daysLeft = differenceInDays(parseISO(hw.dueDate), new Date());
                const isUrgent = daysLeft <= 2;

                return (
                  <div key={hw.id} className="p-3 rounded-lg border space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="font-medium text-sm">{hw.title}</div>
                        <div className="text-xs text-muted-foreground mt-1">{subject?.name}</div>
                      </div>
                      {isUrgent && (
                        <AlertCircle className="h-4 w-4 text-orange-500" />
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <Badge variant={isUrgent ? "destructive" : "secondary"} className="text-xs">
                        Due in {daysLeft} {daysLeft === 1 ? 'day' : 'days'}
                      </Badge>
                      <Button size="sm" variant="outline">Submit</Button>
                    </div>
                  </div>
                );
              })}
              {pendingHomework.length === 0 && (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  🎉 All caught up! No pending homework.
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Exams */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Upcoming Exams
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => onNavigate("exams")}>
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingExams.map((exam) => {
                const subject = subjects.find(s => s.id === exam.subject);
                const daysLeft = differenceInDays(parseISO(exam.date), new Date());

                return (
                  <div key={exam.id} className="p-3 rounded-lg border space-y-2">
                    <div className="font-medium text-sm">{exam.title}</div>
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: subject?.color }}
                      />
                      <span className="text-xs text-muted-foreground">{subject?.name}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">
                        {format(parseISO(exam.date), 'MMM dd, yyyy • hh:mm a')}
                      </span>
                      <Badge variant="outline">In {daysLeft} days</Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Messages */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Recent Messages
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {messages.slice(0, 2).map((msg) => (
                <div key={msg.id} className="p-3 rounded-lg border space-y-1">
                  <div className="flex items-start justify-between">
                    <div className="font-medium text-sm">{msg.from}</div>
                    {msg.unread && (
                      <div className="w-2 h-2 bg-blue-600 rounded-full" />
                    )}
                  </div>
                  <div className="text-xs font-medium">{msg.subject}</div>
                  <div className="text-xs text-muted-foreground line-clamp-1">{msg.preview}</div>
                  <div className="text-xs text-muted-foreground">{msg.time}</div>
                </div>
              ))}
              {unreadMessages > 0 && (
                <Button variant="outline" size="sm" className="w-full" onClick={() => onNavigate("communication")}>
                  {unreadMessages} Unread Messages
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Achievement Highlights */}
        <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 border-amber-200 dark:border-amber-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-amber-600" />
              Recent Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {achievements.slice(0, 2).map((achievement) => (
                <div key={achievement.id} className="p-3 rounded-lg bg-white/50 dark:bg-black/20 space-y-1">
                  <div className="flex items-center gap-2">
                    <Trophy className="h-4 w-4 text-amber-600" />
                    <div className="font-medium text-sm">{achievement.title}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">{achievement.description}</div>
                  <div className="text-xs text-muted-foreground">{achievement.date}</div>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full" onClick={() => onNavigate("achievements")}>
                View All Achievements
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button variant="outline" className="h-auto py-4 flex-col gap-2" onClick={() => onNavigate("classes")}>
              <BookCheck className="h-5 w-5" />
              <span className="text-sm">Open Class</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2" onClick={() => onNavigate("homework")}>
              <FileText className="h-5 w-5" />
              <span className="text-sm">Submit Work</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2" onClick={() => onNavigate("routine")}>
              <Calendar className="h-5 w-5" />
              <span className="text-sm">View Routine</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2" onClick={() => onNavigate("communication")}>
              <MessageSquare className="h-5 w-5" />
              <span className="text-sm">Message Teacher</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}