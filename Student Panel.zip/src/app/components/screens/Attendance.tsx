import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Calendar, TrendingUp, AlertCircle } from "lucide-react";
import { attendance, subjects } from "../../data/mockData";
import { cn } from "../ui/utils";

export function Attendance() {
  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 90) return "text-green-600";
    if (percentage >= 75) return "text-yellow-600";
    return "text-red-600";
  };

  const getAttendanceStatus = (percentage: number) => {
    if (percentage >= 90) return { text: "Excellent", variant: "default" as const };
    if (percentage >= 75) return { text: "Good", variant: "secondary" as const };
    return { text: "Low", variant: "destructive" as const };
  };

  // Generate calendar days for February 2026
  const generateCalendarDays = () => {
    const days = [];
    const startDate = new Date(2026, 1, 1); // February 1, 2026
    const daysInMonth = 28; // February 2026 has 28 days
    
    for (let i = 1; i <= daysInMonth; i++) {
      const date = new Date(2026, 1, i);
      const dateString = date.toISOString().split('T')[0];
      const attendanceRecord = attendance.calendar.find(a => a.date === dateString);
      
      days.push({
        day: i,
        date: dateString,
        dayOfWeek: date.getDay(),
        status: attendanceRecord?.status || null,
      });
    }
    
    return days;
  };

  const calendarDays = generateCalendarDays();
  const status = getAttendanceStatus(attendance.overall);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Attendance</h1>
        <p className="text-muted-foreground">Track your class attendance and presence</p>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Select defaultValue="feb-2026">
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Select month" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="feb-2026">February 2026</SelectItem>
            <SelectItem value="jan-2026">January 2026</SelectItem>
            <SelectItem value="dec-2025">December 2025</SelectItem>
          </SelectContent>
        </Select>

        <Select defaultValue="all">
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by subject" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Subjects</SelectItem>
            {subjects.map(subject => (
              <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">Overall Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-baseline gap-2">
                <div className={cn("text-4xl font-bold", getAttendanceColor(attendance.overall))}>
                  {attendance.overall}%
                </div>
                <Badge variant={status.variant}>{status.text}</Badge>
              </div>
              <Progress value={attendance.overall} className="h-2" />
              {attendance.overall < 75 && (
                <div className="flex items-start gap-2 text-xs text-red-600 dark:text-red-400">
                  <AlertCircle className="h-3 w-3 mt-0.5 shrink-0" />
                  <span>Attendance below 75%. Please maintain regularity to avoid academic penalties.</span>
                </div>
              )}
              {attendance.overall >= 90 && (
                <div className="flex items-start gap-2 text-xs text-green-600 dark:text-green-400">
                  <TrendingUp className="h-3 w-3 mt-0.5 shrink-0" />
                  <span>Keep going! You're doing great!</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-sm font-medium">Subject-wise Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {attendance.bySubject.map((item) => {
                const subject = subjects.find(s => s.id === item.subject);
                return (
                  <div key={item.subject} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: subject?.color }}
                        />
                        <span className="text-sm font-medium">{subject?.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {item.present}/{item.total}
                        </span>
                        <span className={cn("text-sm font-semibold", getAttendanceColor(item.percentage))}>
                          {item.percentage.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <Progress value={item.percentage} className="h-1.5" />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Calendar View */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Calendar View - February 2026
            </CardTitle>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-muted-foreground">Present</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <span className="text-muted-foreground">Late</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-muted-foreground">Absent</span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {/* Day headers */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center text-sm font-semibold text-muted-foreground p-2">
                {day}
              </div>
            ))}
            
            {/* Empty cells for days before month starts (Feb 1, 2026 is a Sunday) */}
            {Array.from({ length: 0 }).map((_, i) => (
              <div key={`empty-${i}`} />
            ))}
            
            {/* Calendar days */}
            {calendarDays.map((day) => {
              const isWeekend = day.dayOfWeek === 0 || day.dayOfWeek === 6;
              const statusColor = 
                day.status === 'present' ? 'bg-green-500' :
                day.status === 'late' ? 'bg-yellow-500' :
                day.status === 'absent' ? 'bg-red-500' :
                null;

              return (
                <div
                  key={day.date}
                  className={cn(
                    "aspect-square p-2 rounded-lg border relative",
                    isWeekend && "bg-muted/30",
                    day.status && "cursor-pointer hover:shadow-md transition-shadow"
                  )}
                >
                  <div className="text-sm font-medium">{day.day}</div>
                  {statusColor && (
                    <div className={cn("absolute bottom-2 right-2 w-2 h-2 rounded-full", statusColor)} />
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
