import { Card, CardContent } from "../ui/card";
import { Badge } from "../ui/badge";
import { ScrollArea } from "../ui/scroll-area";
import { routine, subjects } from "../../data/mockData";
import { cn } from "../ui/utils";

export function Routine() {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  const currentDay = new Date().getDay();
  const currentDayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][currentDay];
  
  // Get all unique time slots
  const timeSlots = routine[0]?.periods.map(p => p.time) || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Class Routine</h1>
        <p className="text-muted-foreground">Your weekly class schedule</p>
      </div>

      {/* Mobile View - Scrollable Cards */}
      <div className="lg:hidden space-y-4">
        {days.map((day) => {
          const dayRoutine = routine.find(r => r.day === day);
          const isToday = day === currentDayName;

          return (
            <Card key={day} className={cn(isToday && "border-blue-500 bg-blue-50/50 dark:bg-blue-950/20")}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-lg">{day}</h3>
                  {isToday && <Badge>Today</Badge>}
                </div>
                <div className="space-y-2">
                  {dayRoutine?.periods.map((period, index) => {
                    if (period.subject === "break") {
                      return (
                        <div key={index} className="p-2 rounded bg-gray-100 dark:bg-gray-800 text-center text-xs text-muted-foreground">
                          ☕ Break
                        </div>
                      );
                    }
                    if (period.subject === "lunch") {
                      return (
                        <div key={index} className="p-2 rounded bg-amber-100 dark:bg-amber-900/20 text-center text-xs text-muted-foreground">
                          🍽️ Lunch Break
                        </div>
                      );
                    }

                    const subject = subjects.find(s => s.id === period.subject);
                    return (
                      <div 
                        key={index}
                        className="p-3 rounded-lg border flex items-center gap-3"
                      >
                        <div 
                          className="w-1 h-12 rounded-full"
                          style={{ backgroundColor: subject?.color }}
                        />
                        <div className="flex-1">
                          <div className="font-medium text-sm">{subject?.name}</div>
                          <div className="text-xs text-muted-foreground">{subject?.teacher}</div>
                        </div>
                        <div className="text-xs font-mono text-muted-foreground">{period.time}</div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Desktop View - Table */}
      <div className="hidden lg:block">
        <Card>
          <ScrollArea className="w-full">
            <div className="min-w-[900px]">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="sticky left-0 bg-muted/50 p-4 text-left font-semibold min-w-[100px] z-10">
                      Time
                    </th>
                    {days.map((day) => {
                      const isToday = day === currentDayName;
                      return (
                        <th 
                          key={day} 
                          className={cn(
                            "p-4 text-center font-semibold",
                            isToday && "bg-blue-100 dark:bg-blue-950/30"
                          )}
                        >
                          <div className="flex items-center justify-center gap-2">
                            {day}
                            {isToday && <Badge variant="default" className="text-xs">Today</Badge>}
                          </div>
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {timeSlots.map((timeSlot, timeIndex) => {
                    return (
                      <tr key={timeIndex} className="border-b hover:bg-muted/30 transition-colors">
                        <td className="sticky left-0 bg-background p-4 font-mono text-sm text-muted-foreground z-10 border-r">
                          {timeSlot}
                        </td>
                        {days.map((day) => {
                          const dayRoutine = routine.find(r => r.day === day);
                          const period = dayRoutine?.periods[timeIndex];
                          const isToday = day === currentDayName;

                          if (!period) return <td key={day} className="p-2" />;

                          // Handle breaks
                          if (period.subject === "break") {
                            return (
                              <td 
                                key={day} 
                                className={cn(
                                  "p-2",
                                  isToday && "bg-blue-50 dark:bg-blue-950/10"
                                )}
                              >
                                <div className="p-3 rounded-lg bg-gray-100 dark:bg-gray-800 text-center text-xs text-muted-foreground">
                                  ☕ Break
                                </div>
                              </td>
                            );
                          }

                          if (period.subject === "lunch") {
                            return (
                              <td 
                                key={day}
                                className={cn(
                                  "p-2",
                                  isToday && "bg-blue-50 dark:bg-blue-950/10"
                                )}
                              >
                                <div className="p-3 rounded-lg bg-amber-100 dark:bg-amber-900/20 text-center text-xs text-muted-foreground">
                                  🍽️ Lunch
                                </div>
                              </td>
                            );
                          }

                          const subject = subjects.find(s => s.id === period.subject);

                          return (
                            <td 
                              key={day}
                              className={cn(
                                "p-2 cursor-pointer",
                                isToday && "bg-blue-50 dark:bg-blue-950/10"
                              )}
                            >
                              <div 
                                className="p-3 rounded-lg border hover:shadow-md transition-shadow"
                                style={{ 
                                  borderLeftWidth: '3px',
                                  borderLeftColor: subject?.color 
                                }}
                              >
                                <div className="font-medium text-sm">{subject?.name}</div>
                                <div className="text-xs text-muted-foreground mt-1">{subject?.room}</div>
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </ScrollArea>
        </Card>

        {/* Legend */}
        <div className="mt-4 flex items-center gap-6 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-blue-100 dark:bg-blue-950/30 border border-blue-500" />
            <span>Today</span>
          </div>
          {subjects.slice(0, 3).map((subject) => (
            <div key={subject.id} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: subject.color }} />
              <span>{subject.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
