import { Card, CardContent } from "../ui/card";
import { 
  Trophy, 
  FileText,
  MessageCircle,
  FolderOpen,
  CalendarDays,
  HelpCircle,
  ChevronRight
} from "lucide-react";

interface MoreMenuProps {
  onNavigate: (tab: string) => void;
}

const menuItems = [
  { id: "attendance", label: "Attendance", icon: CalendarDays, description: "View your attendance records" },
  { id: "exams", label: "Examinations", icon: FileText, description: "Upcoming and past exams" },
  { id: "results", label: "Results", icon: Trophy, description: "Academic performance" },
  { id: "achievements", label: "Achievements", icon: Trophy, description: "Your badges and awards" },
  { id: "communication", label: "Communication", icon: MessageCircle, description: "Messages and chats" },
  { id: "resources", label: "Resources", icon: FolderOpen, description: "Study materials" },
  { id: "planner", label: "Planner", icon: CalendarDays, description: "Plan your studies" },
  { id: "help", label: "Help & Support", icon: HelpCircle, description: "Get assistance" },
];

export function MoreMenu({ onNavigate }: MoreMenuProps) {
  return (
    <div className="space-y-6 pb-20">
      <div>
        <h1 className="text-3xl font-bold">More</h1>
        <p className="text-muted-foreground">Additional features and options</p>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Card 
              key={item.id}
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => onNavigate(item.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-medium">{item.label}</div>
                      <div className="text-xs text-muted-foreground">{item.description}</div>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
