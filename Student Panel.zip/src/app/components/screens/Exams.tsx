import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { FileText, Clock, MapPin, BookOpen } from "lucide-react";
import { exams, subjects } from "../../data/mockData";
import { format, parseISO, differenceInDays } from "date-fns";

export function Exams() {
  const now = new Date();
  const upcomingExams = exams.filter(e => differenceInDays(parseISO(e.date), now) >= 0);
  const pastExams = exams.filter(e => differenceInDays(parseISO(e.date), now) < 0);

  const ExamCard = ({ exam }: { exam: typeof exams[0] }) => {
    const subject = subjects.find(s => s.id === exam.subject);
    const daysLeft = differenceInDays(parseISO(exam.date), now);
    const isUpcoming = daysLeft >= 0;

    return (
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-1 flex-1">
              <CardTitle className="text-lg">{exam.title}</CardTitle>
              <div className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: subject?.color }}
                />
                <span className="text-sm text-muted-foreground">{subject?.name}</span>
              </div>
            </div>
            {isUpcoming && (
              <Badge variant={daysLeft <= 7 ? "destructive" : "secondary"}>
                In {daysLeft} {daysLeft === 1 ? 'day' : 'days'}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>Date & Time</span>
              </div>
              <div className="text-sm font-medium">
                {format(parseISO(exam.date), 'MMM dd, yyyy')}
                <br />
                {format(parseISO(exam.date), 'hh:mm a')}
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <FileText className="h-4 w-4" />
                <span>Duration</span>
              </div>
              <div className="text-sm font-medium">{exam.duration}</div>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>Location</span>
              </div>
              <div className="text-sm font-medium">{exam.room}</div>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <BookOpen className="h-4 w-4" />
                <span>Marks</span>
              </div>
              <div className="text-sm font-medium">{exam.totalMarks}</div>
            </div>
          </div>

          <div className="pt-4 border-t">
            <div className="text-sm font-medium mb-2">Syllabus</div>
            <div className="text-sm text-muted-foreground">{exam.syllabus}</div>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="outline">{exam.type}</Badge>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Examinations</h1>
        <p className="text-muted-foreground">View your upcoming and past examinations</p>
      </div>

      <Tabs defaultValue="upcoming" className="space-y-4">
        <TabsList>
          <TabsTrigger value="upcoming">
            Upcoming ({upcomingExams.length})
          </TabsTrigger>
          <TabsTrigger value="past">
            Completed ({pastExams.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-4">
          {upcomingExams.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {upcomingExams.map((exam) => (
                <ExamCard key={exam.id} exam={exam} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8 text-muted-foreground">
                  No upcoming exams scheduled
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="past" className="space-y-4">
          {pastExams.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {pastExams.map((exam) => (
                <ExamCard key={exam.id} exam={exam} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8 text-muted-foreground">
                  No past exams to display
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
