import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { AlertCircle, Upload, CheckCircle, Clock, XCircle, FileText } from "lucide-react";
import { homework, subjects } from "../../data/mockData";
import { format, parseISO, differenceInDays } from "date-fns";
import { toast } from "sonner";

export function Homework() {
  const [selectedHomework, setSelectedHomework] = useState<string | null>(null);
  const [comment, setComment] = useState("");

  const pendingHomework = homework.filter(h => h.status === "pending");
  const submittedHomework = homework.filter(h => h.status === "submitted");
  const lateHomework = homework.filter(h => h.status === "late");

  const handleSubmit = () => {
    toast.success("Homework submitted successfully! 🎉");
    setSelectedHomework(null);
    setComment("");
  };

  if (selectedHomework) {
    const hw = homework.find(h => h.id === selectedHomework);
    if (!hw) return null;

    const subject = subjects.find(s => s.id === hw.subject);
    const daysLeft = differenceInDays(parseISO(hw.dueDate), new Date());

    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={() => setSelectedHomework(null)}>
            ← Back
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Assignment Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle>{hw.title}</CardTitle>
                    <CardDescription>{subject?.name}</CardDescription>
                  </div>
                  <Badge 
                    variant={hw.status === "submitted" ? "default" : daysLeft <= 2 ? "destructive" : "secondary"}
                  >
                    {hw.status === "submitted" ? "Submitted" : `Due in ${daysLeft} days`}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground">{hw.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div>
                    <div className="text-sm text-muted-foreground">Assigned Date</div>
                    <div className="font-medium">{format(parseISO(hw.assignedDate), 'MMM dd, yyyy')}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Due Date</div>
                    <div className="font-medium">{format(parseISO(hw.dueDate), 'MMM dd, yyyy hh:mm a')}</div>
                  </div>
                </div>

                {hw.status === "submitted" && hw.grade && (
                  <div className="p-4 rounded-lg bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div className="flex-1">
                        <div className="font-semibold text-green-900 dark:text-green-200">Grade: {hw.grade}</div>
                        <div className="text-sm text-green-700 dark:text-green-300 mt-1">{hw.feedback}</div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Submission Area */}
          <div>
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle className="text-lg">Submission</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {hw.status !== "submitted" ? (
                  <>
                    <div>
                      <Label htmlFor="file">Upload File</Label>
                      <div className="mt-2 border-2 border-dashed rounded-lg p-6 text-center hover:bg-accent/50 transition-colors cursor-pointer">
                        <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                        <div className="text-sm text-muted-foreground">
                          Click to upload or drag and drop
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          PDF, DOC, DOCX (max 10MB)
                        </div>
                        <Input 
                          id="file" 
                          type="file" 
                          className="hidden" 
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="comment">Add Comment (Optional)</Label>
                      <Textarea
                        id="comment"
                        placeholder="Add any notes or comments..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        className="mt-2"
                        rows={4}
                      />
                    </div>

                    <Button className="w-full" size="lg" onClick={handleSubmit}>
                      Submit Homework
                    </Button>

                    {daysLeft <= 2 && (
                      <div className="flex items-start gap-2 p-3 rounded-lg bg-orange-50 dark:bg-orange-950/20 text-orange-900 dark:text-orange-200">
                        <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                        <div className="text-xs">
                          Deadline approaching! Submit before {format(parseISO(hw.dueDate), 'MMM dd, hh:mm a')}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-6">
                    <CheckCircle className="h-12 w-12 mx-auto text-green-600 mb-3" />
                    <div className="font-semibold">Assignment Submitted</div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Submitted on {format(parseISO(hw.submittedDate!), 'MMM dd, yyyy hh:mm a')}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Homework</h1>
        <p className="text-muted-foreground">Manage your assignments and submissions</p>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">
            Pending ({pendingHomework.length})
          </TabsTrigger>
          <TabsTrigger value="submitted">
            Submitted ({submittedHomework.length})
          </TabsTrigger>
          <TabsTrigger value="late">
            Late ({lateHomework.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-3">
          {pendingHomework.map((hw) => {
            const subject = subjects.find(s => s.id === hw.subject);
            const daysLeft = differenceInDays(parseISO(hw.dueDate), new Date());
            const isUrgent = daysLeft <= 2;

            return (
              <Card 
                key={hw.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setSelectedHomework(hw.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
                        style={{ backgroundColor: subject?.color }}
                      >
                        <FileText className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold">{hw.title}</div>
                        <div className="text-sm text-muted-foreground mt-1">{subject?.name}</div>
                        <div className="text-xs text-muted-foreground mt-2 line-clamp-1">{hw.description}</div>
                        <div className="flex items-center gap-3 mt-3">
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            Due {format(parseISO(hw.dueDate), 'MMM dd, hh:mm a')}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge variant={isUrgent ? "destructive" : "secondary"}>
                        {daysLeft} {daysLeft === 1 ? 'day' : 'days'} left
                      </Badge>
                      {hw.priority === "high" && (
                        <Badge variant="outline">High Priority</Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {pendingHomework.length === 0 && (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-3 text-green-600" />
                  <div>All caught up! No pending homework.</div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="submitted" className="space-y-3">
          {submittedHomework.map((hw) => {
            const subject = subjects.find(s => s.id === hw.subject);

            return (
              <Card 
                key={hw.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setSelectedHomework(hw.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
                        style={{ backgroundColor: subject?.color }}
                      >
                        <CheckCircle className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold">{hw.title}</div>
                        <div className="text-sm text-muted-foreground mt-1">{subject?.name}</div>
                        {hw.submittedDate && (
                          <div className="text-xs text-muted-foreground mt-2">
                            Submitted on {format(parseISO(hw.submittedDate), 'MMM dd, yyyy')}
                          </div>
                        )}
                      </div>
                    </div>
                    {hw.grade && (
                      <Badge variant="default" className="bg-green-600">
                        Grade: {hw.grade}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>

        <TabsContent value="late" className="space-y-3">
          {lateHomework.map((hw) => {
            const subject = subjects.find(s => s.id === hw.subject);

            return (
              <Card 
                key={hw.id}
                className="cursor-pointer hover:shadow-md transition-shadow border-red-200 dark:border-red-900"
                onClick={() => setSelectedHomework(hw.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 bg-red-100 dark:bg-red-950"
                      >
                        <XCircle className="h-5 w-5 text-red-600" />
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold">{hw.title}</div>
                        <div className="text-sm text-muted-foreground mt-1">{subject?.name}</div>
                        <div className="text-xs text-red-600 mt-2">
                          Was due on {format(parseISO(hw.dueDate), 'MMM dd, yyyy')}
                        </div>
                      </div>
                    </div>
                    <Badge variant="destructive">Late</Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>
      </Tabs>
    </div>
  );
}
