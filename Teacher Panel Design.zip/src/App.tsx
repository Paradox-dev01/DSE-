import { useState } from 'react';
import { ThemeProvider } from './lib/theme-context';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ContextPanel } from './components/ContextPanel';
import { Dashboard } from './components/screens/Dashboard';
import { MyClasses } from './components/screens/MyClasses';
import { Attendance } from './components/screens/Attendance';
import { Homework } from './components/screens/Homework';
import { ExamsMarks } from './components/screens/ExamsMarks';
import { Students } from './components/screens/Students';
import { Communication } from './components/screens/Communication';
import { 
  Planner, 
  Reports, 
  Leave, 
  Resources, 
  Help, 
  Shortcuts 
} from './components/screens/SimpleScreens';
import { Toaster } from './components/ui/sonner';
import { todayClasses } from './lib/mock-data';

export default function App() {
  const [activeView, setActiveView] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const activeClass = todayClasses.find(c => c.status === 'active');
  const activeClassString = activeClass 
    ? `${activeClass.className} – ${activeClass.subject} – Period ${activeClass.period}`
    : undefined;

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard onNavigate={setActiveView} />;
      case 'classes':
        return <MyClasses onNavigate={setActiveView} />;
      case 'attendance':
        return <Attendance />;
      case 'homework':
        return <Homework />;
      case 'exams':
        return <ExamsMarks />;
      case 'students':
        return <Students />;
      case 'communication':
        return <Communication />;
      case 'planner':
        return <Planner />;
      case 'reports':
        return <Reports />;
      case 'leave':
        return <Leave />;
      case 'resources':
        return <Resources />;
      case 'help':
        return <Help />;
      case 'shortcuts':
        return <Shortcuts />;
      default:
        return <Dashboard onNavigate={setActiveView} />;
    }
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <Header activeClass={activeClassString} />
        <div className="flex">
          <Sidebar
            activeView={activeView}
            onNavigate={setActiveView}
            collapsed={sidebarCollapsed}
          />
          <main className="flex-1 p-6 overflow-auto">
            <div className="max-w-7xl mx-auto">
              {renderView()}
            </div>
          </main>
          <ContextPanel />
        </div>
        <Toaster position="top-right" />
      </div>
    </ThemeProvider>
  );
}
