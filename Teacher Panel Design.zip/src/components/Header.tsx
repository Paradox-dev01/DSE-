import { Bell, Search, MessageSquare, User, LogOut, Settings, Calendar, Moon, Sun } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { currentTeacher, academicYear } from '../lib/mock-data';
import { useTheme } from '../lib/theme-context';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';

interface HeaderProps {
  activeClass?: string;
}

export function Header({ activeClass }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const currentTime = new Date().toLocaleString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white dark:bg-gray-900 dark:border-gray-800">
      <div className="flex h-16 items-center gap-4 px-6">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#2563EB] text-white">
            <span className="font-bold">TP</span>
          </div>
          <div className="hidden md:block">
            <div className="text-sm font-semibold text-gray-900 dark:text-white">Teacher Panel</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">{academicYear}</div>
          </div>
        </div>

        {/* Date & Time */}
        <div className="hidden lg:flex flex-col ml-4">
          <div className="text-xs text-gray-500 dark:text-gray-400">{currentTime}</div>
        </div>

        {/* Active Class Indicator */}
        {activeClass && (
          <div className="hidden md:flex items-center gap-2 ml-4 px-3 py-1.5 bg-[#2563EB]/10 dark:bg-[#2563EB]/20 rounded-lg border border-[#2563EB]/20">
            <div className="h-2 w-2 rounded-full bg-[#16A34A] animate-pulse"></div>
            <span className="text-sm font-medium text-[#2563EB] dark:text-blue-400">{activeClass}</span>
          </div>
        )}

        {/* Search */}
        <div className="flex-1 max-w-md mx-4">
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search students, classes, messages..."
              className="pl-9 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
            />
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="text-gray-600 dark:text-gray-300"
          >
            {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </Button>

          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative text-gray-600 dark:text-gray-300">
            <Bell className="h-5 w-5" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-[#DC2626]">
              3
            </Badge>
          </Button>

          {/* Messages */}
          <Button variant="ghost" size="icon" className="relative text-gray-600 dark:text-gray-300">
            <MessageSquare className="h-5 w-5" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-[#2563EB]">
              2
            </Badge>
          </Button>

          {/* Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={currentTeacher.avatar} alt={currentTeacher.name} />
                  <AvatarFallback>{currentTeacher.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <span className="hidden md:inline text-sm font-medium text-gray-700 dark:text-gray-300">
                  {currentTeacher.name}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="px-2 py-1.5">
                <p className="text-sm font-medium">{currentTeacher.name}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{currentTeacher.email}</p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                My Profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Calendar className="mr-2 h-4 w-4" />
                My Timetable
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600 dark:text-red-400">
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
