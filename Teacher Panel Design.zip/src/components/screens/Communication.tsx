import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Send, Paperclip, Mic, Users, User, Bell } from 'lucide-react';
import { chatMessages, students, currentTeacher } from '../../lib/mock-data';
import { toast } from 'sonner@2.0.3';
import { ScrollArea } from '../ui/scroll-area';

export function Communication() {
  const [activeTab, setActiveTab] = useState('class');
  const [message, setMessage] = useState('');

  const handleSendMessage = () => {
    if (message.trim()) {
      toast.success('Message sent successfully!');
      setMessage('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Communication Center</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Connect with students, parents, and staff
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="class">Class</TabsTrigger>
          <TabsTrigger value="students">Students</TabsTrigger>
          <TabsTrigger value="parents">Parents</TabsTrigger>
          <TabsTrigger value="teachers">Teachers</TabsTrigger>
          <TabsTrigger value="authority">Authority</TabsTrigger>
          <TabsTrigger value="announcements">Announce</TabsTrigger>
        </TabsList>

        {/* Class Chat */}
        <TabsContent value="class" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Class List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">My Classes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {['7B', '8A', '9C'].map((cls) => (
                    <Button
                      key={cls}
                      variant="outline"
                      className="w-full justify-start"
                    >
                      <Users className="mr-2 h-4 w-4" />
                      Class {cls}
                      <Badge className="ml-auto">2</Badge>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Chat Area */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Class 7B - Mathematics</CardTitle>
                  <Badge className="bg-[#16A34A]">32 students</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 pr-4">
                  <div className="space-y-4">
                    {chatMessages.class.map((msg) => {
                      const isTeacher = msg.senderType === 'teacher';
                      return (
                        <div
                          key={msg.id}
                          className={`flex gap-3 ${isTeacher ? 'flex-row-reverse' : ''}`}
                        >
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={isTeacher ? currentTeacher.avatar : students[0]?.avatar} />
                            <AvatarFallback>{msg.sender[0]}</AvatarFallback>
                          </Avatar>
                          <div className={`flex-1 ${isTeacher ? 'text-right' : ''}`}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium text-gray-900 dark:text-white">
                                {msg.sender}
                              </span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                {msg.timestamp}
                              </span>
                            </div>
                            <div
                              className={`inline-block p-3 rounded-lg ${
                                isTeacher
                                  ? 'bg-[#2563EB] text-white'
                                  : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
                              }`}
                            >
                              {msg.message}
                            </div>
                            {msg.readBy && (
                              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                Read by {msg.readBy} students
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>

                {/* Message Input */}
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" size="icon">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <Mic className="h-4 w-4" />
                  </Button>
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button className="bg-[#2563EB]" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Students Chat */}
        <TabsContent value="students" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Students</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {students.slice(0, 5).map((student) => (
                    <Button
                      key={student.id}
                      variant="outline"
                      className="w-full justify-start"
                    >
                      <Avatar className="h-6 w-6 mr-2">
                        <AvatarImage src={student.avatar} alt={student.name} />
                        <AvatarFallback>{student.name[0]}</AvatarFallback>
                      </Avatar>
                      {student.name}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-base">Select a student to start chatting</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-96 flex items-center justify-center text-gray-500 dark:text-gray-400">
                  <User className="h-12 w-12 mb-2" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Parents Chat */}
        <TabsContent value="parents" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Parents / Guardians</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {students.slice(0, 5).map((student) => (
                    <Button
                      key={student.id}
                      variant="outline"
                      className="w-full justify-start text-left"
                    >
                      <div className="flex-1">
                        <p className="font-medium">{student.guardianName}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Parent of {student.name}
                        </p>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-base">Maria Martinez</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 pr-4">
                  <div className="space-y-4">
                    {chatMessages.parent.map((msg) => {
                      const isTeacher = msg.senderType === 'teacher';
                      return (
                        <div
                          key={msg.id}
                          className={`flex gap-3 ${isTeacher ? 'flex-row-reverse' : ''}`}
                        >
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={isTeacher ? currentTeacher.avatar : undefined} />
                            <AvatarFallback>{msg.sender[0]}</AvatarFallback>
                          </Avatar>
                          <div className={`flex-1 ${isTeacher ? 'text-right' : ''}`}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium text-gray-900 dark:text-white">
                                {msg.sender}
                              </span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                {msg.timestamp}
                              </span>
                            </div>
                            <div
                              className={`inline-block p-3 rounded-lg ${
                                isTeacher
                                  ? 'bg-[#2563EB] text-white'
                                  : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
                              }`}
                            >
                              {msg.message}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>

                <div className="mt-4 flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button className="bg-[#2563EB]" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Teachers Chat */}
        <TabsContent value="teachers" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Teacher Colleagues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { name: 'Prof. Michael Chen', subject: 'Physics', status: 'online' },
                    { name: 'Dr. Emily Watson', subject: 'Chemistry', status: 'online' },
                    { name: 'Mr. James Miller', subject: 'English', status: 'offline' },
                    { name: 'Ms. Patricia Davis', subject: 'History', status: 'online' },
                    { name: 'Dr. Robert Kumar', subject: 'Biology', status: 'away' }
                  ].map((teacher, idx) => (
                    <Button
                      key={idx}
                      variant="outline"
                      className="w-full justify-start text-left"
                    >
                      <Avatar className="h-8 w-8 mr-2">
                        <AvatarFallback>{teacher.name.split(' ')[1][0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{teacher.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{teacher.subject}</p>
                      </div>
                      <div className={`h-2 w-2 rounded-full ${
                        teacher.status === 'online' ? 'bg-[#16A34A]' :
                        teacher.status === 'away' ? 'bg-[#F59E0B]' :
                        'bg-gray-400'
                      }`} />
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>MC</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-base">Prof. Michael Chen</CardTitle>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Physics Department</p>
                  </div>
                  <div className="h-2 w-2 rounded-full bg-[#16A34A]" />
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 pr-4">
                  <div className="space-y-4">
                    <div className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>MC</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            Prof. Michael Chen
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            10:30 AM
                          </span>
                        </div>
                        <div className="inline-block p-3 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white">
                          Hi Sarah! Do you have the lab schedule for next week?
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-3 flex-row-reverse">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={currentTeacher.avatar} />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 text-right">
                        <div className="flex items-center gap-2 mb-1 justify-end">
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            10:35 AM
                          </span>
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            You
                          </span>
                        </div>
                        <div className="inline-block p-3 rounded-lg bg-[#2563EB] text-white">
                          Yes! I'll share it with you in a moment. We have Lab 2 booked for Tuesday and Thursday.
                        </div>
                      </div>
                    </div>
                  </div>
                </ScrollArea>

                <div className="mt-4 flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button className="bg-[#2563EB]" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Authority Chat */}
        <TabsContent value="authority" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">School Administration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { name: 'Principal Office', role: 'Principal', status: 'online' },
                    { name: 'Vice Principal', role: 'Administration', status: 'online' },
                    { name: 'Academic Head', role: 'Academics', status: 'away' },
                    { name: 'Examination Cell', role: 'Examinations', status: 'online' },
                    { name: 'HR Department', role: 'Human Resources', status: 'offline' }
                  ].map((authority, idx) => (
                    <Button
                      key={idx}
                      variant="outline"
                      className="w-full justify-start text-left"
                    >
                      <Avatar className="h-8 w-8 mr-2">
                        <AvatarFallback>{authority.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{authority.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{authority.role}</p>
                      </div>
                      <div className={`h-2 w-2 rounded-full ${
                        authority.status === 'online' ? 'bg-[#16A34A]' :
                        authority.status === 'away' ? 'bg-[#F59E0B]' :
                        'bg-gray-400'
                      }`} />
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>PO</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-base">Principal Office</CardTitle>
                    <p className="text-xs text-gray-500 dark:text-gray-400">School Administration</p>
                  </div>
                  <div className="h-2 w-2 rounded-full bg-[#16A34A]" />
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 pr-4">
                  <div className="space-y-4">
                    <div className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>PO</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            Principal Office
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            Yesterday
                          </span>
                        </div>
                        <div className="inline-block p-3 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white">
                          Reminder: Faculty meeting scheduled for tomorrow at 3 PM in the conference room. Please confirm your attendance.
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-3 flex-row-reverse">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={currentTeacher.avatar} />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 text-right">
                        <div className="flex items-center gap-2 mb-1 justify-end">
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            Yesterday
                          </span>
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            You
                          </span>
                        </div>
                        <div className="inline-block p-3 rounded-lg bg-[#2563EB] text-white">
                          Confirmed. I'll be there at 3 PM. Thank you for the reminder.
                        </div>
                      </div>
                    </div>
                  </div>
                </ScrollArea>

                <div className="mt-4 flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button className="bg-[#2563EB]" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Announcements */}
        <TabsContent value="announcements" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Create Announcement</CardTitle>
                <Button className="bg-[#2563EB]">
                  <Bell className="mr-2 h-4 w-4" />
                  Send Announcement
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                    To
                  </label>
                  <div className="flex gap-2">
                    <Button variant="outline">All Classes</Button>
                    <Button variant="outline">Class 7B</Button>
                    <Button variant="outline">Class 8A</Button>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                    Title
                  </label>
                  <Input placeholder="Announcement title..." />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                    Message
                  </label>
                  <Textarea
                    placeholder="Type your announcement message..."
                    rows={6}
                  />
                </div>
                <div>
                  <Button variant="outline">
                    <Paperclip className="mr-2 h-4 w-4" />
                    Attach Files
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}