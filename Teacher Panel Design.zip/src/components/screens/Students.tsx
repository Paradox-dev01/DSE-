import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../ui/sheet';
import { Search, Phone, Mail, AlertTriangle, MessageCircle, Calendar } from 'lucide-react';
import { students } from '../../lib/mock-data';
import { Progress } from '../ui/progress';

export function Students() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<number | null>(null);

  const filteredStudents = students.filter(s =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.rollNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.class.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const student = students.find(s => s.id === selectedStudent);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Students Directory</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          View and manage student information
        </p>
      </div>

      {/* Search & Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by name, roll number, or class..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline">Filters</Button>
          </div>
        </CardContent>
      </Card>

      {/* Students Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStudents.map((student) => (
          <Card
            key={student.id}
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => setSelectedStudent(student.id)}
          >
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={student.avatar} alt={student.name} />
                  <AvatarFallback>{student.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 dark:text-white">{student.name}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{student.rollNo}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline">{student.class}</Badge>
                    <Badge
                      variant={
                        student.performance === 'excellent'
                          ? 'default'
                          : student.performance === 'good'
                          ? 'secondary'
                          : 'destructive'
                      }
                      className={student.performance === 'excellent' ? 'bg-[#16A34A]' : ''}
                    >
                      {student.performance}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <div>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-gray-600 dark:text-gray-400">Attendance</span>
                    <span
                      className={`font-medium ${
                        student.attendance >= 90
                          ? 'text-[#16A34A]'
                          : student.attendance >= 75
                          ? 'text-[#F59E0B]'
                          : 'text-[#DC2626]'
                      }`}
                    >
                      {student.attendance}%
                    </span>
                  </div>
                  <Progress value={student.attendance} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Student Profile Drawer */}
      <Sheet open={selectedStudent !== null} onOpenChange={() => setSelectedStudent(null)}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          {student && (
            <>
              <SheetHeader>
                <SheetTitle>Student Profile</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-6">
                {/* Student Info */}
                <div className="flex items-start gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={student.avatar} alt={student.name} />
                    <AvatarFallback>{student.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                      {student.name}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">{student.rollNo}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline">{student.class}</Badge>
                      <Badge
                        variant={
                          student.performance === 'excellent'
                            ? 'default'
                            : student.performance === 'good'
                            ? 'secondary'
                            : 'destructive'
                        }
                        className={student.performance === 'excellent' ? 'bg-[#16A34A]' : ''}
                      >
                        {student.performance}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-gray-600 dark:text-gray-400">Attendance</p>
                      <p
                        className={`text-2xl font-bold mt-1 ${
                          student.attendance >= 90
                            ? 'text-[#16A34A]'
                            : student.attendance >= 75
                            ? 'text-[#F59E0B]'
                            : 'text-[#DC2626]'
                        }`}
                      >
                        {student.attendance}%
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-gray-600 dark:text-gray-400">Performance</p>
                      <p className="text-2xl font-bold mt-1 capitalize text-gray-900 dark:text-white">
                        {student.performance}
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Guardian Info */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Guardian Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Name</p>
                      <p className="font-medium text-gray-900 dark:text-white">{student.guardianName}</p>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <span className="text-gray-900 dark:text-white">{student.guardianPhone}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span className="text-gray-900 dark:text-white">{student.guardianEmail}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Attendance Chart Placeholder */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Attendance Trend</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-48 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <p className="text-gray-500 dark:text-gray-400">Attendance chart visualization</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Marks Graph Placeholder */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Performance Graph</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-48 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <p className="text-gray-500 dark:text-gray-400">Marks graph visualization</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button className="flex-1 bg-[#2563EB]">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Contact Guardian
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <Calendar className="mr-2 h-4 w-4" />
                    Schedule Meeting
                  </Button>
                </div>
                {student.performance === 'weak' && (
                  <Button variant="outline" className="w-full border-[#DC2626] text-[#DC2626]">
                    <AlertTriangle className="mr-2 h-4 w-4" />
                    Flag for Attention
                  </Button>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
