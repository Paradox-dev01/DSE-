import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Calendar, BarChart3, FileText, HelpCircle, Keyboard } from 'lucide-react';

export function Planner() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Planner</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Manage your schedule and plan lessons
        </p>
      </div>
      <Card>
        <CardContent className="pt-6">
          <div className="h-96 flex flex-col items-center justify-center text-gray-500 dark:text-gray-400">
            <Calendar className="h-16 w-16 mb-4" />
            <p className="text-lg font-medium">Calendar View</p>
            <p className="text-sm mt-2">View classes, exams, homework deadlines, and meetings</p>
            <Button className="mt-4 bg-[#2563EB]">Open Calendar</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function Reports() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Reports</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          View analytics and generate reports
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Class Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">Performance chart</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Attendance Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">Attendance chart</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Homework Completion</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">Completion chart</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Export Options</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button className="w-full" variant="outline">Export as PDF</Button>
              <Button className="w-full" variant="outline">Export as Excel</Button>
              <Button className="w-full" variant="outline">Export as CSV</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export function Leave() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Leave & Substitution</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Apply for leave and manage substitutions
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Apply for Leave</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                Leave Type
              </label>
              <select className="w-full p-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700">
                <option>Sick Leave</option>
                <option>Personal Leave</option>
                <option>Emergency Leave</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                  From Date
                </label>
                <input type="date" className="w-full p-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                  To Date
                </label>
                <input type="date" className="w-full p-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                Reason
              </label>
              <textarea 
                rows={4}
                className="w-full p-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700"
                placeholder="Enter reason for leave..."
              />
            </div>
            <Button className="w-full bg-[#2563EB]">
              <FileText className="mr-2 h-4 w-4" />
              Submit Leave Request
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function Resources() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Resources</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Access and manage teaching resources
        </p>
      </div>
      <Card>
        <CardContent className="pt-6">
          <div className="h-96 flex flex-col items-center justify-center text-gray-500 dark:text-gray-400">
            <FileText className="h-16 w-16 mb-4" />
            <p className="text-lg font-medium">Resource Library</p>
            <p className="text-sm mt-2">Upload and access teaching materials</p>
            <Button className="mt-4 bg-[#2563EB]">Browse Resources</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function Help() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Help Center</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Get help and support
        </p>
      </div>
      <Card>
        <CardContent className="pt-6">
          <div className="h-96 flex flex-col items-center justify-center text-gray-500 dark:text-gray-400">
            <HelpCircle className="h-16 w-16 mb-4" />
            <p className="text-lg font-medium">Help & Support</p>
            <p className="text-sm mt-2">Browse FAQs and contact support</p>
            <Button className="mt-4 bg-[#2563EB]">View Help Articles</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function Shortcuts() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Keyboard Shortcuts</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Learn keyboard shortcuts to work faster
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Attendance Shortcuts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <span className="text-gray-900 dark:text-white">Mark Present</span>
              <kbd className="px-3 py-1 bg-white dark:bg-gray-900 border rounded font-mono text-sm">P</kbd>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <span className="text-gray-900 dark:text-white">Mark Absent</span>
              <kbd className="px-3 py-1 bg-white dark:bg-gray-900 border rounded font-mono text-sm">A</kbd>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <span className="text-gray-900 dark:text-white">Mark Late</span>
              <kbd className="px-3 py-1 bg-white dark:bg-gray-900 border rounded font-mono text-sm">L</kbd>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <span className="text-gray-900 dark:text-white">Mark Excused</span>
              <kbd className="px-3 py-1 bg-white dark:bg-gray-900 border rounded font-mono text-sm">E</kbd>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
