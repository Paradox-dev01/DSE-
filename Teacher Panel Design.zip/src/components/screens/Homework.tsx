import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Progress } from '../ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Plus, Upload, Calendar, CheckCircle2, Clock, XCircle } from 'lucide-react';
import { pendingHomework, homeworkSubmissions, students } from '../../lib/mock-data';
import { toast } from 'sonner@2.0.3';

export function Homework() {
  const [selectedHomework, setSelectedHomework] = useState<number | null>(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  const handleCreateHomework = () => {
    toast.success('Homework created successfully! Students have been notified.');
    setCreateDialogOpen(false);
  };

  const handleGradeSubmission = (studentId: number, score: number) => {
    toast.success('Grade published successfully!');
  };

  if (selectedHomework) {
    const homework = pendingHomework.find(h => h.id === selectedHomework);
    
    return (
      <div className="space-y-6">
        {/* Back Button */}
        <Button variant="outline" onClick={() => setSelectedHomework(null)}>
          ← Back to Homework List
        </Button>

        {/* Header */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
                  {homework?.title}
                </h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  {homework?.class} • {homework?.subject}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600 dark:text-gray-400">Due Date</p>
                <p className="font-medium text-gray-900 dark:text-white">{homework?.dueDate}</p>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm text-gray-600 dark:text-gray-400">Submission Progress</span>
                <span className="text-sm font-medium">{homework?.submitted}/{homework?.total}</span>
              </div>
              <Progress value={((homework?.submitted || 0) / (homework?.total || 1)) * 100} />
            </div>
          </CardContent>
        </Card>

        {/* Submissions */}
        <Card>
          <CardHeader>
            <CardTitle>Student Submissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {homeworkSubmissions.map((submission) => {
                const student = students.find(s => s.id === submission.studentId);
                return (
                  <div
                    key={submission.studentId}
                    className="p-4 rounded-lg border dark:border-gray-700 bg-white dark:bg-gray-800"
                  >
                    <div className="flex items-start gap-4">
                      <Avatar>
                        <AvatarImage src={student?.avatar} alt={student?.name} />
                        <AvatarFallback>{student?.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium text-gray-900 dark:text-white">{student?.name}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{student?.rollNo}</p>
                          </div>
                          <Badge
                            variant={
                              submission.status === 'graded'
                                ? 'default'
                                : submission.status === 'submitted'
                                ? 'secondary'
                                : 'outline'
                            }
                            className={
                              submission.status === 'graded' ? 'bg-[#16A34A]' :
                              submission.status === 'submitted' ? 'bg-[#2563EB]' : ''
                            }
                          >
                            {submission.status === 'graded' && <CheckCircle2 className="mr-1 h-3 w-3" />}
                            {submission.status === 'submitted' && <Clock className="mr-1 h-3 w-3" />}
                            {submission.status === 'pending' && <XCircle className="mr-1 h-3 w-3" />}
                            {submission.status}
                          </Badge>
                        </div>
                        {submission.status !== 'pending' && (
                          <div className="mt-3">
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Submitted: {submission.submittedAt}
                            </p>
                            {submission.files.length > 0 && (
                              <div className="mt-2">
                                {submission.files.map((file, idx) => (
                                  <Button key={idx} variant="outline" size="sm" className="mr-2">
                                    📄 {file}
                                  </Button>
                                ))}
                              </div>
                            )}
                            {submission.status === 'submitted' && (
                              <div className="mt-3 flex gap-2">
                                <Input
                                  type="number"
                                  placeholder="Score"
                                  className="w-24"
                                  max={100}
                                />
                                <Button 
                                  size="sm" 
                                  className="bg-[#16A34A]"
                                  onClick={() => handleGradeSubmission(submission.studentId, 85)}
                                >
                                  Publish Grade
                                </Button>
                              </div>
                            )}
                            {submission.status === 'graded' && (
                              <div className="mt-2">
                                <Badge className="bg-[#16A34A]">Score: {submission.score}/100</Badge>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Homework & Assignments</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Create and manage homework assignments
          </p>
        </div>
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#2563EB]">
              <Plus className="mr-2 h-4 w-4" />
              Create Assignment
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Assignment</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Title</Label>
                <Input placeholder="e.g., Algebra: Linear Equations" />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea 
                  placeholder="Assignment instructions and requirements..."
                  rows={4}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Class</Label>
                  <Input placeholder="7B" />
                </div>
                <div>
                  <Label>Subject</Label>
                  <Input placeholder="Mathematics" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Due Date</Label>
                  <Input type="date" />
                </div>
                <div>
                  <Label>Total Marks</Label>
                  <Input type="number" placeholder="100" />
                </div>
              </div>
              <div>
                <Label>Attach Files</Label>
                <Button variant="outline" className="w-full">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Files
                </Button>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button className="bg-[#2563EB]" onClick={handleCreateHomework}>
                  Create & Publish
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Homework List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {pendingHomework.map((hw) => (
          <Card 
            key={hw.id} 
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => setSelectedHomework(hw.id)}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{hw.title}</CardTitle>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {hw.class} • {hw.subject}
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Submissions</span>
                    <span className="text-sm font-medium">
                      {hw.submitted}/{hw.total}
                    </span>
                  </div>
                  <Progress value={(hw.submitted / hw.total) * 100} />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                    <Calendar className="h-4 w-4" />
                    <span>Due: {hw.dueDate}</span>
                  </div>
                  {hw.pending > 0 && (
                    <Badge variant="outline" className="text-[#F59E0B] border-[#F59E0B]">
                      {hw.pending} pending
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
