import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Save, Lock, Upload } from 'lucide-react';
import { students, upcomingExams } from '../../lib/mock-data';
import { toast } from 'sonner@2.0.3';

export function ExamsMarks() {
  const [selectedExam, setSelectedExam] = useState<number | null>(null);
  const [marks, setMarks] = useState<Record<number, string>>({});
  const [isLocked, setIsLocked] = useState(false);

  const handleMarkChange = (studentId: number, value: string) => {
    if (!isLocked) {
      setMarks(prev => ({ ...prev, [studentId]: value }));
    }
  };

  const handleSave = () => {
    toast.success('Marks saved as draft. Auto-saving enabled.');
  };

  const handleSubmit = () => {
    setIsLocked(true);
    toast.success('Marks submitted successfully! Sent to admin for approval.');
  };

  const exam = upcomingExams.find(e => e.id === selectedExam);
  const examStudents = exam ? students.filter(s => s.class === exam.class) : [];

  if (selectedExam && exam) {
    return (
      <div className="space-y-6">
        {/* Back Button */}
        <Button variant="outline" onClick={() => setSelectedExam(null)}>
          ← Back to Exams List
        </Button>

        {/* Exam Header */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
                  {exam.name} - {exam.subject}
                </h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  {exam.class} • {exam.date} • {exam.totalMarks} marks
                </p>
              </div>
              {isLocked && (
                <Badge variant="secondary" className="bg-gray-500">
                  <Lock className="mr-1 h-3 w-3" />
                  Locked
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Entry Grid */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Enter Marks</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline">
                  <Upload className="mr-2 h-4 w-4" />
                  Bulk Upload
                </Button>
                {!isLocked && (
                  <>
                    <Button variant="outline" onClick={handleSave}>
                      <Save className="mr-2 h-4 w-4" />
                      Save Draft
                    </Button>
                    <Button className="bg-[#16A34A]" onClick={handleSubmit}>
                      <Lock className="mr-2 h-4 w-4" />
                      Submit & Lock
                    </Button>
                  </>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-20">Roll No</TableHead>
                    <TableHead>Student Name</TableHead>
                    <TableHead className="w-32">Marks Obtained</TableHead>
                    <TableHead className="w-32">Total Marks</TableHead>
                    <TableHead className="w-32">Percentage</TableHead>
                    <TableHead className="w-24">Grade</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {examStudents.map((student) => {
                    const obtainedMarks = marks[student.id] ? parseInt(marks[student.id]) : 0;
                    const percentage = (obtainedMarks / exam.totalMarks) * 100;
                    const grade =
                      percentage >= 90 ? 'A+' :
                      percentage >= 80 ? 'A' :
                      percentage >= 70 ? 'B' :
                      percentage >= 60 ? 'C' :
                      percentage >= 50 ? 'D' : 'F';

                    return (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.rollNo}</TableCell>
                        <TableCell>{student.name}</TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min="0"
                            max={exam.totalMarks}
                            value={marks[student.id] || ''}
                            onChange={(e) => handleMarkChange(student.id, e.target.value)}
                            disabled={isLocked}
                            className="w-24"
                            placeholder="0"
                          />
                        </TableCell>
                        <TableCell>{exam.totalMarks}</TableCell>
                        <TableCell>
                          {marks[student.id] ? (
                            <span className={
                              percentage >= 90 ? 'text-[#16A34A]' :
                              percentage >= 75 ? 'text-[#2563EB]' :
                              percentage >= 60 ? 'text-[#F59E0B]' :
                              'text-[#DC2626]'
                            }>
                              {percentage.toFixed(1)}%
                            </span>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {marks[student.id] ? (
                            <Badge
                              variant={
                                grade === 'A+' || grade === 'A' ? 'default' :
                                grade === 'B' || grade === 'C' ? 'secondary' :
                                'destructive'
                              }
                              className={grade === 'A+' || grade === 'A' ? 'bg-[#16A34A]' : ''}
                            >
                              {grade}
                            </Badge>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
              💡 Tip: Use Tab key to navigate between cells. Changes are auto-saved every 3 seconds.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Exams & Marks</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Enter and manage examination marks
        </p>
      </div>

      {/* Exams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {upcomingExams.map((exam) => (
          <Card
            key={exam.id}
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => setSelectedExam(exam.id)}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{exam.name}</CardTitle>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {exam.subject} • {exam.class}
                  </p>
                </div>
                <Badge variant="outline">Upcoming</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center justify-between">
                  <span>Date:</span>
                  <span className="font-medium text-gray-900 dark:text-white">{exam.date}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Duration:</span>
                  <span className="font-medium text-gray-900 dark:text-white">{exam.duration}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Total Marks:</span>
                  <span className="font-medium text-gray-900 dark:text-white">{exam.totalMarks}</span>
                </div>
              </div>
              <Button className="w-full mt-4 bg-[#2563EB]">
                Enter Marks
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
