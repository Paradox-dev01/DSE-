import {
  LayoutDashboard,
  BookOpen,
  ClipboardCheck,
  BookMarked,
  GraduationCap,
  Users,
  MessageCircle,
  FolderOpen,
  BarChart3,
  CalendarDays,
  FileText,
  HelpCircle,
  Keyboard,
  ChevronRight
} from 'lucide-react';
import { cn } from './ui/utils';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  collapsed?: boolean;
}

const navigation = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'classes', label: 'My Classes', icon: BookOpen },
  { id: 'attendance', label: 'Attendance', icon: ClipboardCheck },
  { id: 'homework', label: 'Homework & Assignments', icon: BookMarked },
  { id: 'exams', label: 'Exams & Marks', icon: GraduationCap },
  { id: 'students', label: 'Students', icon: Users },
  { id: 'communication', label: 'Communication', icon: MessageCircle },
  { id: 'resources', label: 'Resources', icon: FolderOpen },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
  { id: 'planner', label: 'Planner', icon: CalendarDays },
  { id: 'leave', label: 'Leave & Substitution', icon: FileText },
];

const bottomNavigation = [
  { id: 'help', label: 'Help', icon: HelpCircle },
  { id: 'shortcuts', label: 'Shortcuts Guide', icon: Keyboard },
];

export function Sidebar({ activeView, onNavigate, collapsed = false }: SidebarProps) {
  return (
    <aside
      className={cn(
        "border-r bg-white dark:bg-gray-900 dark:border-gray-800 transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
    >
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <div className="flex flex-col h-full">
          {/* Primary Navigation */}
          <nav className="flex-1 p-3 space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <Button
                  key={item.id}
                  variant={isActive ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-3 transition-colors",
                    isActive
                      ? "bg-[#2563EB] text-white hover:bg-[#2563EB]/90"
                      : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800",
                    collapsed && "justify-center px-2"
                  )}
                  onClick={() => onNavigate(item.id)}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  {!collapsed && (
                    <>
                      <span className="flex-1 text-left">{item.label}</span>
                      {isActive && <ChevronRight className="h-4 w-4" />}
                    </>
                  )}
                </Button>
              );
            })}
          </nav>

          {/* Bottom Navigation */}
          <div className="p-3 border-t dark:border-gray-800">
            <Separator className="mb-3" />
            {bottomNavigation.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  className={cn(
                    "w-full justify-start gap-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800",
                    collapsed && "justify-center px-2"
                  )}
                  onClick={() => onNavigate(item.id)}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  {!collapsed && <span className="flex-1 text-left">{item.label}</span>}
                </Button>
              );
            })}
          </div>
        </div>
      </ScrollArea>
    </aside>
  );
}
