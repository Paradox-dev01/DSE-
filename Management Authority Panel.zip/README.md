
  # Management Authority Panel UI/UX

  This is a code bundle for Management Authority Panel UI/UX. The original project is available at https://www.figma.com/design/3PxfReEvkkKc4gaLENv9ca/Management-Authority-Panel-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  