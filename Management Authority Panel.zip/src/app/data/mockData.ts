// Mock data for the Management Panel

export const schoolInfo = {
  name: "St. Xavier's International School",
  logo: "🎓",
  academicYear: "2025-2026",
  status: "Open" as "Open" | "Closed" | "Event Mode",
};

export const dashboardMetrics = {
  totalStudents: 1847,
  totalTeachers: 94,
  attendanceToday: 94.2,
  teachersAbsentToday: 3,
  classesNotConducted: 2,
  weakStudentsAlert: 47,
  feeDefaulters: 23,
  pendingApprovals: 8,
  upcomingExams: 3,
};

export const criticalAlerts = [
  {
    id: 1,
    type: "attendance",
    severity: "high",
    title: "Low Attendance Alert",
    description: "12 students below 75% attendance threshold",
    students: ["Rajesh Kumar (8-A)", "Priya Sharma (9-B)", "Amit Patel (7-C)"],
  },
  {
    id: 2,
    type: "homework",
    severity: "medium",
    title: "Homework Unchecked",
    description: "3 teachers haven't checked homework for 5+ days",
    teachers: ["Mr. Verma (Math)", "Ms. Singh (English)"],
  },
  {
    id: 3,
    type: "marks",
    severity: "high",
    title: "Marks Pending Submission",
    description: "Mid-term marks not submitted by 4 teachers",
    subjects: ["Physics (11-A)", "Chemistry (12-B)"],
  },
  {
    id: 4,
    type: "discipline",
    severity: "critical",
    title: "Open Discipline Cases",
    description: "2 cases require immediate attention",
    cases: ["Fighting incident - Class 10-B", "Repeated absence - Class 8-A"],
  },
  {
    id: 5,
    type: "finance",
    severity: "medium",
    title: "Payment Irregularities",
    description: "5 partial payments need verification",
  },
];

export const students = Array.from({ length: 50 }, (_, i) => {
  const classNum = (i % 5) + 6; // Classes 6-10
  const section = ["A", "B", "C"][i % 3];
  const rollNo = Math.floor(i / 3) + 1;
  
  return {
    id: `STU${1000 + i}`,
    name: `Student ${i + 1}`,
    class: `${classNum}`,
    section: section,
    rollNo: rollNo,
    attendance: 75 + Math.random() * 25,
    performance: ["Excellent", "Good", "Average", "Weak"][Math.floor(Math.random() * 4)],
    feeStatus: Math.random() > 0.8 ? "Due" : "Paid",
    guardianName: `Guardian ${i + 1}`,
    guardianPhone: `+91 98765${43210 + i}`,
    address: `House ${i + 1}, Street ${Math.floor(i / 10) + 1}, City`,
    medicalNotes: i % 5 === 0 ? "Asthma - Keep inhaler" : "",
    incidents: Math.floor(Math.random() * 3),
  };
}).sort((a, b) => {
  // Sort by class first
  if (a.class !== b.class) return parseInt(a.class) - parseInt(b.class);
  // Then by section
  if (a.section !== b.section) return a.section.localeCompare(b.section);
  // Finally by roll number
  return a.rollNo - b.rollNo;
});

export const teachers = Array.from({ length: 30 }, (_, i) => ({
  id: `TCH${2000 + i}`,
  name: `Teacher ${i + 1}`,
  department: ["Science", "Mathematics", "Languages", "Social Studies", "Arts"][Math.floor(Math.random() * 5)],
  subjects: ["Physics", "Chemistry", "Math", "English", "History"][Math.floor(Math.random() * 5)],
  classesAssigned: Math.floor(Math.random() * 4) + 2,
  attendance: 85 + Math.random() * 15,
  syllabusCoverage: 60 + Math.random() * 40,
  homeworkCheckingRate: 80 + Math.random() * 20,
  parentFeedbackScore: 3.5 + Math.random() * 1.5,
  phone: `+91 99876${54321 + i}`,
  email: `teacher${i + 1}@school.edu`,
}));

export const financeData = {
  monthlyCollection: 2847500,
  outstandingDues: 567800,
  revenueVsExpense: {
    revenue: 3200000,
    expense: 2650000,
  },
  salaryTotal: 1840000,
  feeWaiverPending: 3,
  scholarshipPending: 2,
  refundPending: 1,
};

export const admissions = Array.from({ length: 15 }, (_, i) => ({
  id: `ADM${3000 + i}`,
  studentName: `Applicant ${i + 1}`,
  class: `${Math.floor(Math.random() * 5) + 6}`,
  applicationDate: new Date(2026, 1, Math.floor(Math.random() * 20) + 1).toLocaleDateString(),
  status: ["Pending", "Under Review", "Interview Scheduled"][Math.floor(Math.random() * 3)],
  testScore: 60 + Math.random() * 40,
  guardianPhone: `+91 98765${43210 + i}`,
}));

export const disciplineCases = [
  {
    id: "DC001",
    studentName: "Rahul Mehta",
    class: "10-B",
    incident: "Fighting with classmate",
    date: "2026-02-20",
    status: "Under Investigation",
    severity: "High",
    guardianContacted: true,
    documents: 2,
  },
  {
    id: "DC002",
    studentName: "Sneha Kapoor",
    class: "8-A",
    incident: "Repeated unauthorized absence",
    date: "2026-02-18",
    status: "Guardian Meeting Scheduled",
    severity: "Medium",
    guardianContacted: true,
    documents: 1,
  },
  {
    id: "DC003",
    studentName: "Vikram Singh",
    class: "9-C",
    incident: "Damage to school property",
    date: "2026-02-15",
    status: "Decision Pending",
    severity: "High",
    guardianContacted: true,
    documents: 3,
  },
];

export const exams = [
  {
    id: "EX001",
    name: "Mid-Term Examination",
    classes: "6-12",
    startDate: "2026-03-15",
    endDate: "2026-03-25",
    status: "Scheduled",
    marksSubmitted: "45%",
  },
  {
    id: "EX002",
    name: "Unit Test 3",
    classes: "6-10",
    startDate: "2026-04-05",
    endDate: "2026-04-10",
    status: "Scheduled",
    marksSubmitted: "0%",
  },
];

export const pendingApprovals = [
  {
    id: "APP001",
    type: "Leave",
    from: "Mr. Verma (Teacher)",
    description: "Medical leave for 3 days",
    date: "2026-02-24",
    urgent: false,
  },
  {
    id: "APP002",
    type: "Fee Waiver",
    from: "Rajesh Kumar (Class 8-A)",
    description: "50% fee waiver request - financial hardship",
    date: "2026-02-23",
    urgent: true,
  },
  {
    id: "APP003",
    type: "Result Publication",
    from: "Exam Controller",
    description: "Publish quarterly exam results",
    date: "2026-02-24",
    urgent: true,
  },
  {
    id: "APP004",
    type: "Timetable Change",
    from: "Academic Coordinator",
    description: "Emergency timetable adjustment for Class 12",
    date: "2026-02-24",
    urgent: false,
  },
];

export const systemLogs = Array.from({ length: 20 }, (_, i) => ({
  id: `LOG${4000 + i}`,
  timestamp: new Date(2026, 1, 24, 14 - i, 30).toLocaleString(),
  user: ["Admin Clerk", "Teacher Portal", "Management", "Finance Dept"][Math.floor(Math.random() * 4)],
  action: ["Updated student record", "Marked attendance", "Approved leave", "Generated report", "Published notice"][Math.floor(Math.random() * 5)],
  category: ["Academic", "Finance", "Attendance", "Discipline", "System"][Math.floor(Math.random() * 5)],
}));