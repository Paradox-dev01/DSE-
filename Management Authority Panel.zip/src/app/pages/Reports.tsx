import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Download, FileText, BarChart3 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from "recharts";
import { BackButton } from "../components/BackButton";

export default function Reports() {
  const attendanceData = [
    { id: "aug", month: "Aug", rate: 92.5 },
    { id: "sep", month: "Sep", rate: 93.2 },
    { id: "oct", month: "Oct", rate: 91.8 },
    { id: "nov", month: "Nov", rate: 94.1 },
    { id: "dec", month: "Dec", rate: 90.5 },
    { id: "jan", month: "Jan", rate: 93.8 },
    { id: "feb", month: "Feb", rate: 94.2 },
  ];

  const performanceData = [
    { id: "class6", class: "6", avg: 78 },
    { id: "class7", class: "7", avg: 82 },
    { id: "class8", class: "8", avg: 75 },
    { id: "class9", class: "9", avg: 81 },
    { id: "class10", class: "10", avg: 79 },
  ];

  const reportCategories = [
    {
      title: "Academic Reports",
      reports: [
        "Class-wise Performance Analysis",
        "Subject Failure Rate Report",
        "GPA Distribution Report",
        "Topper List by Class",
      ],
    },
    {
      title: "Attendance Reports",
      reports: [
        "Chronic Absentee Report",
        "Monthly Attendance Trends",
        "Teacher Attendance Report",
        "Class-wise Attendance Summary",
      ],
    },
    {
      title: "Financial Reports",
      reports: [
        "Fee Collection Trend",
        "Defaulter Breakdown",
        "Revenue vs Expense Analysis",
        "Payment Method Analysis",
      ],
    },
    {
      title: "Teacher Reports",
      reports: [
        "Teacher Performance Matrix",
        "Workload Distribution",
        "Syllabus Coverage Report",
        "Parent Feedback Summary",
      ],
    },
  ];

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Reports & Analytics</h1>
        <p className="text-slate-600 mt-1">
          Comprehensive institutional reports and data analysis
        </p>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Attendance Trend (7 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={attendanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[85, 100]} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="rate" stroke="#3b82f6" name="Attendance %" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Class-wise Average Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="class" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Bar dataKey="avg" fill="#10b981" name="Average Score %" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Report Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {reportCategories.map((category, idx) => (
          <Card key={idx}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="size-5" />
                {category.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {category.reports.map((report, reportIdx) => (
                  <div
                    key={reportIdx}
                    className="flex items-center justify-between p-3 border border-slate-200 rounded-lg hover:bg-slate-50"
                  >
                    <div className="flex items-center gap-2">
                      <FileText className="size-4 text-slate-400" />
                      <span className="text-sm font-medium">{report}</span>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        View
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Download className="size-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle>Export Options</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <Button variant="outline">
              <Download className="size-4 mr-2" />
              Export as PDF
            </Button>
            <Button variant="outline">
              <Download className="size-4 mr-2" />
              Export as Excel
            </Button>
            <Button variant="outline">
              <Download className="size-4 mr-2" />
              Export as CSV
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
