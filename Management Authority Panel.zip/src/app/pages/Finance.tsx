import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { DollarSign, TrendingUp, TrendingDown, AlertCircle } from "lucide-react";
import { financeData, pendingApprovals } from "../data/mockData";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { BackButton } from "../components/BackButton";

export default function Finance() {
  const revenueData = [
    { id: "aug-2025", month: "Aug", revenue: 2950000, expense: 2400000 },
    { id: "sep-2025", month: "Sep", revenue: 3100000, expense: 2500000 },
    { id: "oct-2025", month: "Oct", revenue: 2850000, expense: 2450000 },
    { id: "nov-2025", month: "Nov", revenue: 3200000, expense: 2600000 },
    { id: "dec-2025", month: "Dec", revenue: 3050000, expense: 2550000 },
    { id: "jan-2026", month: "Jan", revenue: 3100000, expense: 2600000 },
    { id: "feb-2026", month: "Feb", revenue: 3200000, expense: 2650000 },
  ];

  const feeCollectionData = [
    { id: "collected", name: "Collected", value: financeData.monthlyCollection },
    { id: "outstanding", name: "Outstanding", value: financeData.outstandingDues },
  ];

  const COLORS = ["#10b981", "#ef4444"];

  const financeApprovals = pendingApprovals.filter(
    (a) => a.type === "Fee Waiver" || a.type.includes("Refund") || a.type.includes("Scholarship")
  );

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Finance Overview</h1>
        <p className="text-slate-600 mt-1">
          Financial monitoring and approval control
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Monthly Collection</p>
                <p className="text-2xl font-bold text-slate-900">
                  ₹{(financeData.monthlyCollection / 100000).toFixed(2)}L
                </p>
              </div>
              <div className="bg-green-100 text-green-600 p-3 rounded-lg">
                <DollarSign className="size-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Outstanding Dues</p>
                <p className="text-2xl font-bold text-red-600">
                  ₹{(financeData.outstandingDues / 100000).toFixed(2)}L
                </p>
              </div>
              <div className="bg-red-100 text-red-600 p-3 rounded-lg">
                <AlertCircle className="size-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Monthly Revenue</p>
                <p className="text-2xl font-bold text-slate-900">
                  ₹{(financeData.revenueVsExpense.revenue / 100000).toFixed(2)}L
                </p>
              </div>
              <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
                <TrendingUp className="size-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Monthly Expense</p>
                <p className="text-2xl font-bold text-slate-900">
                  ₹{(financeData.revenueVsExpense.expense / 100000).toFixed(2)}L
                </p>
              </div>
              <div className="bg-purple-100 text-purple-600 p-3 rounded-lg">
                <TrendingDown className="size-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue vs Expense Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" key="grid" />
                <XAxis dataKey="month" key="xaxis" />
                <YAxis key="yaxis" />
                <Tooltip key="tooltip" />
                <Legend key="legend" />
                <Bar dataKey="revenue" fill="#10b981" name="Revenue" key="revenue-bar" />
                <Bar dataKey="expense" fill="#ef4444" name="Expense" key="expense-bar" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fee Collection Status</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={feeCollectionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ₹${(value / 100000).toFixed(1)}L`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {feeCollectionData.map((entry) => (
                    <Cell key={entry.id} fill={COLORS[entry.id === "collected" ? 0 : 1]} />
                  ))}
                </Pie>
                <Tooltip key="pie-tooltip" />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Pending Financial Approvals */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Pending Financial Approvals</CardTitle>
          <Badge variant="destructive">
            {financeData.feeWaiverPending + financeData.scholarshipPending + financeData.refundPending} Pending
          </Badge>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
              <div>
                <Badge>Fee Waiver</Badge>
                <p className="text-sm font-medium mt-2">
                  {financeData.feeWaiverPending} requests pending approval
                </p>
              </div>
              <Button size="sm">Review</Button>
            </div>
            <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
              <div>
                <Badge>Scholarship</Badge>
                <p className="text-sm font-medium mt-2">
                  {financeData.scholarshipPending} requests pending approval
                </p>
              </div>
              <Button size="sm">Review</Button>
            </div>
            <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
              <div>
                <Badge>Refund</Badge>
                <p className="text-sm font-medium mt-2">
                  {financeData.refundPending} requests pending approval
                </p>
              </div>
              <Button size="sm">Review</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Salary Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Salary Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
            <span className="text-slate-600">Total Monthly Salary Disbursement</span>
            <span className="text-2xl font-bold">
              ₹{(financeData.salaryTotal / 100000).toFixed(2)}L
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
