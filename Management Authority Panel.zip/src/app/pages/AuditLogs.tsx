import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Search, Download, Filter, Eye, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "../components/ui/sheet";
import { ScrollArea } from "../components/ui/scroll-area";
import { BackButton } from "../components/BackButton";

// Mock audit log data
const auditLogs = [
  {
    id: "LOG001",
    timestamp: "2026-02-24 14:30:22",
    user: "Principal Manager",
    action: "Updated Student Record",
    module: "Students",
    details: "Modified attendance for Student STU1005",
    ipAddress: "192.168.1.100",
    status: "success",
  },
  {
    id: "LOG002",
    timestamp: "2026-02-24 13:15:10",
    user: "Admin User",
    action: "Approved Fee Payment",
    module: "Finance",
    details: "Approved payment of ₹25,000 for STU1023",
    ipAddress: "192.168.1.105",
    status: "success",
  },
  {
    id: "LOG003",
    timestamp: "2026-02-24 12:45:33",
    user: "Teacher John Doe",
    action: "Failed Login Attempt",
    module: "Authentication",
    details: "Invalid password - 3 attempts",
    ipAddress: "192.168.1.112",
    status: "failed",
  },
  {
    id: "LOG004",
    timestamp: "2026-02-24 11:20:15",
    user: "Principal Manager",
    action: "Created New User",
    module: "User Management",
    details: "Added new teacher account: teacher@school.edu",
    ipAddress: "192.168.1.100",
    status: "success",
  },
  {
    id: "LOG005",
    timestamp: "2026-02-24 10:30:45",
    user: "Finance Manager",
    action: "Generated Report",
    module: "Reports",
    details: "Monthly finance report for January 2026",
    ipAddress: "192.168.1.108",
    status: "success",
  },
  {
    id: "LOG006",
    timestamp: "2026-02-24 09:15:20",
    user: "Admin User",
    action: "Updated Institution Settings",
    module: "Settings",
    details: "Changed academic year configuration",
    ipAddress: "192.168.1.105",
    status: "success",
  },
  {
    id: "LOG007",
    timestamp: "2026-02-24 08:45:12",
    user: "Teacher Jane Smith",
    action: "Uploaded Marks",
    module: "Academic",
    details: "Uploaded mid-term marks for Class 10-A",
    ipAddress: "192.168.1.115",
    status: "success",
  },
  {
    id: "LOG008",
    timestamp: "2026-02-23 17:30:00",
    user: "System",
    action: "Automated Backup",
    module: "System",
    details: "Daily database backup completed",
    ipAddress: "System",
    status: "success",
  },
  {
    id: "LOG009",
    timestamp: "2026-02-23 16:20:33",
    user: "Principal Manager",
    action: "Deleted Record",
    module: "Students",
    details: "Removed duplicate student entry STU9999",
    ipAddress: "192.168.1.100",
    status: "warning",
  },
  {
    id: "LOG010",
    timestamp: "2026-02-23 15:10:45",
    user: "Admin User",
    action: "Password Reset",
    module: "User Management",
    details: "Reset password for teacher@school.edu",
    ipAddress: "192.168.1.105",
    status: "success",
  },
].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

export default function AuditLogs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [moduleFilter, setModuleFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedLog, setSelectedLog] = useState<typeof auditLogs[0] | null>(null);

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesModule = moduleFilter === "all" || log.module === moduleFilter;
    const matchesStatus = statusFilter === "all" || log.status === statusFilter;
    return matchesSearch && matchesModule && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "success":
        return (
          <Badge className="bg-green-500">
            <CheckCircle className="size-3 mr-1" />
            Success
          </Badge>
        );
      case "failed":
        return (
          <Badge className="bg-red-500">
            <XCircle className="size-3 mr-1" />
            Failed
          </Badge>
        );
      case "warning":
        return (
          <Badge className="bg-yellow-500">
            <AlertCircle className="size-3 mr-1" />
            Warning
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6 bg-background min-h-full">
      {/* Page Header */}
      <BackButton />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">Audit Logs</h1>
          <p className="text-muted-foreground mt-1">
            Complete system activity trail for compliance and security monitoring
          </p>
        </div>
        <Button className="shadow-sm">
          <Download className="size-4 mr-2" />
          Export Logs
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Logs</p>
                <p className="text-2xl font-bold">{auditLogs.length}</p>
              </div>
              <div className="size-12 bg-blue-100 dark:bg-blue-950/30 rounded-lg flex items-center justify-center">
                <Filter className="size-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Success</p>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {auditLogs.filter((l) => l.status === "success").length}
                </p>
              </div>
              <div className="size-12 bg-green-100 dark:bg-green-950/30 rounded-lg flex items-center justify-center">
                <CheckCircle className="size-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Failed</p>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {auditLogs.filter((l) => l.status === "failed").length}
                </p>
              </div>
              <div className="size-12 bg-red-100 dark:bg-red-950/30 rounded-lg flex items-center justify-center">
                <XCircle className="size-6 text-red-600 dark:text-red-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Warnings</p>
                <p className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                  {auditLogs.filter((l) => l.status === "warning").length}
                </p>
              </div>
              <div className="size-12 bg-yellow-100 dark:bg-yellow-950/30 rounded-lg flex items-center justify-center">
                <AlertCircle className="size-6 text-yellow-600 dark:text-yellow-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="shadow-sm">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={moduleFilter} onValueChange={setModuleFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Modules" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Modules</SelectItem>
                <SelectItem value="Students">Students</SelectItem>
                <SelectItem value="Finance">Finance</SelectItem>
                <SelectItem value="Authentication">Authentication</SelectItem>
                <SelectItem value="User Management">User Management</SelectItem>
                <SelectItem value="Reports">Reports</SelectItem>
                <SelectItem value="Settings">Settings</SelectItem>
                <SelectItem value="Academic">Academic</SelectItem>
                <SelectItem value="System">System</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="size-4 mr-2" />
              Advanced Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-foreground">
            {filteredLogs.length} Audit Entries{" "}
            {(searchQuery || moduleFilter !== "all" || statusFilter !== "all") &&
              "(Filtered)"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border border-border rounded-lg overflow-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50 hover:bg-muted/50">
                  <TableHead className="font-semibold">Log ID</TableHead>
                  <TableHead className="font-semibold">Timestamp</TableHead>
                  <TableHead className="font-semibold">User</TableHead>
                  <TableHead className="font-semibold">Action</TableHead>
                  <TableHead className="font-semibold">Module</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow
                    key={log.id}
                    className="hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => setSelectedLog(log)}
                  >
                    <TableCell className="font-medium font-mono text-sm">{log.id}</TableCell>
                    <TableCell className="text-sm">{log.timestamp}</TableCell>
                    <TableCell className="font-medium">{log.user}</TableCell>
                    <TableCell>{log.action}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{log.module}</Badge>
                    </TableCell>
                    <TableCell>{getStatusBadge(log.status)}</TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedLog(log);
                        }}
                        className="hover:bg-accent"
                      >
                        <Eye className="size-4 mr-1" />
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Log Detail Drawer */}
      <Sheet open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <SheetContent className="w-full sm:max-w-2xl">
          {selectedLog && (
            <>
              <SheetHeader>
                <SheetTitle className="text-2xl">Audit Log Details</SheetTitle>
                <SheetDescription>{selectedLog.id}</SheetDescription>
              </SheetHeader>

              <ScrollArea className="h-[calc(100vh-10rem)] mt-6">
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Log Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Log ID</p>
                          <p className="font-medium font-mono">{selectedLog.id}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Status</p>
                          <div className="mt-1">{getStatusBadge(selectedLog.status)}</div>
                        </div>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground">Timestamp</p>
                        <p className="font-medium">{selectedLog.timestamp}</p>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground">User</p>
                        <p className="font-medium">{selectedLog.user}</p>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground">Module</p>
                        <Badge variant="outline">{selectedLog.module}</Badge>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground">Action</p>
                        <p className="font-medium">{selectedLog.action}</p>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground">Details</p>
                        <p className="font-medium">{selectedLog.details}</p>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground">IP Address</p>
                        <p className="font-medium font-mono">{selectedLog.ipAddress}</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Additional Metadata</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="p-3 bg-muted/50 rounded">
                        <p className="text-sm text-muted-foreground">Browser</p>
                        <p className="text-sm font-medium">Chrome 120.0.6099.130</p>
                      </div>
                      <div className="p-3 bg-muted/50 rounded">
                        <p className="text-sm text-muted-foreground">Device</p>
                        <p className="text-sm font-medium">Desktop - Windows 11</p>
                      </div>
                      <div className="p-3 bg-muted/50 rounded">
                        <p className="text-sm text-muted-foreground">Session ID</p>
                        <p className="text-sm font-medium font-mono">
                          sess_abc123def456ghi789
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>

              <div className="absolute bottom-0 left-0 right-0 p-6 bg-card border-t border-border">
                <div className="flex gap-3">
                  <Button variant="outline" className="flex-1">
                    <Download className="size-4 mr-2" />
                    Export Log
                  </Button>
                  <Button variant="outline" className="flex-1">
                    View Related Logs
                  </Button>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
