import { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { ScrollArea } from "../components/ui/scroll-area";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { Textarea } from "../components/ui/textarea";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu";
import { BackButton } from "../components/BackButton";
import {
  Mail,
  Plus,
  MessageSquare,
  Search,
  Users,
  Bell,
  Phone,
  Video,
  MoreVertical,
  Check,
  CheckCheck,
  Paperclip,
  Send,
} from "lucide-react";

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  content: string;
  timestamp: Date;
  read: boolean;
  sent?: boolean;
}

interface Contact {
  id: string;
  name: string;
  role: string;
  avatar: string;
  status: "online" | "offline" | "away";
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  department?: string;
}

const teacherContacts: Contact[] = [
  {
    id: "t1",
    name: "Dr. Sarah Johnson",
    role: "Head of Science Department",
    avatar: "SJ",
    status: "online",
    lastMessage: "I've updated the chemistry lab schedule",
    lastMessageTime: "2m ago",
    unreadCount: 2,
    department: "Science",
  },
  {
    id: "t2",
    name: "Prof. Michael Chen",
    role: "Mathematics Teacher",
    avatar: "MC",
    status: "online",
    lastMessage: "Grade 10 results are ready for review",
    lastMessageTime: "15m ago",
    unreadCount: 0,
    department: "Mathematics",
  },
  {
    id: "t3",
    name: "Ms. Emily Rodriguez",
    role: "English Teacher",
    avatar: "ER",
    status: "away",
    lastMessage: "Can we discuss the literature curriculum?",
    lastMessageTime: "1h ago",
    unreadCount: 1,
    department: "Languages",
  },
  {
    id: "t4",
    name: "Mr. David Kim",
    role: "Physical Education",
    avatar: "DK",
    status: "offline",
    lastMessage: "Sports day planning document attached",
    lastMessageTime: "3h ago",
    unreadCount: 0,
    department: "Sports",
  },
];

const staffContacts: Contact[] = [
  {
    id: "s1",
    name: "Rachel Adams",
    role: "Administrative Officer",
    avatar: "RA",
    status: "online",
    lastMessage: "New admission forms are ready",
    lastMessageTime: "5m ago",
    unreadCount: 1,
    department: "Administration",
  },
  {
    id: "s2",
    name: "John Martinez",
    role: "IT Support",
    avatar: "JM",
    status: "online",
    lastMessage: "Server maintenance scheduled for tonight",
    lastMessageTime: "30m ago",
    unreadCount: 0,
    department: "IT",
  },
  {
    id: "s3",
    name: "Lisa Thompson",
    role: "Librarian",
    avatar: "LT",
    status: "away",
    lastMessage: "New books inventory completed",
    lastMessageTime: "2h ago",
    unreadCount: 0,
    department: "Library",
  },
];

const adminContacts: Contact[] = [
  {
    id: "a1",
    name: "Principal Margaret Davis",
    role: "Principal",
    avatar: "MD",
    status: "online",
    lastMessage: "Board meeting agenda for review",
    lastMessageTime: "10m ago",
    unreadCount: 3,
    department: "Executive",
  },
  {
    id: "a2",
    name: "Vice Principal Robert Lee",
    role: "Vice Principal",
    avatar: "RL",
    status: "online",
    lastMessage: "Discipline committee report attached",
    lastMessageTime: "45m ago",
    unreadCount: 0,
    department: "Executive",
  },
  {
    id: "a3",
    name: "Finance Director",
    role: "Priya Sharma",
    avatar: "PS",
    status: "offline",
    lastMessage: "Q1 budget approval needed",
    lastMessageTime: "Yesterday",
    unreadCount: 0,
    department: "Finance",
  },
];

const otherContacts: Contact[] = [
  {
    id: "o1",
    name: "Parent Committee",
    role: "Group - 24 members",
    avatar: "PC",
    status: "online",
    lastMessage: "Annual day event planning discussion",
    lastMessageTime: "1h ago",
    unreadCount: 5,
  },
  {
    id: "o2",
    name: "Alumni Association",
    role: "Group - 156 members",
    avatar: "AA",
    status: "online",
    lastMessage: "Scholarship fund announcement",
    lastMessageTime: "2h ago",
    unreadCount: 0,
  },
  {
    id: "o3",
    name: "External Auditor",
    role: "James Wilson",
    avatar: "JW",
    status: "offline",
    lastMessage: "Audit documents required by next week",
    lastMessageTime: "2 days ago",
    unreadCount: 0,
  },
];

export default function Communication() {
  const [selectedContact, setSelectedContact] = useState<Contact | null>(teacherContacts[0]);
  const [messageInput, setMessageInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("teachers");

  const messages: Message[] = selectedContact ? [
    {
      id: "1",
      senderId: selectedContact.id,
      senderName: selectedContact.name,
      senderRole: selectedContact.role,
      content: "Good morning! I wanted to discuss the upcoming parent-teacher meeting schedule.",
      timestamp: new Date(Date.now() - 3600000),
      read: true,
    },
    {
      id: "2",
      senderId: "me",
      senderName: "Principal",
      senderRole: "School Principal",
      content: "Good morning! Yes, let's coordinate on this. What dates work best for your department?",
      timestamp: new Date(Date.now() - 3500000),
      read: true,
      sent: true,
    },
    {
      id: "3",
      senderId: selectedContact.id,
      senderName: selectedContact.name,
      senderRole: selectedContact.role,
      content: "We prefer the first week of next month. I've also updated the chemistry lab schedule as requested.",
      timestamp: new Date(Date.now() - 3400000),
      read: true,
    },
    {
      id: "4",
      senderId: "me",
      senderName: "Principal",
      senderRole: "School Principal",
      content: "Perfect! I'll have the admin team block those dates. Could you share the lab schedule with the facilities team as well?",
      timestamp: new Date(Date.now() - 3300000),
      read: true,
      sent: true,
    },
    {
      id: "5",
      senderId: selectedContact.id,
      senderName: selectedContact.name,
      senderRole: selectedContact.role,
      content: "Already done! They've confirmed the equipment maintenance timeline aligns perfectly.",
      timestamp: new Date(Date.now() - 120000),
      read: false,
    },
  ] : [];

  const handleSendMessage = () => {
    if (messageInput.trim() && selectedContact) {
      // Handle message sending logic here
      console.log("Sending message:", messageInput);
      setMessageInput("");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-500";
      case "away":
        return "bg-yellow-500";
      default:
        return "bg-gray-400";
    }
  };

  const getContactsByTab = () => {
    switch (activeTab) {
      case "teachers":
        return teacherContacts;
      case "staff":
        return staffContacts;
      case "admin":
        return adminContacts;
      case "others":
        return otherContacts;
      default:
        return teacherContacts;
    }
  };

  const filteredContacts = getContactsByTab().filter((contact) =>
    contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalUnread = [...teacherContacts, ...staffContacts, ...adminContacts, ...otherContacts]
    .reduce((sum, contact) => sum + contact.unreadCount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <BackButton to="/" />
        <div className="flex items-center justify-between mt-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Communication Center</h1>
            <p className="text-muted-foreground mt-1">
              Direct messaging with teachers, staff, and administration
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2">
              <Mail className="size-4" />
              Send Broadcast
            </Button>
            <Button className="gap-2">
              <Plus className="size-4" />
              New Message
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mt-6">
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Unread Messages</p>
                <p className="text-2xl font-bold text-foreground mt-1">{totalUnread}</p>
              </div>
              <div className="size-12 bg-blue-100 dark:bg-blue-950/30 rounded-lg flex items-center justify-center">
                <MessageSquare className="size-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Chats</p>
                <p className="text-2xl font-bold text-foreground mt-1">12</p>
              </div>
              <div className="size-12 bg-green-100 dark:bg-green-950/30 rounded-lg flex items-center justify-center">
                <Users className="size-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Online Now</p>
                <p className="text-2xl font-bold text-foreground mt-1">8</p>
              </div>
              <div className="size-12 bg-purple-100 dark:bg-purple-950/30 rounded-lg flex items-center justify-center">
                <Bell className="size-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Broadcasts Sent</p>
                <p className="text-2xl font-bold text-foreground mt-1">24</p>
              </div>
              <div className="size-12 bg-orange-100 dark:bg-orange-950/30 rounded-lg flex items-center justify-center">
                <Mail className="size-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Communication Interface */}
      <div className="bg-card border border-border rounded-lg overflow-hidden" style={{ height: "600px" }}>
        <div className="flex h-full">
          {/* Contacts Sidebar */}
          <div className="w-80 border-r border-border flex flex-col">
            {/* Search */}
            <div className="p-4 border-b border-border">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  placeholder="Search contacts..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
              <TabsList className="grid grid-cols-4 w-full rounded-none border-b border-border">
                <TabsTrigger value="teachers" className="relative">
                  Teachers
                  {teacherContacts.some(c => c.unreadCount > 0) && (
                    <Badge className="ml-1 size-5 p-0 flex items-center justify-center text-xs">
                      {teacherContacts.reduce((sum, c) => sum + c.unreadCount, 0)}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="staff" className="relative">
                  Staff
                  {staffContacts.some(c => c.unreadCount > 0) && (
                    <Badge className="ml-1 size-5 p-0 flex items-center justify-center text-xs">
                      {staffContacts.reduce((sum, c) => sum + c.unreadCount, 0)}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="admin" className="relative">
                  Admin
                  {adminContacts.some(c => c.unreadCount > 0) && (
                    <Badge className="ml-1 size-5 p-0 flex items-center justify-center text-xs">
                      {adminContacts.reduce((sum, c) => sum + c.unreadCount, 0)}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="others" className="relative">
                  Others
                  {otherContacts.some(c => c.unreadCount > 0) && (
                    <Badge className="ml-1 size-5 p-0 flex items-center justify-center text-xs">
                      {otherContacts.reduce((sum, c) => sum + c.unreadCount, 0)}
                    </Badge>
                  )}
                </TabsTrigger>
              </TabsList>

              {/* Contact List */}
              <ScrollArea className="flex-1">
                {["teachers", "staff", "admin", "others"].map((tab) => (
                  <TabsContent key={tab} value={tab} className="m-0 mt-0">
                    <div className="divide-y divide-border">
                      {filteredContacts.map((contact) => (
                        <button
                          key={contact.id}
                          onClick={() => setSelectedContact(contact)}
                          className={`w-full p-4 flex items-start gap-3 hover:bg-accent transition-colors text-left ${
                            selectedContact?.id === contact.id ? "bg-accent" : ""
                          }`}
                        >
                          <div className="relative">
                            <Avatar className="size-12">
                              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-600 text-white font-semibold">
                                {contact.avatar}
                              </AvatarFallback>
                            </Avatar>
                            <div
                              className={`absolute bottom-0 right-0 size-3 rounded-full border-2 border-card ${getStatusColor(
                                contact.status
                              )}`}
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <h4 className="font-semibold text-sm text-foreground truncate">
                                {contact.name}
                              </h4>
                              <span className="text-xs text-muted-foreground">
                                {contact.lastMessageTime}
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground mb-1">{contact.role}</p>
                            <div className="flex items-center justify-between">
                              <p className="text-xs text-muted-foreground truncate flex-1">
                                {contact.lastMessage}
                              </p>
                              {contact.unreadCount > 0 && (
                                <Badge className="ml-2 size-5 p-0 flex items-center justify-center text-xs">
                                  {contact.unreadCount}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </ScrollArea>
            </Tabs>
          </div>

          {/* Chat Area */}
          {selectedContact ? (
            <div className="flex-1 flex flex-col">
              {/* Chat Header */}
              <div className="p-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar className="size-10">
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-600 text-white font-semibold">
                        {selectedContact.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`absolute bottom-0 right-0 size-3 rounded-full border-2 border-card ${getStatusColor(
                        selectedContact.status
                      )}`}
                    />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{selectedContact.name}</h3>
                    <p className="text-xs text-muted-foreground">{selectedContact.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon">
                    <Phone className="size-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="size-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Search className="size-4" />
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="size-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>View Profile</DropdownMenuItem>
                      <DropdownMenuItem>Mute Notifications</DropdownMenuItem>
                      <DropdownMenuItem>Clear History</DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600">Block Contact</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sent ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[70%] ${
                          message.sent
                            ? "bg-blue-600 text-white"
                            : "bg-accent text-foreground"
                        } rounded-lg p-3`}
                      >
                        {!message.sent && (
                          <p className="text-xs font-semibold mb-1">{message.senderName}</p>
                        )}
                        <p className="text-sm">{message.content}</p>
                        <div className="flex items-center justify-end gap-1 mt-1">
                          <p
                            className={`text-xs ${
                              message.sent ? "text-blue-100" : "text-muted-foreground"
                            }`}
                          >
                            {message.timestamp.toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                          {message.sent && (
                            <span className="text-blue-100">
                              {message.read ? (
                                <CheckCheck className="size-3" />
                              ) : (
                                <Check className="size-3" />
                              )}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="p-4 border-t border-border">
                <div className="flex items-end gap-2">
                  <Button variant="ghost" size="icon">
                    <Paperclip className="size-4" />
                  </Button>
                  <Textarea
                    placeholder="Type a message..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    className="min-h-[44px] max-h-32 resize-none"
                  />
                  <Button onClick={handleSendMessage} disabled={!messageInput.trim()}>
                    <Send className="size-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Press Enter to send, Shift + Enter for new line
                </p>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <MessageSquare className="size-16 mx-auto mb-4 opacity-20" />
                <p>Select a contact to start messaging</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}