import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { UserPlus, CheckCircle, XCircle, Clock } from "lucide-react";
import { admissions } from "../data/mockData";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { BackButton } from "../components/BackButton";
import { toast } from "sonner";

export default function Admissions() {
  const handleNewApplication = () => {
    toast.info("Opening new application form...");
  };

  const handleViewApplication = (applicationId: string, studentName: string) => {
    toast.info(`Viewing application for ${studentName}`);
  };

  const handleRejectApplication = (applicationId: string, studentName: string) => {
    toast.error(`Application rejected for ${studentName}`);
  };

  const handleApproveApplication = (applicationId: string, studentName: string) => {
    toast.success(`Application approved for ${studentName}`);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Pending":
        return <Badge variant="outline" className="text-yellow-600">Pending</Badge>;
      case "Under Review":
        return <Badge className="bg-blue-500">Under Review</Badge>;
      case "Interview Scheduled":
        return <Badge className="bg-purple-500">Interview Scheduled</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Admissions Control</h1>
          <p className="text-slate-600 mt-1">
            Review and approve new student applications
          </p>
        </div>
        <Button onClick={handleNewApplication}>
          <UserPlus className="size-4 mr-2" />
          New Application
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total Applications</p>
                <p className="text-2xl md:text-3xl font-bold">{admissions.length}</p>
              </div>
              <UserPlus className="size-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Pending Review</p>
                <p className="text-2xl md:text-3xl font-bold">
                  {admissions.filter((a) => a.status === "Pending").length}
                </p>
              </div>
              <Clock className="size-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Available Seats</p>
                <p className="text-2xl md:text-3xl font-bold">47</p>
              </div>
              <CheckCircle className="size-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Waiting List</p>
                <p className="text-2xl md:text-3xl font-bold">12</p>
              </div>
              <XCircle className="size-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Applications Table */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Application ID</TableHead>
                  <TableHead>Student Name</TableHead>
                  <TableHead>Class Applied</TableHead>
                  <TableHead>Application Date</TableHead>
                  <TableHead>Test Score</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {admissions.map((application) => (
                  <TableRow key={application.id}>
                    <TableCell className="font-medium">{application.id}</TableCell>
                    <TableCell>{application.studentName}</TableCell>
                    <TableCell>Class {application.class}</TableCell>
                    <TableCell>{application.applicationDate}</TableCell>
                    <TableCell>
                      <span
                        className={
                          application.testScore >= 80
                            ? "text-green-600 font-semibold"
                            : application.testScore >= 60
                            ? "text-blue-600"
                            : "text-red-600"
                        }
                      >
                        {application.testScore.toFixed(0)}%
                      </span>
                    </TableCell>
                    <TableCell>{getStatusBadge(application.status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleViewApplication(application.id, application.studentName)}>
                          View
                        </Button>
                        {application.status === "Pending" && (
                          <>
                            <Button size="sm" variant="outline" className="text-red-600" onClick={() => handleRejectApplication(application.id, application.studentName)}>
                              <XCircle className="size-4" />
                            </Button>
                            <Button size="sm" onClick={() => handleApproveApplication(application.id, application.studentName)}>
                              <CheckCircle className="size-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Capacity Management */}
      <Card>
        <CardHeader>
          <CardTitle>Class-wise Capacity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
            {[6, 7, 8, 9, 10].map((cls) => {
              const capacity = 60;
              const admitted = Math.floor(Math.random() * 20) + 40;
              return (
                <div key={cls} className="p-4 border border-slate-200 rounded-lg">
                  <p className="font-semibold mb-2">Class {cls}</p>
                  <div className="flex items-baseline gap-1 mb-1">
                    <span className="text-2xl font-bold">{admitted}</span>
                    <span className="text-sm text-slate-600">/ {capacity}</span>
                  </div>
                  <Badge variant={admitted >= capacity ? "destructive" : "outline"}>
                    {capacity - admitted} seats left
                  </Badge>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
