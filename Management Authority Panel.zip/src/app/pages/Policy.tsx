import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Shield, Edit, History } from "lucide-react";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { BackButton } from "../components/BackButton";

export default function Policy() {
  const policies = [
    {
      category: "Academic Policies",
      rules: [
        { name: "Passing Marks Percentage", value: "40%", editable: true },
        { name: "Minimum Attendance for Exam", value: "75%", editable: true },
        { name: "Grace Marks Rule", value: "Up to 5% in aggregate", editable: true },
        { name: "Homework Submission Deadline", value: "Next day by 9 AM", editable: true },
      ],
    },
    {
      category: "Attendance Policies",
      rules: [
        { name: "Minimum Required Attendance", value: "75%", editable: true },
        { name: "Late Arrival Grace Period", value: "10 minutes", editable: true },
        { name: "Medical Leave Approval", value: "Requires certificate if >3 days", editable: false },
      ],
    },
    {
      category: "Discipline Escalation",
      rules: [
        { name: "First Offense", value: "Verbal Warning", editable: false },
        { name: "Second Offense", value: "Written Warning + Guardian Meeting", editable: false },
        { name: "Third Offense", value: "Suspension (3-7 days)", editable: false },
        { name: "Severe Violation", value: "Immediate suspension pending investigation", editable: false },
      ],
    },
    {
      category: "Financial Policies",
      rules: [
        { name: "Fee Payment Deadline", value: "10th of each month", editable: true },
        { name: "Late Payment Penalty", value: "₹500 after grace period", editable: true },
        { name: "Fee Waiver Approval", value: "Requires management approval", editable: false },
        { name: "Refund Processing Time", value: "30 working days", editable: true },
      ],
    },
  ];

  const recentChanges = [
    {
      policy: "Passing Marks Percentage",
      oldValue: "35%",
      newValue: "40%",
      changedBy: "Principal",
      date: "2025-08-15",
    },
    {
      policy: "Minimum Attendance for Exam",
      oldValue: "70%",
      newValue: "75%",
      changedBy: "Principal",
      date: "2025-08-10",
    },
  ];

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Policy & Rules Control</h1>
        <p className="text-slate-600 mt-1">
          Configure institutional policies and rules
        </p>
      </div>

      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Shield className="size-5 text-blue-600 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-blue-900">
                All policy changes are automatically logged in the audit trail
              </p>
              <p className="text-xs text-blue-700 mt-1">
                Changes take effect immediately and are visible to relevant staff
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Policy Categories */}
      {policies.map((policyGroup, idx) => (
        <Card key={idx}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{policyGroup.category}</span>
              <Badge variant="outline">{policyGroup.rules.length} rules</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {policyGroup.rules.map((rule, ruleIdx) => (
                <div
                  key={ruleIdx}
                  className="flex items-center justify-between p-4 border border-slate-200 rounded-lg"
                >
                  <div className="flex-1">
                    <p className="font-medium text-sm">{rule.name}</p>
                    <p className="text-sm text-slate-600 mt-1">{rule.value}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {rule.editable ? (
                      <Button size="sm" variant="outline">
                        <Edit className="size-4 mr-1" />
                        Edit
                      </Button>
                    ) : (
                      <Badge variant="outline">Fixed Rule</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}

      {/* Edit Policy Modal Example */}
      <Card>
        <CardHeader>
          <CardTitle>Edit Policy Example</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label>Policy Name</Label>
              <Input value="Passing Marks Percentage" disabled className="mt-1" />
            </div>
            <div>
              <Label>Current Value</Label>
              <Input value="40%" className="mt-1" />
            </div>
            <div className="flex gap-3">
              <Button>Save Changes</Button>
              <Button variant="outline">Cancel</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Audit Trail */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="size-5" />
            Recent Policy Changes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentChanges.map((change, idx) => (
              <div
                key={idx}
                className="p-4 border border-slate-200 rounded-lg bg-slate-50"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-sm">{change.policy}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm text-red-600 line-through">
                        {change.oldValue}
                      </span>
                      <span className="text-slate-400">→</span>
                      <span className="text-sm text-green-600 font-medium">
                        {change.newValue}
                      </span>
                    </div>
                  </div>
                  <Badge variant="outline">{change.date}</Badge>
                </div>
                <p className="text-xs text-slate-600">
                  Changed by: {change.changedBy}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
