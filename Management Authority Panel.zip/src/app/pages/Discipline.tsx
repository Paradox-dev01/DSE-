import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { AlertTriangle, FileText, CheckCircle } from "lucide-react";
import { disciplineCases } from "../data/mockData";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { BackButton } from "../components/BackButton";
import { toast } from "sonner";

export default function Discipline() {
  const handleViewCase = (caseId: string, studentName: string) => {
    toast.info(`Opening case details for ${studentName} (${caseId})`);
  };

  const handleDecideCase = (caseId: string, studentName: string) => {
    toast.warning(`Opening decision form for ${studentName} (${caseId})`);
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "High":
        return <Badge variant="destructive">High</Badge>;
      case "Medium":
        return <Badge className="bg-yellow-500">Medium</Badge>;
      case "Low":
        return <Badge variant="outline">Low</Badge>;
      default:
        return <Badge>{severity}</Badge>;
    }
  };

  const getStatusColor = (status: string) => {
    if (status.includes("Investigation")) return "text-yellow-600";
    if (status.includes("Meeting")) return "text-blue-600";
    if (status.includes("Decision")) return "text-purple-600";
    return "text-slate-600";
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Discipline & Case Management</h1>
        <p className="text-slate-600 mt-1">
          Track incidents, investigations, and disciplinary decisions
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Open Cases</p>
                <p className="text-2xl md:text-3xl font-bold">{disciplineCases.length}</p>
              </div>
              <AlertTriangle className="size-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">High Severity</p>
                <p className="text-2xl md:text-3xl font-bold">
                  {disciplineCases.filter((c) => c.severity === "High").length}
                </p>
              </div>
              <AlertTriangle className="size-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Pending Decision</p>
                <p className="text-2xl md:text-3xl font-bold">
                  {disciplineCases.filter((c) => c.status.includes("Decision")).length}
                </p>
              </div>
              <FileText className="size-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Resolved (This Month)</p>
                <p className="text-2xl md:text-3xl font-bold">8</p>
              </div>
              <CheckCircle className="size-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Case Workflow */}
      <Card>
        <CardHeader>
          <CardTitle>Discipline Case Workflow</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
            <div className="flex items-center gap-8">
              <div className="text-center">
                <div className="size-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-semibold mb-2">
                  1
                </div>
                <p className="text-xs font-medium">Incident<br/>Report</p>
              </div>
              <div className="text-slate-300">→</div>
              <div className="text-center">
                <div className="size-12 rounded-full bg-yellow-100 text-yellow-600 flex items-center justify-center font-semibold mb-2">
                  2
                </div>
                <p className="text-xs font-medium">Investigation</p>
              </div>
              <div className="text-slate-300">→</div>
              <div className="text-center">
                <div className="size-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center font-semibold mb-2">
                  3
                </div>
                <p className="text-xs font-medium">Guardian<br/>Meeting</p>
              </div>
              <div className="text-slate-300">→</div>
              <div className="text-center">
                <div className="size-12 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center font-semibold mb-2">
                  4
                </div>
                <p className="text-xs font-medium">Decision</p>
              </div>
              <div className="text-slate-300">→</div>
              <div className="text-center">
                <div className="size-12 rounded-full bg-green-100 text-green-600 flex items-center justify-center font-semibold mb-2">
                  5
                </div>
                <p className="text-xs font-medium">Closure</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Cases */}
      <Card>
        <CardHeader>
          <CardTitle>Active Discipline Cases</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Case ID</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>Incident</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Documents</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {disciplineCases.map((caseItem) => (
                  <TableRow key={caseItem.id}>
                    <TableCell className="font-medium">{caseItem.id}</TableCell>
                    <TableCell>{caseItem.studentName}</TableCell>
                    <TableCell>{caseItem.class}</TableCell>
                    <TableCell className="max-w-xs">{caseItem.incident}</TableCell>
                    <TableCell>{caseItem.date}</TableCell>
                    <TableCell>{getSeverityBadge(caseItem.severity)}</TableCell>
                    <TableCell>
                      <span className={`text-sm font-medium ${getStatusColor(caseItem.status)}`}>
                        {caseItem.status}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{caseItem.documents} files</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleViewCase(caseItem.id, caseItem.studentName)}>
                          View
                        </Button>
                        {caseItem.status.includes("Decision") && (
                          <Button size="sm" onClick={() => handleDecideCase(caseItem.id, caseItem.studentName)}>Decide</Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Decision Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Available Disciplinary Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            <div className="p-4 border border-slate-200 rounded-lg">
              <Badge className="mb-2">Warning</Badge>
              <p className="text-sm font-medium">Verbal/Written Warning</p>
              <p className="text-xs text-slate-600 mt-1">First-time minor incidents</p>
            </div>
            <div className="p-4 border border-yellow-300 bg-yellow-50 rounded-lg">
              <Badge className="bg-yellow-500 mb-2">Suspension</Badge>
              <p className="text-sm font-medium">Temporary Suspension</p>
              <p className="text-xs text-slate-600 mt-1">Serious incidents requiring intervention</p>
            </div>
            <div className="p-4 border border-red-300 bg-red-50 rounded-lg">
              <Badge variant="destructive" className="mb-2">Expulsion</Badge>
              <p className="text-sm font-medium">Permanent Expulsion</p>
              <p className="text-xs text-slate-600 mt-1">Severe violations, last resort</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
