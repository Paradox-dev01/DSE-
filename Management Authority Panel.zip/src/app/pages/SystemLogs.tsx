import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Search, Download, FileText } from "lucide-react";
import { systemLogs } from "../data/mockData";
import { BackButton } from "../components/BackButton";

export default function SystemLogs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const filteredLogs = systemLogs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.user.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      categoryFilter === "all" || log.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Academic":
        return "bg-blue-100 text-blue-800";
      case "Finance":
        return "bg-green-100 text-green-800";
      case "Attendance":
        return "bg-purple-100 text-purple-800";
      case "Discipline":
        return "bg-red-100 text-red-800";
      case "System":
        return "bg-slate-100 text-slate-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">System Logs & Audit Trail</h1>
          <p className="text-slate-600 mt-1">
            Complete activity log with searchable history
          </p>
        </div>
        <Button>
          <Download className="size-4 mr-2" />
          Export Logs
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-slate-600 mb-1">Total Logs</p>
              <p className="text-2xl font-bold">{systemLogs.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-slate-600 mb-1">Academic</p>
              <p className="text-2xl font-bold">
                {systemLogs.filter((l) => l.category === "Academic").length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-slate-600 mb-1">Finance</p>
              <p className="text-2xl font-bold">
                {systemLogs.filter((l) => l.category === "Finance").length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-slate-600 mb-1">Attendance</p>
              <p className="text-2xl font-bold">
                {systemLogs.filter((l) => l.category === "Attendance").length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-slate-600 mb-1">Discipline</p>
              <p className="text-2xl font-bold">
                {systemLogs.filter((l) => l.category === "Discipline").length}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                placeholder="Search by action or user..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Academic">Academic</SelectItem>
                <SelectItem value="Finance">Finance</SelectItem>
                <SelectItem value="Attendance">Attendance</SelectItem>
                <SelectItem value="Discipline">Discipline</SelectItem>
                <SelectItem value="System">System</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle>
            {filteredLogs.length} Log Entries
            {(searchQuery || categoryFilter !== "all") && " (Filtered)"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>User/Module</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Category</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-mono text-xs">
                      {log.timestamp}
                    </TableCell>
                    <TableCell>
                      <span className="font-medium text-sm">{log.user}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <FileText className="size-4 text-slate-400" />
                        <span className="text-sm">{log.action}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getCategoryColor(log.category)} variant="outline">
                        {log.category}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Specialized Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Financial Approval Log</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                {
                  action: "Fee waiver approved",
                  amount: "₹12,500",
                  student: "Rajesh Kumar",
                  date: "2026-02-23",
                },
                {
                  action: "Scholarship approved",
                  amount: "₹25,000",
                  student: "Priya Sharma",
                  date: "2026-02-20",
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 border border-slate-200 rounded-lg bg-slate-50"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium">{item.action}</span>
                    <span className="text-sm font-bold text-green-600">
                      {item.amount}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Student: {item.student} • {item.date}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Discipline Decision Log</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                {
                  action: "Suspension approved",
                  student: "Vikram Singh",
                  days: "5 days",
                  date: "2026-02-22",
                },
                {
                  action: "Warning issued",
                  student: "Amit Patel",
                  days: "Written",
                  date: "2026-02-19",
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 border border-slate-200 rounded-lg bg-slate-50"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium">{item.action}</span>
                    <Badge variant="outline">{item.days}</Badge>
                  </div>
                  <p className="text-xs text-slate-600">
                    Student: {item.student} • {item.date}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
