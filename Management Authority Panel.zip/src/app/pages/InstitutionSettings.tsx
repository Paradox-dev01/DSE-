import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Building, Globe, Mail, Phone, MapPin, Clock, Calendar, Users } from "lucide-react";
import { toast } from "sonner";
import { BackButton } from "../components/BackButton";

export default function InstitutionSettings() {
  const handleSave = () => {
    toast.success("Institution settings updated successfully!");
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6 bg-background min-h-full">
      {/* Page Header */}
      <BackButton />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">Institution Settings</h1>
          <p className="text-muted-foreground mt-1">
            Manage your institution's information and configuration
          </p>
        </div>
        <Badge className="bg-green-500">Academic Year: 2025-2026</Badge>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="academic">Academic</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
          <TabsTrigger value="admissions">Admissions</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="schoolName">School Name</Label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    id="schoolName"
                    defaultValue="St. Xavier's International School"
                    className="pl-9"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="affiliation">Affiliation</Label>
                  <Input
                    id="affiliation"
                    defaultValue="CBSE"
                    placeholder="e.g., CBSE, ICSE, State Board"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="affiliationCode">Affiliation Code</Label>
                  <Input
                    id="affiliationCode"
                    defaultValue="1234567"
                    placeholder="Enter code"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="motto">School Motto</Label>
                <Input
                  id="motto"
                  defaultValue="Excellence in Education"
                  placeholder="Enter school motto"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">About School</Label>
                <Textarea
                  id="description"
                  rows={4}
                  defaultValue="St. Xavier's International School is a premier educational institution committed to providing quality education and holistic development of students."
                  placeholder="Brief description of your institution"
                />
              </div>

              <Button onClick={handleSave}>Save General Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="academic" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Academic Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="academicYear">Current Academic Year</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="academicYear"
                      defaultValue="2025-2026"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="yearStart">Academic Year Start</Label>
                  <Input
                    id="yearStart"
                    type="date"
                    defaultValue="2025-04-01"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="totalClasses">Total Classes</Label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="totalClasses"
                      type="number"
                      defaultValue="12"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sectionsPerClass">Sections per Class</Label>
                  <Input
                    id="sectionsPerClass"
                    type="number"
                    defaultValue="3"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="classStartTime">Class Start Time</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="classStartTime"
                      type="time"
                      defaultValue="08:00"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="classEndTime">Class End Time</Label>
                  <Input
                    id="classEndTime"
                    type="time"
                    defaultValue="15:30"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="attendanceThreshold">Minimum Attendance Threshold (%)</Label>
                <Input
                  id="attendanceThreshold"
                  type="number"
                  defaultValue="75"
                  min="0"
                  max="100"
                />
              </div>

              <Button onClick={handleSave}>Save Academic Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Official Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    defaultValue="info@stxaviers.edu"
                    className="pl-9"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone1">Primary Phone</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="phone1"
                      type="tel"
                      defaultValue="+91 11 2345 6789"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone2">Secondary Phone</Label>
                  <Input
                    id="phone2"
                    type="tel"
                    defaultValue="+91 11 2345 6790"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    id="website"
                    type="url"
                    defaultValue="https://www.stxaviers.edu"
                    className="pl-9"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">School Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 size-4 text-muted-foreground" />
                  <Textarea
                    id="address"
                    rows={3}
                    defaultValue="123 Education Lane, Knowledge District, New Delhi - 110001, India"
                    className="pl-9"
                  />
                </div>
              </div>

              <Button onClick={handleSave}>Save Contact Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="admissions" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Admission Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <div className="space-y-2">
                  <Label htmlFor="admissionStart">Admission Start Date</Label>
                  <Input
                    id="admissionStart"
                    type="date"
                    defaultValue="2025-01-01"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admissionEnd">Admission End Date</Label>
                  <Input
                    id="admissionEnd"
                    type="date"
                    defaultValue="2025-03-31"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="admissionAge">Minimum Age for Admission</Label>
                <Input
                  id="admissionAge"
                  type="number"
                  defaultValue="5"
                  min="3"
                  max="18"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="admissionFee">Application Fee (₹)</Label>
                <Input
                  id="admissionFee"
                  type="number"
                  defaultValue="500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="admissionStatus">Admission Status</Label>
                <Select defaultValue="open">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                    <SelectItem value="waitlist">Waitlist Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleSave}>Save Admission Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-900 rounded-lg">
                <h4 className="font-semibold text-sm mb-2 text-yellow-900 dark:text-yellow-200">
                  ⚠️ Caution Required
                </h4>
                <p className="text-sm text-yellow-800 dark:text-yellow-300">
                  These settings can significantly impact system behavior. Please consult with IT support before making changes.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <h4 className="font-medium text-sm">Data Backup</h4>
                    <p className="text-sm text-muted-foreground">
                      Last backup: 2 hours ago
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Backup Now
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <h4 className="font-medium text-sm">System Maintenance Mode</h4>
                    <p className="text-sm text-muted-foreground">
                      Temporarily disable access for maintenance
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Enable
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <h4 className="font-medium text-sm">Export All Data</h4>
                    <p className="text-sm text-muted-foreground">
                      Download complete institutional data
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Export
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 rounded-lg">
                  <div>
                    <h4 className="font-medium text-sm text-red-900 dark:text-red-200">Reset All Settings</h4>
                    <p className="text-sm text-red-800 dark:text-red-300">
                      Restore default configuration
                    </p>
                  </div>
                  <Button variant="destructive" size="sm">
                    Reset
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
