import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Bell, Send, Calendar, CheckCircle, Clock } from "lucide-react";
import { Textarea } from "../components/ui/textarea";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { BackButton } from "../components/BackButton";
import { toast } from "sonner";
import { useState } from "react";

export default function Notices() {
  const [noticeTitle, setNoticeTitle] = useState("");
  const [noticeContent, setNoticeContent] = useState("");

  const handlePublishImmediately = () => {
    if (!noticeTitle || !noticeContent) {
      toast.error("Please fill in all required fields");
      return;
    }
    toast.success("Notice published successfully");
    setNoticeTitle("");
    setNoticeContent("");
  };

  const handleScheduleLater = () => {
    if (!noticeTitle || !noticeContent) {
      toast.error("Please fill in all required fields");
      return;
    }
    toast.info("Opening schedule picker...");
  };

  const handleSaveDraft = () => {
    if (!noticeTitle || !noticeContent) {
      toast.error("Please fill in all required fields");
      return;
    }
    toast.success("Draft saved successfully");
  };

  const handleRejectNotice = (noticeTitle: string) => {
    toast.error(`Notice rejected: ${noticeTitle}`);
  };

  const handleApproveNotice = (noticeTitle: string) => {
    toast.success(`Notice approved and published: ${noticeTitle}`);
  };

  const handleEmergencyBroadcast = () => {
    toast.warning("Opening emergency broadcast form...");
  };

  const recentNotices = [
    {
      id: 1,
      title: "Mid-Term Examination Schedule",
      content: "The mid-term examinations will be conducted from March 15 to March 25, 2026.",
      date: "2026-02-20",
      status: "Published",
      audience: "All Students & Guardians",
    },
    {
      id: 2,
      title: "Parent-Teacher Meeting",
      content: "Annual PTM scheduled for March 10, 2026. Attendance is mandatory.",
      date: "2026-02-18",
      status: "Published",
      audience: "All Guardians",
    },
    {
      id: 3,
      title: "Sports Day Announcement",
      content: "Annual Sports Day will be held on April 5, 2026.",
      date: "2026-02-15",
      status: "Published",
      audience: "All Students & Guardians",
    },
  ];

  const pendingApproval = [
    {
      id: 1,
      title: "Library Hour Extension",
      from: "Librarian",
      date: "2026-02-24",
      urgency: "Normal",
    },
    {
      id: 2,
      title: "Cultural Event Notice",
      from: "Cultural Committee",
      date: "2026-02-23",
      urgency: "High",
    },
  ];

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Notices & Communication</h1>
        <p className="text-slate-600 mt-1">
          Manage institutional notices and guardian communications
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Published (This Month)</p>
                <p className="text-2xl md:text-3xl font-bold">12</p>
              </div>
              <CheckCircle className="size-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Pending Approval</p>
                <p className="text-2xl md:text-3xl font-bold">{pendingApproval.length}</p>
              </div>
              <Clock className="size-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Scheduled</p>
                <p className="text-2xl md:text-3xl font-bold">3</p>
              </div>
              <Calendar className="size-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total Reach</p>
                <p className="text-2xl md:text-3xl font-bold">1,847</p>
              </div>
              <Send className="size-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Create New Notice */}
      <Card>
        <CardHeader>
          <CardTitle>Create New Notice / Announcement</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label>Notice Title</Label>
              <Input
                placeholder="Enter notice title"
                className="mt-1"
                value={noticeTitle}
                onChange={(e) => setNoticeTitle(e.target.value)}
              />
            </div>
            <div>
              <Label>Message Content</Label>
              <Textarea
                placeholder="Enter the notice content..."
                rows={4}
                className="mt-1"
                value={noticeContent}
                onChange={(e) => setNoticeContent(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <div>
                <Label>Target Audience</Label>
                <select className="w-full mt-1 px-3 py-2 border border-slate-300 rounded-md">
                  <option>All Students & Guardians</option>
                  <option>All Guardians Only</option>
                  <option>All Students Only</option>
                  <option>All Teachers</option>
                  <option>Specific Classes</option>
                </select>
              </div>
              <div>
                <Label>Priority</Label>
                <select className="w-full mt-1 px-3 py-2 border border-slate-300 rounded-md">
                  <option>Normal</option>
                  <option>High</option>
                  <option>Urgent</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3">
              <Button className="flex-1" onClick={handlePublishImmediately}>
                <Send className="size-4 mr-2" />
                Publish Immediately
              </Button>
              <Button variant="outline" className="flex-1" onClick={handleScheduleLater}>
                <Calendar className="size-4 mr-2" />
                Schedule for Later
              </Button>
              <Button variant="outline" onClick={handleSaveDraft}>Save as Draft</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pending Approvals */}
      {pendingApproval.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Notices Pending Your Approval</CardTitle>
            <Badge variant="destructive">{pendingApproval.length}</Badge>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingApproval.map((notice) => (
                <div
                  key={notice.id}
                  className="flex items-center justify-between p-4 border border-slate-200 rounded-lg"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={notice.urgency === "High" ? "destructive" : "outline"}>
                        {notice.urgency}
                      </Badge>
                    </div>
                    <p className="font-medium">{notice.title}</p>
                    <p className="text-sm text-slate-600">
                      Submitted by: {notice.from} • {notice.date}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="text-red-600" onClick={() => handleRejectNotice(notice.title)}>
                      Reject
                    </Button>
                    <Button size="sm" onClick={() => handleApproveNotice(notice.title)}>Approve & Publish</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Notices */}
      <Card>
        <CardHeader>
          <CardTitle>Recently Published Notices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentNotices.map((notice) => (
              <div
                key={notice.id}
                className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-semibold">{notice.title}</h3>
                    <p className="text-sm text-slate-600 mt-1">{notice.content}</p>
                  </div>
                  <Badge className="bg-green-500">{notice.status}</Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500 mt-3 pt-3 border-t">
                  <span>Audience: {notice.audience}</span>
                  <span>Published: {notice.date}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Emergency Broadcast */}
      <Card className="border-red-300 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-900">
            <Bell className="size-5" />
            Emergency Broadcast
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-red-800 mb-3">
            Send immediate emergency notifications to all guardians via SMS and app notification
          </p>
          <Button variant="destructive" onClick={handleEmergencyBroadcast}>
            <Send className="size-4 mr-2" />
            Send Emergency Broadcast
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
