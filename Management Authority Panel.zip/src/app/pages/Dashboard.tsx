import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  Users,
  GraduationCap,
  TrendingUp,
  UserX,
  BookX,
  AlertCircle,
  DollarSign,
  CheckCircle,
  Calendar,
  ArrowRight,
  Bell,
} from "lucide-react";
import { dashboardMetrics, pendingApprovals } from "../data/mockData";
import { Link, useNavigate } from "react-router";
import { toast } from "sonner";

export default function Dashboard() {
  const navigate = useNavigate();

  const handleApproveResults = () => {
    toast.success("Redirecting to Academic Control for result approval");
    navigate("/academic");
  };

  const handleApproveLeave = () => {
    toast.success("Redirecting to Teachers & Staff for leave approval");
    navigate("/teachers");
  };

  const handlePublishNotice = () => {
    toast.success("Redirecting to Notices & Announcements");
    navigate("/notices");
  };

  const handleFinancialSummary = () => {
    toast.success("Redirecting to Finance Overview");
    navigate("/finance");
  };

  const handleApprove = (approvalId: number, description: string) => {
    toast.success(`Approved: ${description}`);
  };

  const handleReject = (approvalId: number, description: string) => {
    toast.error(`Rejected: ${description}`);
  };

  const metricCards = [
    {
      title: "Total Students",
      value: dashboardMetrics.totalStudents.toLocaleString(),
      icon: GraduationCap,
      color: "text-blue-600 dark:text-blue-400",
      bgColor: "bg-blue-100 dark:bg-blue-950",
    },
    {
      title: "Total Teachers",
      value: dashboardMetrics.totalTeachers,
      icon: Users,
      color: "text-green-600 dark:text-green-400",
      bgColor: "bg-green-100 dark:bg-green-950",
    },
    {
      title: "Attendance Today",
      value: `${dashboardMetrics.attendanceToday}%`,
      icon: TrendingUp,
      color: "text-emerald-600 dark:text-emerald-400",
      bgColor: "bg-emerald-100 dark:bg-emerald-950",
      status: "good",
    },
    {
      title: "Teachers Absent Today",
      value: dashboardMetrics.teachersAbsentToday,
      icon: UserX,
      color: "text-orange-600 dark:text-orange-400",
      bgColor: "bg-orange-100 dark:bg-orange-950",
      alert: dashboardMetrics.teachersAbsentToday > 2,
    },
    {
      title: "Classes Not Conducted",
      value: dashboardMetrics.classesNotConducted,
      icon: BookX,
      color: "text-red-600 dark:text-red-400",
      bgColor: "bg-red-100 dark:bg-red-950",
      alert: dashboardMetrics.classesNotConducted > 0,
    },
    {
      title: "Weak Students Alert",
      value: dashboardMetrics.weakStudentsAlert,
      icon: AlertCircle,
      color: "text-amber-600 dark:text-amber-400",
      bgColor: "bg-amber-100 dark:bg-amber-950",
    },
    {
      title: "Fee Defaulters",
      value: dashboardMetrics.feeDefaulters,
      icon: DollarSign,
      color: "text-purple-600 dark:text-purple-400",
      bgColor: "bg-purple-100 dark:bg-purple-950",
    },
    {
      title: "Pending Approvals",
      value: dashboardMetrics.pendingApprovals,
      icon: CheckCircle,
      color: "text-cyan-600 dark:text-cyan-400",
      bgColor: "bg-cyan-100 dark:bg-cyan-950",
      highlight: dashboardMetrics.pendingApprovals > 5,
    },
    {
      title: "Upcoming Exams",
      value: dashboardMetrics.upcomingExams,
      icon: Calendar,
      color: "text-indigo-600 dark:text-indigo-400",
      bgColor: "bg-indigo-100 dark:bg-indigo-950",
    },
  ];

  return (
    <div className="p-4 md:p-6 lg:p-8 space-y-6 md:space-y-8">
      {/* Page Header */}
      <div className="space-y-2">
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground tracking-tight">Executive Dashboard</h1>
        <p className="text-muted-foreground text-sm md:text-base lg:text-lg">
          Complete institutional oversight and control center
        </p>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {metricCards.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card
              key={index}
              className={`transition-all duration-200 hover:shadow-xl border-2 ${
                metric.alert
                  ? "border-red-300 dark:border-red-800 bg-red-50/50 dark:bg-red-950/20"
                  : metric.highlight
                  ? "border-cyan-300 dark:border-cyan-800 bg-cyan-50/50 dark:bg-cyan-950/20"
                  : "border-border hover:border-primary/20"
              }`}
            >
              <CardContent className="p-4 md:p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-2 flex-1 min-w-0">
                    <p className="text-xs md:text-sm font-medium text-muted-foreground tracking-wide uppercase truncate">
                      {metric.title}
                    </p>
                    <p className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground tracking-tight">
                      {metric.value}
                    </p>
                  </div>
                  <div className={`${metric.bgColor} ${metric.color} p-3 md:p-4 rounded-xl shadow-sm shrink-0`}>
                    <Icon className="size-5 md:size-6" strokeWidth={2} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="border-2 shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="text-xl md:text-2xl">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
            <Button
              onClick={handleApproveResults}
              className="h-auto py-4 md:py-6 flex-col gap-2 md:gap-3 text-sm md:text-base hover:shadow-lg transition-all"
              variant="outline"
            >
              <CheckCircle className="size-5 md:size-6" />
              <span className="text-center leading-tight">Approve Results</span>
            </Button>
            <Button
              onClick={handleApproveLeave}
              className="h-auto py-4 md:py-6 flex-col gap-2 md:gap-3 text-sm md:text-base hover:shadow-lg transition-all"
              variant="outline"
            >
              <Users className="size-5 md:size-6" />
              <span className="text-center leading-tight">Approve Leave</span>
            </Button>
            <Button
              onClick={handlePublishNotice}
              className="h-auto py-4 md:py-6 flex-col gap-2 md:gap-3 text-sm md:text-base hover:shadow-lg transition-all"
              variant="outline"
            >
              <Bell className="size-5 md:size-6" />
              <span className="text-center leading-tight">Publish Notice</span>
            </Button>
            <Button
              onClick={handleFinancialSummary}
              className="h-auto py-4 md:py-6 flex-col gap-2 md:gap-3 text-sm md:text-base hover:shadow-lg transition-all"
              variant="outline"
            >
              <DollarSign className="size-5 md:size-6" />
              <span className="text-center leading-tight">Financial Summary</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Pending Approvals */}
      <Card className="border-2 shadow-md">
        <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 space-y-2 sm:space-y-0">
          <CardTitle className="text-xl md:text-2xl">Pending Approvals</CardTitle>
          <Badge variant="destructive" className="text-sm md:text-base px-3 md:px-4 py-1 md:py-1.5 shadow-sm self-start sm:self-auto">
            {pendingApprovals.length} Pending
          </Badge>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {pendingApprovals.map((approval) => (
              <div
                key={approval.id}
                className="flex flex-col md:flex-row md:items-center justify-between p-4 md:p-5 border-2 border-border rounded-xl hover:border-primary/30 hover:shadow-lg transition-all bg-card space-y-3 md:space-y-0 md:gap-4"
              >
                <div className="flex-1 space-y-2 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 md:gap-3">
                    <Badge variant={approval.urgent ? "destructive" : "secondary"} className="font-medium text-xs md:text-sm">
                      {approval.type}
                    </Badge>
                    {approval.urgent && (
                      <Badge variant="outline" className="text-red-600 border-red-300 dark:border-red-800 text-xs md:text-sm">
                        Urgent
                      </Badge>
                    )}
                  </div>
                  <p className="font-semibold text-sm md:text-base text-foreground">{approval.description}</p>
                  <div className="flex flex-wrap items-center gap-2 md:gap-4 text-xs md:text-sm text-muted-foreground">
                    <span>From: <span className="font-medium">{approval.from}</span></span>
                    <span className="hidden sm:inline">•</span>
                    <span>{approval.date}</span>
                  </div>
                </div>
                <div className="flex gap-2 md:gap-3">
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20 border-2 flex-1 md:flex-initial"
                    onClick={() => handleReject(approval.id, approval.description)}
                  >
                    Reject
                  </Button>
                  <Button
                    size="sm"
                    className="shadow-sm flex-1 md:flex-initial"
                    onClick={() => handleApprove(approval.id, approval.description)}
                  >
                    Approve
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Links */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <Card className="hover:shadow-xl transition-all cursor-pointer border-2 hover:border-primary/30">
          <Link to="/students">
            <CardContent className="p-4 md:p-6 flex items-center justify-between">
              <div className="space-y-1 flex-1 min-w-0">
                <p className="font-semibold text-base md:text-lg text-foreground truncate">Student Directory</p>
                <p className="text-muted-foreground text-sm md:text-base">View all students and records</p>
              </div>
              <ArrowRight className="size-5 md:size-6 text-muted-foreground shrink-0 ml-2" />
            </CardContent>
          </Link>
        </Card>

        <Card className="hover:shadow-xl transition-all cursor-pointer border-2 hover:border-primary/30">
          <Link to="/teachers">
            <CardContent className="p-4 md:p-6 flex items-center justify-between">
              <div className="space-y-1 flex-1 min-w-0">
                <p className="font-semibold text-base md:text-lg text-foreground truncate">Teacher Directory</p>
                <p className="text-muted-foreground text-sm md:text-base">View all teachers and performance</p>
              </div>
              <ArrowRight className="size-5 md:size-6 text-muted-foreground shrink-0 ml-2" />
            </CardContent>
          </Link>
        </Card>

        <Card className="hover:shadow-xl transition-all cursor-pointer border-2 hover:border-primary/30">
          <Link to="/finance">
            <CardContent className="p-4 md:p-6 flex items-center justify-between">
              <div className="space-y-1 flex-1 min-w-0">
                <p className="font-semibold text-base md:text-lg text-foreground truncate">Finance Overview</p>
                <p className="text-muted-foreground text-sm md:text-base">Revenue, expenses, and collections</p>
              </div>
              <ArrowRight className="size-5 md:size-6 text-muted-foreground shrink-0 ml-2" />
            </CardContent>
          </Link>
        </Card>

        <Card className="hover:shadow-xl transition-all cursor-pointer border-2 hover:border-primary/30">
          <Link to="/discipline">
            <CardContent className="p-4 md:p-6 flex items-center justify-between">
              <div className="space-y-1 flex-1 min-w-0">
                <p className="font-semibold text-base md:text-lg text-foreground truncate">Discipline Cases</p>
                <p className="text-muted-foreground text-sm md:text-base">Active cases and decisions</p>
              </div>
              <ArrowRight className="size-5 md:size-6 text-muted-foreground shrink-0 ml-2" />
            </CardContent>
          </Link>
        </Card>
      </div>
    </div>
  );
}
