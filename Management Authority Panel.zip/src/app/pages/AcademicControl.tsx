import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Lock, Unlock, Calendar, CheckCircle, AlertCircle } from "lucide-react";
import { exams } from "../data/mockData";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { BackButton } from "../components/BackButton";
import { toast } from "sonner";

export default function AcademicControl() {
  const handleUnlockTimetable = () => {
    toast.success("Timetable unlocked for editing");
  };

  const handleViewTimetable = () => {
    toast.info("Opening timetable viewer...");
  };

  const handleOverride = () => {
    toast.warning("Emergency override mode activated");
  };

  const handleScheduleExam = () => {
    toast.info("Opening exam scheduling form...");
  };

  const handleLockMarks = (examName: string) => {
    toast.success(`Marks locked for ${examName}`);
  };

  const handlePublishResults = (examName: string) => {
    toast.success(`Results published for ${examName}`);
  };

  const handleViewEligibleStudents = () => {
    toast.info("Loading eligible students list...");
  };

  const handleApprovePromotion = () => {
    toast.success("Promotion approved successfully");
  };

  const handleReviewConditionalCases = () => {
    toast.info("Opening conditional promotion review...");
  };

  const handleReviewRetentionCases = () => {
    toast.warning("Opening retention cases review...");
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Academic Control</h1>
        <p className="text-slate-600 mt-1">
          Manage academic operations, timetables, and examinations
        </p>
      </div>

      {/* Timetable Control */}
      <Card>
        <CardHeader>
          <CardTitle>Timetable Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline">2025-2026</Badge>
                  <Badge className="bg-green-500">Active</Badge>
                </div>
                <p className="font-medium">Current Academic Year Timetable</p>
                <p className="text-sm text-slate-600 mt-1">
                  Last updated: 15 Aug 2025 • Status: Locked
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleUnlockTimetable}>
                  <Unlock className="size-4 mr-2" />
                  Unlock
                </Button>
                <Button size="sm" onClick={handleViewTimetable}>
                  <Calendar className="size-4 mr-2" />
                  View Timetable
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 border border-amber-300 bg-amber-50 rounded-lg">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline">Emergency Override</Badge>
                </div>
                <p className="font-medium">Temporary Schedule Adjustment</p>
                <p className="text-sm text-slate-600 mt-1">
                  Make emergency changes without unlocking main timetable
                </p>
              </div>
              <Button variant="outline" size="sm" onClick={handleOverride}>
                Override
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Exam Management */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Examination Management</CardTitle>
          <Button size="sm" onClick={handleScheduleExam}>Schedule New Exam</Button>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Exam Name</TableHead>
                  <TableHead>Classes</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Marks Submitted</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {exams.map((exam) => (
                  <TableRow key={exam.id}>
                    <TableCell className="font-medium">{exam.name}</TableCell>
                    <TableCell>{exam.classes}</TableCell>
                    <TableCell>{exam.startDate}</TableCell>
                    <TableCell>{exam.endDate}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>{exam.marksSubmitted}</span>
                        {parseInt(exam.marksSubmitted) < 50 && (
                          <AlertCircle className="size-4 text-amber-500" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{exam.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleLockMarks(exam.name)}>
                          <Lock className="size-4" />
                        </Button>
                        <Button size="sm" onClick={() => handlePublishResults(exam.name)}>Publish</Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Promotion Control */}
      <Card>
        <CardHeader>
          <CardTitle>Class Promotion Control</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
              <div>
                <p className="font-medium mb-1">Annual Promotion 2025-2026</p>
                <p className="text-sm text-slate-600">
                  Promote eligible students to next academic year
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleViewEligibleStudents}>
                  View Eligible Students
                </Button>
                <Button size="sm" onClick={handleApprovePromotion}>
                  <CheckCircle className="size-4 mr-2" />
                  Approve Promotion
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-4 border border-slate-200 rounded-lg">
                <Badge className="mb-2">Conditional Promotion</Badge>
                <p className="text-sm font-medium">23 Students Require Review</p>
                <p className="text-xs text-slate-600 mt-1">
                  Students with borderline performance
                </p>
                <Button variant="outline" size="sm" className="mt-3 w-full" onClick={handleReviewConditionalCases}>
                  Review Cases
                </Button>
              </div>

              <div className="p-4 border border-red-200 bg-red-50 rounded-lg">
                <Badge variant="destructive" className="mb-2">
                  Retention Cases
                </Badge>
                <p className="text-sm font-medium">5 Students Under Consideration</p>
                <p className="text-xs text-slate-600 mt-1">
                  Students who may need to repeat the year
                </p>
                <Button variant="outline" size="sm" className="mt-3 w-full" onClick={handleReviewRetentionCases}>
                  Review Cases
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Academic Calendar */}
      <Card>
        <CardHeader>
          <CardTitle>Academic Calendar</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[
              { event: "Mid-Term Examination", date: "15-25 Mar 2026", status: "Upcoming" },
              { event: "Parent-Teacher Meeting", date: "10 Mar 2026", status: "Scheduled" },
              { event: "Annual Sports Day", date: "05 Apr 2026", status: "Scheduled" },
              { event: "Final Examination", date: "15-30 May 2026", status: "Scheduled" },
            ].map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 border border-slate-200 rounded-lg"
              >
                <div>
                  <p className="font-medium text-sm">{item.event}</p>
                  <p className="text-xs text-slate-600">{item.date}</p>
                </div>
                <Badge variant="outline">{item.status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
