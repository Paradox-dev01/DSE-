import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { Search, Eye, Download, Phone, Mail } from "lucide-react";
import { teachers } from "../data/mockData";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "../components/ui/sheet";
import { ScrollArea } from "../components/ui/scroll-area";
import { Progress } from "../components/ui/progress";
import { BackButton } from "../components/BackButton";
import { toast } from "sonner";

export default function Teachers() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTeacher, setSelectedTeacher] = useState<typeof teachers[0] | null>(null);

  const handleExportAll = () => {
    toast.success("Exporting all teacher records...");
  };

  const filteredTeachers = teachers.filter(
    (teacher) =>
      teacher.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      teacher.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <BackButton to="/" />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Teachers & Staff Directory</h1>
          <p className="text-slate-600 mt-1">
            Complete teacher records with performance metrics
          </p>
        </div>
        <Button onClick={handleExportAll}>
          <Download className="size-4 mr-2" />
          Export All
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
            <Input
              placeholder="Search by name or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{filteredTeachers.length} Teachers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Teacher ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Classes</TableHead>
                  <TableHead>Attendance</TableHead>
                  <TableHead>Syllabus Coverage</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTeachers.map((teacher) => (
                  <TableRow key={teacher.id}>
                    <TableCell className="font-medium">{teacher.id}</TableCell>
                    <TableCell>{teacher.name}</TableCell>
                    <TableCell>{teacher.department}</TableCell>
                    <TableCell>{teacher.subjects}</TableCell>
                    <TableCell>{teacher.classesAssigned}</TableCell>
                    <TableCell>{teacher.attendance.toFixed(1)}%</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={teacher.syllabusCoverage} className="w-16" />
                        <span className="text-sm">{teacher.syllabusCoverage.toFixed(0)}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedTeacher(teacher)}
                      >
                        <Eye className="size-4 mr-1" />
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Sheet open={!!selectedTeacher} onOpenChange={() => setSelectedTeacher(null)}>
        <SheetContent className="w-full sm:max-w-2xl">
          {selectedTeacher && (
            <>
              <SheetHeader>
                <SheetTitle className="text-2xl">{selectedTeacher.name}</SheetTitle>
                <SheetDescription>
                  {selectedTeacher.id} • {selectedTeacher.department}
                </SheetDescription>
              </SheetHeader>

              <ScrollArea className="h-[calc(100vh-10rem)] mt-6">
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Contact Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="size-4" />
                        {selectedTeacher.phone}
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="size-4" />
                        {selectedTeacher.email}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Professional Metrics</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-slate-600">Attendance Rate</span>
                          <span className="text-sm font-semibold">
                            {selectedTeacher.attendance.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={selectedTeacher.attendance} />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-slate-600">Syllabus Coverage</span>
                          <span className="text-sm font-semibold">
                            {selectedTeacher.syllabusCoverage.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={selectedTeacher.syllabusCoverage} />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-slate-600">Homework Checking Rate</span>
                          <span className="text-sm font-semibold">
                            {selectedTeacher.homeworkCheckingRate.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={selectedTeacher.homeworkCheckingRate} />
                      </div>
                      <div className="pt-3 border-t">
                        <div className="flex justify-between">
                          <span className="text-sm text-slate-600">Parent Feedback Score</span>
                          <div className="flex items-center gap-1">
                            <span className="text-lg font-bold text-yellow-600">
                              {selectedTeacher.parentFeedbackScore.toFixed(1)}
                            </span>
                            <span className="text-sm text-slate-500">/ 5.0</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Assignment Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between p-3 bg-slate-50 rounded">
                        <span className="text-sm text-slate-600">Department</span>
                        <span className="font-medium">{selectedTeacher.department}</span>
                      </div>
                      <div className="flex justify-between p-3 bg-slate-50 rounded">
                        <span className="text-sm text-slate-600">Primary Subject</span>
                        <span className="font-medium">{selectedTeacher.subjects}</span>
                      </div>
                      <div className="flex justify-between p-3 bg-slate-50 rounded">
                        <span className="text-sm text-slate-600">Classes Assigned</span>
                        <Badge>{selectedTeacher.classesAssigned}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>

              <div className="absolute bottom-0 left-0 right-0 p-6 bg-white border-t">
                <div className="grid grid-cols-3 gap-3">
                  <Button variant="outline">Approve Leave</Button>
                  <Button variant="outline">Issue Notice</Button>
                  <Button variant="outline">Schedule Meeting</Button>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
