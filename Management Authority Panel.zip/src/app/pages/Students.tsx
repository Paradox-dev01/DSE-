import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Search, Eye, Download, AlertCircle, Phone, MapPin } from "lucide-react";
import { students } from "../data/mockData";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "../components/ui/sheet";
import { ScrollArea } from "../components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { BackButton } from "../components/BackButton";
import { toast } from "sonner";

export default function Students() {
  const [searchQuery, setSearchQuery] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [performanceFilter, setPerformanceFilter] = useState("all");
  const [selectedStudent, setSelectedStudent] = useState<typeof students[0] | null>(null);

  const handleExportAll = () => {
    toast.success("Exporting all student records...");
  };

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesClass = classFilter === "all" || student.class === classFilter;
    const matchesPerformance =
      performanceFilter === "all" || student.performance === performanceFilter;
    return matchesSearch && matchesClass && matchesPerformance;
  });

  const getPerformanceBadge = (performance: string) => {
    switch (performance) {
      case "Excellent":
        return <Badge className="bg-green-500 text-white font-semibold shadow-sm">Excellent</Badge>;
      case "Good":
        return <Badge className="bg-blue-500 text-white font-semibold shadow-sm">Good</Badge>;
      case "Average":
        return <Badge className="bg-yellow-500 text-white font-semibold shadow-sm">Average</Badge>;
      case "Weak":
        return <Badge className="bg-red-500 text-white font-semibold shadow-sm">Weak</Badge>;
      default:
        return <Badge className="font-semibold">{performance}</Badge>;
    }
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 space-y-6 md:space-y-8 bg-background min-h-full">
      {/* Page Header */}
      <div className="space-y-4">
        <BackButton to="/" />
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground tracking-tight">Students Directory</h1>
            <p className="text-muted-foreground text-lg">
              Complete student records with full institutional visibility
            </p>
          </div>
          <Button className="shadow-md hover:shadow-lg transition-all px-6" onClick={handleExportAll}>
            <Download className="size-4 mr-2" />
            Export All
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card className="shadow-md border-2">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-2 focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="border-2">
                <SelectValue placeholder="All Classes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="6">Class 6</SelectItem>
                <SelectItem value="7">Class 7</SelectItem>
                <SelectItem value="8">Class 8</SelectItem>
                <SelectItem value="9">Class 9</SelectItem>
                <SelectItem value="10">Class 10</SelectItem>
              </SelectContent>
            </Select>
            <Select value={performanceFilter} onValueChange={setPerformanceFilter}>
              <SelectTrigger className="border-2">
                <SelectValue placeholder="All Performance Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Performance</SelectItem>
                <SelectItem value="Excellent">Excellent</SelectItem>
                <SelectItem value="Good">Good</SelectItem>
                <SelectItem value="Average">Average</SelectItem>
                <SelectItem value="Weak">Weak</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="border-2 hover:bg-accent hover:shadow-md transition-all">
              <AlertCircle className="size-4 mr-2" />
              Risk Alerts Only
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Students Table */}
      <Card className="shadow-md border-2">
        <CardHeader className="pb-4">
          <CardTitle className="text-foreground text-2xl">
            {filteredStudents.length} Students{" "}
            {(searchQuery || classFilter !== "all" || performanceFilter !== "all") &&
              "(Filtered)"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border-2 border-border rounded-xl overflow-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50 hover:bg-muted/50">
                  <TableHead className="font-semibold text-base">Student ID</TableHead>
                  <TableHead className="font-semibold text-base">Name</TableHead>
                  <TableHead className="font-semibold text-base">Class</TableHead>
                  <TableHead className="font-semibold text-base">Roll No</TableHead>
                  <TableHead className="font-semibold text-base">Attendance</TableHead>
                  <TableHead className="font-semibold text-base">Performance</TableHead>
                  <TableHead className="font-semibold text-base">Fee Status</TableHead>
                  <TableHead className="font-semibold text-base">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow
                    key={student.id}
                    className="hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => setSelectedStudent(student)}
                  >
                    <TableCell className="font-medium font-mono">{student.id}</TableCell>
                    <TableCell className="font-semibold text-foreground">{student.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-mono font-medium">
                        {student.class}-{student.section}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium">{student.rollNo}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span
                          className={
                            student.attendance < 75
                              ? "text-red-600 dark:text-red-400 font-bold"
                              : "text-foreground font-semibold"
                          }
                        >
                          {student.attendance.toFixed(1)}%
                        </span>
                        {student.attendance < 75 && (
                          <AlertCircle className="size-4 text-red-600 dark:text-red-400" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getPerformanceBadge(student.performance)}</TableCell>
                    <TableCell>
                      <Badge
                        variant={student.feeStatus === "Due" ? "destructive" : "outline"}
                        className="font-medium"
                      >
                        {student.feeStatus}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedStudent(student);
                        }}
                        className="hover:bg-accent hover:shadow-sm font-medium"
                      >
                        <Eye className="size-4 mr-1" />
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Student Detail Drawer */}
      <Sheet open={!!selectedStudent} onOpenChange={() => setSelectedStudent(null)}>
        <SheetContent className="w-full sm:max-w-2xl">
          {selectedStudent && (
            <>
              <SheetHeader className="pb-4 border-b border-border">
                <SheetTitle className="text-2xl md:text-3xl font-bold">{selectedStudent.name}</SheetTitle>
                <SheetDescription className="text-base">
                  {selectedStudent.id} • Class {selectedStudent.class}-{selectedStudent.section} • Roll No: {selectedStudent.rollNo}
                </SheetDescription>
              </SheetHeader>

              <ScrollArea className="h-[calc(100vh-10rem)] mt-6">
                <Tabs defaultValue="academic" className="w-full">
                  <TabsList className="grid w-full grid-cols-4 h-12">
                    <TabsTrigger value="academic" className="font-medium">Academic</TabsTrigger>
                    <TabsTrigger value="personal" className="font-medium">Personal</TabsTrigger>
                    <TabsTrigger value="financial" className="font-medium">Financial</TabsTrigger>
                    <TabsTrigger value="behavior" className="font-medium">Behavior</TabsTrigger>
                  </TabsList>

                  <TabsContent value="academic" className="space-y-4 mt-6">
                    <Card className="border-2 shadow-md">
                      <CardHeader className="pb-4">
                        <CardTitle className="text-xl">Academic Performance</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-6">
                          <div className="space-y-1">
                            <p className="text-sm text-muted-foreground font-medium">Attendance</p>
                            <p className="text-2xl md:text-3xl font-bold text-foreground">
                              {selectedStudent.attendance.toFixed(1)}%
                            </p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm text-muted-foreground font-medium">Performance Level</p>
                            <div className="mt-2">
                              {getPerformanceBadge(selectedStudent.performance)}
                            </div>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-3 font-medium">Subjects</p>
                          <div className="space-y-3">
                            {["Mathematics", "Science", "English", "Social Studies"].map(
                              (subject) => (
                                <div
                                  key={subject}
                                  className="flex items-center justify-between p-3 bg-muted/50 rounded-lg border border-border"
                                >
                                  <span className="font-medium">{subject}</span>
                                  <span className="font-bold text-foreground">
                                    {Math.floor(Math.random() * 30) + 70}%
                                  </span>
                                </div>
                              )
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="personal" className="space-y-4 mt-6">
                    <Card className="border-2 shadow-md">
                      <CardHeader className="pb-4">
                        <CardTitle className="text-xl">Personal Information</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-5">
                        <div>
                          <p className="text-sm text-muted-foreground font-medium mb-1">Guardian Name</p>
                          <p className="font-semibold text-foreground text-base">{selectedStudent.guardianName}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground font-medium mb-2">Contact</p>
                          <div className="flex items-center gap-2 text-base font-medium">
                            <Phone className="size-4" />
                            {selectedStudent.guardianPhone}
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground font-medium mb-2">Address</p>
                          <div className="flex items-start gap-2 text-base">
                            <MapPin className="size-4 mt-1" />
                            <span className="leading-relaxed">{selectedStudent.address}</span>
                          </div>
                        </div>
                        {selectedStudent.medicalNotes && (
                          <div className="p-4 bg-yellow-50 dark:bg-yellow-950/30 border-2 border-yellow-200 dark:border-yellow-900 rounded-xl">
                            <p className="font-semibold text-yellow-900 dark:text-yellow-200 mb-2">
                              Medical Notes
                            </p>
                            <p className="text-sm text-yellow-800 dark:text-yellow-300 leading-relaxed">
                              {selectedStudent.medicalNotes}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="financial" className="space-y-4 mt-6">
                    <Card className="border-2 shadow-md">
                      <CardHeader className="pb-4">
                        <CardTitle className="text-xl">Financial Information</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-5">
                        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-xl border-2 border-border">
                          <span className="font-medium text-foreground">Fee Status</span>
                          <Badge
                            variant={
                              selectedStudent.feeStatus === "Due" ? "destructive" : "outline"
                            }
                            className="font-medium text-base px-3 py-1"
                          >
                            {selectedStudent.feeStatus}
                          </Badge>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground font-medium mb-3">Payment History</p>
                          <div className="space-y-3">
                            {["Q4 2025", "Q3 2025", "Q2 2025"].map((quarter) => (
                              <div
                                key={quarter}
                                className="flex justify-between p-3 border-2 border-border rounded-lg hover:border-primary/30 transition-colors"
                              >
                                <span className="font-medium">{quarter}</span>
                                <span className="text-green-600 dark:text-green-400 font-semibold">
                                  ₹25,000 - Paid
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="behavior" className="space-y-4 mt-6">
                    <Card className="border-2 shadow-md">
                      <CardHeader className="pb-4">
                        <CardTitle className="text-xl">Behavior Records</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between p-5 bg-muted/50 rounded-xl border-2 border-border">
                          <span className="font-medium text-foreground">Total Incidents</span>
                          <span className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground">
                            {selectedStudent.incidents}
                          </span>
                        </div>
                        {selectedStudent.incidents === 0 && (
                          <p className="text-muted-foreground mt-6 text-center leading-relaxed">
                            No incidents recorded
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </ScrollArea>

              <div className="absolute bottom-0 left-0 right-0 p-6 bg-card border-t-2 border-border shadow-lg">
                <div className="flex gap-3">
                  <Button variant="outline" className="flex-1 border-2 font-medium">
                    <Download className="size-4 mr-2" />
                    Download Profile
                  </Button>
                  <Button variant="outline" className="flex-1 border-2 font-medium">
                    Flag Attention
                  </Button>
                  <Button variant="destructive" className="flex-1 shadow-md font-medium">
                    Suspend
                  </Button>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}