import { useState } from "react";
import { Outlet, Link, useLocation, useNavigate } from "react-router";
import { 
  LayoutDashboard, 
  GraduationCap, 
  Users, 
  BookOpen, 
  DollarSign, 
  UserPlus, 
  AlertTriangle, 
  BarChart3, 
  Bell, 
  FileText, 
  Shield,
  Search,
  Menu,
  X,
  ChevronRight,
  Sun,
  Moon,
  MessageSquare,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { ScrollArea } from "../components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetDescription } from "../components/ui/sheet";
import { schoolInfo, criticalAlerts } from "../data/mockData";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../components/ui/dropdown-menu";
import { Toaster } from "../components/ui/sonner";
import { toast } from "sonner";
import { useTheme } from "../contexts/ThemeContext";

const navigationItems = [
  { path: "/", label: "Executive Dashboard", icon: LayoutDashboard },
  { path: "/academic", label: "Academic Control", icon: BookOpen },
  { path: "/students", label: "Students", icon: GraduationCap },
  { path: "/teachers", label: "Teachers & Staff", icon: Users },
  { path: "/finance", label: "Finance Overview", icon: DollarSign },
  { path: "/admissions", label: "Admissions", icon: UserPlus },
  { path: "/discipline", label: "Discipline & Cases", icon: AlertTriangle },
  { path: "/reports", label: "Reports & Analytics", icon: BarChart3 },
  { path: "/notices", label: "Notices & Announcements", icon: Bell },
  { path: "/communication", label: "Communication Center", icon: MessageSquare },
  { path: "/policy", label: "Policy & Rules", icon: Shield },
  { path: "/system-logs", label: "System Logs", icon: FileText },
];

export default function MainLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [showAlerts, setShowAlerts] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const handleMarkAllAsRead = () => {
    toast.success("All notifications marked as read");
    setShowNotifications(false);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900 text-red-900 dark:text-red-200";
      case "high":
        return "bg-orange-50 dark:bg-orange-950/30 border-orange-200 dark:border-orange-900 text-orange-900 dark:text-orange-200";
      case "medium":
        return "bg-yellow-50 dark:bg-yellow-950/30 border-yellow-200 dark:border-yellow-900 text-yellow-900 dark:text-yellow-200";
      default:
        return "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900 text-blue-900 dark:text-blue-200";
    }
  };

  const Sidebar = () => (
    <div className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col shadow-xl overflow-hidden" style={{ height: '100%' }}>
      <div className="p-6 border-b border-sidebar-border bg-gradient-to-br from-sidebar to-sidebar flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="size-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg ring-2 ring-blue-400/30">
            <span className="text-lg font-bold">{schoolInfo.logo}</span>
          </div>
          <div>
            <div className="font-semibold text-sidebar-foreground">{schoolInfo.name}</div>
            <div className="text-xs text-sidebar-foreground/70 mt-0.5">{schoolInfo.academicYear}</div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <nav className="p-3 space-y-1">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-lg ring-1 ring-blue-400/30"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground hover:shadow-md"
                }`}
              >
                <Icon className={`size-5 transition-transform duration-200 ${isActive ? "scale-110" : "group-hover:scale-110"}`} />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );

  return (
    <div className="h-screen flex flex-col bg-background">
      <Toaster position="top-right" />
      {/* Top Executive Bar */}
      <header className="bg-card border-b border-border h-14 md:h-16 flex items-center justify-between px-3 md:px-6 z-10 shadow-sm backdrop-blur-sm bg-card/80">
        <div className="flex items-center gap-2 md:gap-4 flex-1 min-w-0">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden hover:bg-accent shrink-0">
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64">
              <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
              <SheetDescription className="sr-only">
                Main navigation menu for the school management panel
              </SheetDescription>
              <Sidebar />
            </SheetContent>
          </Sheet>

          <Badge
            variant={schoolInfo.status === "Open" ? "default" : "secondary"}
            className="font-semibold px-2 md:px-3 py-1 md:py-1.5 shadow-sm text-xs md:text-sm shrink-0"
          >
            {schoolInfo.status}
          </Badge>

          <div className="relative hidden md:block flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              placeholder="Search students, teachers, classes..."
              className="pl-10 w-full bg-background border-border focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
        </div>

        <div className="flex items-center gap-1 md:gap-2 shrink-0">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="hover:bg-accent rounded-lg size-9 md:size-10"
          >
            {theme === "dark" ? (
              <Sun className="size-4 md:size-5 text-foreground" />
            ) : (
              <Moon className="size-4 md:size-5 text-foreground" />
            )}
          </Button>

          <Sheet open={showNotifications} onOpenChange={setShowNotifications}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="relative hover:bg-accent rounded-lg size-9 md:size-10">
                <Bell className="size-4 md:size-5" />
                <Badge className="absolute -top-1 -right-1 size-4 md:size-5 flex items-center justify-center p-0 text-[10px] md:text-xs shadow-sm">
                  8
                </Badge>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:w-96 flex flex-col p-4 md:p-6">
              <SheetTitle className="text-base md:text-lg font-semibold">Notifications</SheetTitle>
              <SheetDescription className="text-sm text-muted-foreground">You have 8 unread notifications</SheetDescription>
              <div className="flex-1 overflow-y-auto mt-4 md:mt-6">
                <div className="space-y-3 pr-2">
                  {[
                    {
                      id: 1,
                      type: "admission",
                      title: "New Admission Request",
                      message: "Sarah Johnson submitted application for Grade 9",
                      time: "5 minutes ago",
                      unread: true,
                    },
                    {
                      id: 2,
                      type: "finance",
                      title: "Payment Received",
                      message: "₹50,000 received from Michael Chen (Student ID: ST-2024)",
                      time: "1 hour ago",
                      unread: true,
                    },
                    {
                      id: 3,
                      type: "discipline",
                      title: "Incident Report Filed",
                      message: "New incident reported in Grade 10-A classroom",
                      time: "2 hours ago",
                      unread: true,
                    },
                    {
                      id: 4,
                      type: "academic",
                      title: "Exam Schedule Updated",
                      message: "Mid-term exam dates have been revised for all grades",
                      time: "3 hours ago",
                      unread: true,
                    },
                    {
                      id: 5,
                      type: "staff",
                      title: "Leave Request",
                      message: "Ms. Emily Rodriguez requested leave for March 15-17",
                      time: "5 hours ago",
                      unread: false,
                    },
                    {
                      id: 6,
                      type: "system",
                      title: "System Backup Complete",
                      message: "Daily backup completed successfully at 2:00 AM",
                      time: "Yesterday",
                      unread: false,
                    },
                    {
                      id: 7,
                      type: "admission",
                      title: "Interview Scheduled",
                      message: "Parent meeting scheduled with David Kim for March 10",
                      time: "Yesterday",
                      unread: false,
                    },
                    {
                      id: 8,
                      type: "finance",
                      title: "Fee Reminder Sent",
                      message: "Automated fee reminders sent to 45 students",
                      time: "2 days ago",
                      unread: false,
                    },
                  ].map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-3 md:p-4 rounded-xl border transition-all cursor-pointer hover:shadow-md ${
                        notification.unread
                          ? "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900/50"
                          : "bg-card border-border hover:border-primary/20"
                      }`}
                    >
                      <div className="flex items-start gap-2 md:gap-3">
                        {notification.unread && (
                          <div className="size-2 rounded-full bg-blue-600 mt-2 shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm md:text-base text-foreground mb-1">
                            {notification.title}
                          </h4>
                          <p className="text-xs md:text-sm text-muted-foreground mb-2 line-clamp-2">
                            {notification.message}
                          </p>
                          <p className="text-[10px] md:text-xs text-muted-foreground">{notification.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-border flex-shrink-0">
                <Button variant="outline" className="w-full" size="sm" onClick={handleMarkAllAsRead}>
                  Mark All as Read
                </Button>
              </div>
            </SheetContent>
          </Sheet>

          <Button
            variant="ghost"
            size="icon"
            className="relative hover:bg-accent rounded-lg size-9 md:size-10 hidden sm:flex"
            onClick={() => setShowAlerts(!showAlerts)}
          >
            <AlertTriangle className="size-4 md:size-5 text-orange-500" />
            <Badge className="absolute -top-1 -right-1 size-4 md:size-5 flex items-center justify-center p-0 text-[10px] md:text-xs bg-red-500 shadow-sm">
              5
            </Badge>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-1 md:gap-2 hover:bg-accent rounded-lg px-2 md:px-3">
                <div className="size-7 md:size-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 text-white flex items-center justify-center font-semibold shadow-md text-xs">
                  PM
                </div>
                <span className="hidden md:inline font-medium text-sm">Principal</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 md:w-56">
              <DropdownMenuItem onSelect={() => navigate("/profile")}>
                My Profile
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => navigate("/institution-settings")}>
                Institution Settings
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => navigate("/audit-logs")}>
                Audit Logs
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600">Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Desktop */}
        <aside className="hidden lg:block">
          <Sidebar />
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className={`transition-all duration-300 ${showAlerts ? "xl:mr-80" : ""}`}>
            <Outlet />
          </div>
        </main>

        {/* Right Alerts Panel */}
        {showAlerts && (
          <aside className="hidden xl:flex w-80 bg-card border-l border-border fixed right-0 top-14 md:top-16 bottom-0 flex-col shadow-xl">
            <div className="flex items-center justify-between p-4 md:p-5 border-b border-border bg-gradient-to-r from-card to-muted/30 flex-shrink-0">
              <h3 className="font-semibold text-sm md:text-base text-foreground">Critical Alerts</h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowAlerts(false)}
                className="size-8 hover:bg-accent rounded-lg"
              >
                <X className="size-4" />
              </Button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <div className="p-3 md:p-4 space-y-3">
                {criticalAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-3 md:p-4 rounded-xl border-2 transition-all hover:shadow-lg cursor-pointer ${getSeverityColor(alert.severity)}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-sm">{alert.title}</h4>
                      <Badge variant="outline" className="text-[10px] md:text-xs capitalize font-medium">
                        {alert.severity}
                      </Badge>
                    </div>
                    <p className="text-xs md:text-sm mb-3 opacity-90 leading-relaxed">{alert.description}</p>
                    {alert.students && (
                      <div className="text-xs md:text-sm space-y-1.5">
                        {alert.students.slice(0, 3).map((student, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            <ChevronRight className="size-3 md:size-3.5" />
                            <span className="font-medium">{student}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    {alert.teachers && (
                      <div className="text-xs md:text-sm space-y-1.5">
                        {alert.teachers.map((teacher, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            <ChevronRight className="size-3 md:size-3.5" />
                            <span className="font-medium">{teacher}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}