import { createBrowserRouter } from "react-router";
import MainLayout from "./layouts/MainLayout";
import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import Teachers from "./pages/Teachers";
import AcademicControl from "./pages/AcademicControl";
import Finance from "./pages/Finance";
import Admissions from "./pages/Admissions";
import Discipline from "./pages/Discipline";
import Reports from "./pages/Reports";
import Notices from "./pages/Notices";
import Policy from "./pages/Policy";
import SystemLogs from "./pages/SystemLogs";
import Profile from "./pages/Profile";
import InstitutionSettings from "./pages/InstitutionSettings";
import AuditLogs from "./pages/AuditLogs";
import Communication from "./pages/Communication";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: MainLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "students", Component: Students },
      { path: "teachers", Component: Teachers },
      { path: "academic", Component: AcademicControl },
      { path: "finance", Component: Finance },
      { path: "admissions", Component: Admissions },
      { path: "discipline", Component: Discipline },
      { path: "reports", Component: Reports },
      { path: "notices", Component: Notices },
      { path: "communication", Component: Communication },
      { path: "policy", Component: Policy },
      { path: "system-logs", Component: SystemLogs },
      { path: "profile", Component: Profile },
      { path: "institution-settings", Component: InstitutionSettings },
      { path: "audit-logs", Component: AuditLogs },
    ],
  },
]);