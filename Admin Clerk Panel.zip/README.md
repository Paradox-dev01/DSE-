
  # Admin Clerk Panel

  This is a code bundle for Admin Clerk Panel. The original project is available at https://www.figma.com/design/5zoyv7ZuLZke6Sr5536Hbr/Admin-Clerk-Panel.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  