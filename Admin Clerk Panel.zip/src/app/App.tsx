import { useState } from 'react';
import { Toaster, toast } from 'sonner';
import { ThemeProvider } from './context/ThemeContext';
import { DataProvider } from './context/DataContext';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Students from './components/StudentsNew';
import AddStudentForm from './components/AddStudentFormNew';
import Attendance from './components/Attendance';
import Fees from './components/Fees';
import CollectFeeForm from './components/CollectFeeForm';
import Admissions from './components/Admissions';
import Routine from './components/Routine';
import Exams from './components/Exams';
import Certificates from './components/Certificates';
import Teachers from './components/Teachers';
import Communication from './components/Communication';
import Transport from './components/Transport';
import Library from './components/Library';
import Profile from './components/Profile';
import Settings from './components/Settings';
import Checklist from './components/Checklist';
import QuickActionsSettings, { QuickAction } from './components/QuickActionsSettings';
import ConfirmDialog from './components/ConfirmDialog';

function AppContent() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [showAddStudentForm, setShowAddStudentForm] = useState(false);
  const [showCollectFeeForm, setShowCollectFeeForm] = useState(false);
  const [showChecklist, setShowChecklist] = useState(false);
  const [showQuickActionsSettings, setShowQuickActionsSettings] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const [quickActions, setQuickActions] = useState<QuickAction[]>([
    { id: 'checklist', label: 'Checklist', icon: 'ListTodo', color: 'from-indigo-600 to-indigo-500', enabled: true },
    { id: 'add-student', label: 'Add Student', icon: 'UserPlus', color: 'from-blue-600 to-blue-500', enabled: true },
    { id: 'collect-fee', label: 'Collect Fee', icon: 'DollarSign', color: 'from-green-600 to-green-500', enabled: true },
    { id: 'mark-attendance', label: 'Mark Attendance', icon: 'ClipboardCheck', color: 'from-orange-600 to-orange-500', enabled: true },
    { id: 'create-exam', label: 'Create Exam', icon: 'FileText', color: 'from-purple-600 to-purple-500', enabled: true },
  ]);

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'add-student':
        setShowAddStudentForm(true);
        break;
      case 'collect-fee':
        setShowCollectFeeForm(true);
        break;
      case 'mark-attendance':
        setActiveSection('attendance');
        break;
      case 'create-exam':
        setActiveSection('exams');
        break;
      case 'checklist':
        setShowChecklist(true);
        break;
    }
  };

  const handleProfileAction = (action: string) => {
    switch (action) {
      case 'profile':
        setActiveSection('profile');
        break;
      case 'settings':
        setActiveSection('settings');
        break;
      case 'logout':
        setShowLogoutConfirm(true);
        break;
    }
  };

  const handleLogout = () => {
    toast.success('Logged out successfully');
    setShowLogoutConfirm(false);
    // In a real app, you would redirect to login page
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <Dashboard
            onQuickAction={handleQuickAction}
            onNavigate={setActiveSection}
            quickActions={quickActions}
            onCustomizeActions={() => setShowQuickActionsSettings(true)}
          />
        );
      case 'students':
        return <Students onAddStudent={() => setShowAddStudentForm(true)} />;
      case 'attendance':
        return <Attendance />;
      case 'fees':
        return <Fees onCollectFee={() => setShowCollectFeeForm(true)} />;
      case 'admissions':
        return <Admissions />;
      case 'routine':
        return <Routine />;
      case 'exams':
        return <Exams />;
      case 'certificates':
        return <Certificates />;
      case 'teachers':
        return <Teachers />;
      case 'communication':
        return <Communication />;
      case 'transport':
        return <Transport />;
      case 'library':
        return <Library />;
      case 'profile':
        return <Profile />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard onQuickAction={handleQuickAction} />;
    }
  };

  return (
    <>
      <Toaster position="top-right" richColors theme="system" />
      <Layout
        activeSection={activeSection}
        onSectionChange={setActiveSection}
        onQuickAction={handleQuickAction}
        onProfileAction={handleProfileAction}
      >
        {renderContent()}
      </Layout>

      {showAddStudentForm && (
        <AddStudentForm onClose={() => setShowAddStudentForm(false)} />
      )}

      {showCollectFeeForm && (
        <CollectFeeForm
          onClose={() => setShowCollectFeeForm(false)}
          onSubmit={() => setShowCollectFeeForm(false)}
        />
      )}

      {showChecklist && (
        <Checklist onClose={() => setShowChecklist(false)} />
      )}

      {showQuickActionsSettings && (
        <QuickActionsSettings
          onClose={() => setShowQuickActionsSettings(false)}
          availableActions={quickActions}
          onSave={setQuickActions}
        />
      )}

      {showLogoutConfirm && (
        <ConfirmDialog
          title="Confirm Logout"
          message="Are you sure you want to logout?"
          confirmText="Logout"
          cancelText="Cancel"
          variant="warning"
          onConfirm={handleLogout}
          onCancel={() => setShowLogoutConfirm(false)}
        />
      )}
    </>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </ThemeProvider>
  );
}