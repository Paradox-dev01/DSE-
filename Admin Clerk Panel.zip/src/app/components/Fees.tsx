import { useState } from 'react';
import { Search, DollarSign, Receipt, AlertCircle, Download, Eye, TrendingUp, Send } from 'lucide-react';
import { useData } from '../context/DataContext';
import { toast } from 'sonner';

interface FeesProps {
  onCollectFee: () => void;
}

export default function Fees({ onCollectFee }: FeesProps) {
  const { feeRecords } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [viewingTransaction, setViewingTransaction] = useState<string | null>(null);

  const filteredRecords = feeRecords.filter(
    (record) =>
      record.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalCollected = feeRecords.reduce((sum, record) => sum + record.paid, 0);
  const totalDue = feeRecords.reduce((sum, record) => sum + record.due, 0);
  const todayCollection = 45280;

  const record = viewingTransaction ? feeRecords.find((r) => r.id === viewingTransaction) : null;

  const handleDownloadReceipt = (recordId: string) => {
    const rec = feeRecords.find((r) => r.id === recordId);
    if (rec) {
      toast.success(`Receipt downloaded for ${rec.studentName}`);
    }
  };

  const handleSendNotice = (recordId: string) => {
    const rec = feeRecords.find((r) => r.id === recordId);
    if (rec && rec.due > 0) {
      toast.success(`Payment reminder sent to guardian of ${rec.studentName}`);
    } else {
      toast.error('No pending dues for this student');
    }
  };

  const handleExportFees = () => {
    const csvContent = [
      ['Invoice ID', 'Student ID', 'Student Name', 'Class', 'Total Fee', 'Paid', 'Due', 'Status'].join(','),
      ...feeRecords.map((r) => [r.id, r.studentId, r.studentName, r.class, r.totalFee, r.paid, r.due, r.status].join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'fee-records.csv';
    a.click();
    toast.success('Fee records exported successfully');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">Fees & Payments</h2>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Manage fee collection and payment records • {filteredRecords.length} records
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportFees}
            className="px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 text-xs font-medium flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            Export
          </button>
          <button
            onClick={onCollectFee}
            className="px-4 py-2 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg hover:from-green-700 hover:to-green-600 text-sm font-medium flex items-center gap-2 shadow-md hover:shadow-lg transition-all"
          >
            <DollarSign className="w-4 h-4" />
            Collect Payment
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-gradient-to-br from-green-600 to-green-500 p-3 rounded-lg shadow-md">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1 text-sm font-medium text-green-600 dark:text-green-400">
              <TrendingUp className="w-4 h-4" />
              +12%
            </div>
          </div>
          <h3 className="text-gray-600 dark:text-gray-400 text-sm mb-1">Total Collected</h3>
          <p className="text-3xl font-semibold text-gray-900 dark:text-white">₹{totalCollected.toLocaleString()}</p>
          <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">Across all students</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-gradient-to-br from-red-600 to-red-500 p-3 rounded-lg shadow-md">
              <AlertCircle className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 dark:text-gray-400 text-sm mb-1">Total Due</h3>
          <p className="text-3xl font-semibold text-gray-900 dark:text-white">₹{totalDue.toLocaleString()}</p>
          <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">Pending collection</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-gradient-to-br from-blue-600 to-blue-500 p-3 rounded-lg shadow-md">
              <Receipt className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 dark:text-gray-400 text-sm mb-1">Today's Collection</h3>
          <p className="text-3xl font-semibold text-gray-900 dark:text-white">₹{todayCollection.toLocaleString()}</p>
          <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">23 transactions</p>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
          <input
            type="text"
            placeholder="Search by student name, ID, or invoice number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
          />
        </div>
      </div>

      {/* Fee Records Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Invoice ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Student
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Class
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Total Fee
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Paid
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Due
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredRecords.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">{record.id}</td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">{record.studentName}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{record.studentId}</div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">{record.class}</td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                    ₹{record.totalFee.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-sm text-green-600 dark:text-green-400 font-medium">
                    ₹{record.paid.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-sm text-red-600 dark:text-red-400 font-medium">
                    ₹{record.due.toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        record.status === 'Paid'
                          ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                          : record.status === 'Partial'
                          ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'
                          : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                      }`}
                    >
                      {record.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setViewingTransaction(record.id)}
                        className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        title="View Transactions"
                      >
                        <Eye className="w-3.5 h-3.5 text-gray-600 dark:text-gray-400" />
                      </button>
                      {record.due > 0 && (
                        <>
                          <button
                            onClick={onCollectFee}
                            className="px-2.5 py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/50 text-[10px] font-medium transition-colors"
                          >
                            Collect
                          </button>
                          <button
                            onClick={() => handleSendNotice(record.id)}
                            className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                            title="Send Notice to Guardian"
                          >
                            <Send className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400" />
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => handleDownloadReceipt(record.id)}
                        className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        title="Download Receipt"
                      >
                        <Download className="w-3.5 h-3.5 text-gray-600 dark:text-gray-400" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction History Modal */}
      {record && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Transaction History</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{record.studentName} • {record.id}</p>
              </div>
              <button
                onClick={() => setViewingTransaction(null)}
                className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto max-h-[calc(90vh-150px)]">
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Total Fee</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">₹{record.totalFee.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Paid</p>
                    <p className="text-lg font-semibold text-green-600 dark:text-green-400">₹{record.paid.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Due</p>
                    <p className="text-lg font-semibold text-red-600 dark:text-red-400">₹{record.due.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">Payment History</h4>
                {record.transactions.length === 0 ? (
                  <p className="text-gray-600 dark:text-gray-400 text-center py-8">No transactions yet</p>
                ) : (
                  <div className="space-y-3">
                    {record.transactions.map((txn) => (
                      <div key={txn.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium text-gray-900 dark:text-white">₹{txn.amount.toLocaleString()}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{txn.method} • {txn.date}</p>
                          </div>
                          <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Receipt: {txn.receiptNo}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
