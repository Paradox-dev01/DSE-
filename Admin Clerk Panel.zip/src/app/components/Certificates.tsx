import { useState } from 'react';
import { Search, FileText, Download, Printer } from 'lucide-react';
import { useData } from '../context/DataContext';
import { toast } from 'sonner';

type CertificateType = 'id-card' | 'admit-card' | 'transfer' | 'character';

export default function Certificates() {
  const { students } = useData();
  const [certificateType, setCertificateType] = useState<CertificateType>('id-card');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState('');

  const filteredStudents = students.filter((s) =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleGenerate = () => {
    if (!selectedStudent) {
      toast.error('Please select a student');
      return;
    }
    const student = students.find((s) => s.id === selectedStudent);
    toast.success(`${getCertificateName(certificateType)} generated for ${student?.name}`);
  };

  const handleDownload = () => {
    if (!selectedStudent) {
      toast.error('Please select a student');
      return;
    }
    toast.success('Certificate downloaded successfully');
  };

  const handlePrint = () => {
    if (!selectedStudent) {
      toast.error('Please select a student');
      return;
    }
    toast.success('Printing certificate...');
  };

  const getCertificateName = (type: CertificateType) => {
    switch (type) {
      case 'id-card': return 'ID Card';
      case 'admit-card': return 'Admit Card';
      case 'transfer': return 'Transfer Certificate';
      case 'character': return 'Character Certificate';
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Certificates</h2>
        <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">Generate and print student certificates</p>
      </div>

      {/* Certificate Type Selection */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">Certificate Type</label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {(['id-card', 'admit-card', 'transfer', 'character'] as CertificateType[]).map((type) => (
            <button
              key={type}
              onClick={() => setCertificateType(type)}
              className={`px-4 py-3 border-2 rounded-lg text-xs font-medium transition-all ${
                certificateType === type
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                  : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-400'
              }`}
            >
              {getCertificateName(type)}
            </button>
          ))}
        </div>
      </div>

      {/* Student Search */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Search Student</label>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
              <input
                type="text"
                placeholder="Search by name or ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Select Student</label>
            <select
              value={selectedStudent}
              onChange={(e) => setSelectedStudent(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
            >
              <option value="">Choose a student</option>
              {filteredStudents.map((student) => (
                <option key={student.id} value={student.id}>
                  {student.id} - {student.name} ({student.class}-{student.section})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Preview & Actions */}
      {selectedStudent && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Certificate Preview</h3>
            <div className="flex items-center gap-2">
              <button
                onClick={handleGenerate}
                className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-xs font-medium flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5" />
                Generate
              </button>
              <button
                onClick={handleDownload}
                className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-xs font-medium flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Download
              </button>
              <button
                onClick={handlePrint}
                className="px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 text-xs font-medium flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                Print
              </button>
            </div>
          </div>

          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-8 border-2 border-dashed border-gray-300 dark:border-gray-600 text-center">
            <FileText className="w-16 h-16 mx-auto text-gray-400 dark:text-gray-500 mb-3" />
            <p className="text-sm text-gray-600 dark:text-gray-400">Certificate preview will appear here</p>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">{getCertificateName(certificateType)}</p>
          </div>
        </div>
      )}
    </div>
  );
}
