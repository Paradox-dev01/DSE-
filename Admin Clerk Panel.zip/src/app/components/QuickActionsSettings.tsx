import { useState } from 'react';
import { ListTodo, UserPlus, DollarSign, ClipboardCheck, FileText, GripVertical, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

interface QuickActionsSettingsProps {
  onClose: () => void;
  availableActions: QuickAction[];
  onSave: (actions: QuickAction[]) => void;
}

export interface QuickAction {
  id: string;
  label: string;
  icon: string;
  color: string;
  enabled: boolean;
}

const iconMap: Record<string, any> = {
  'ListTodo': ListTodo,
  'UserPlus': UserPlus,
  'DollarSign': DollarSign,
  'ClipboardCheck': ClipboardCheck,
  'FileText': FileText,
};

export default function QuickActionsSettings({ onClose, availableActions, onSave }: QuickActionsSettingsProps) {
  const [actions, setActions] = useState<QuickAction[]>(availableActions);

  const toggleAction = (id: string) => {
    setActions(actions.map(action =>
      action.id === id ? { ...action, enabled: !action.enabled } : action
    ));
  };

  const moveUp = (index: number) => {
    if (index === 0) return;
    const newActions = [...actions];
    [newActions[index - 1], newActions[index]] = [newActions[index], newActions[index - 1]];
    setActions(newActions);
  };

  const moveDown = (index: number) => {
    if (index === actions.length - 1) return;
    const newActions = [...actions];
    [newActions[index], newActions[index + 1]] = [newActions[index + 1], newActions[index]];
    setActions(newActions);
  };

  const handleSave = () => {
    onSave(actions);
    toast.success('Quick actions updated');
    onClose();
  };

  const handleReset = () => {
    const resetActions = actions.map(action => ({ ...action, enabled: true }));
    setActions(resetActions);
    toast.info('Reset to default settings');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Customize Quick Actions</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Choose which actions to show and reorder them
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Actions List */}
        <div className="p-6 max-h-96 overflow-y-auto">
          <div className="space-y-2">
            {actions.map((action, index) => {
              const Icon = iconMap[action.icon];
              return (
                <div
                  key={action.id}
                  className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
                    action.enabled
                      ? 'bg-white dark:bg-gray-700 border-gray-200 dark:border-gray-600'
                      : 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 opacity-60'
                  }`}
                >
                  {/* Drag Handle */}
                  <div className="flex flex-col gap-0.5">
                    <button
                      onClick={() => moveUp(index)}
                      disabled={index === 0}
                      className="p-0.5 hover:bg-gray-200 dark:hover:bg-gray-600 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                      title="Move up"
                    >
                      <GripVertical className="w-3.5 h-3.5 text-gray-400 rotate-90" />
                    </button>
                    <button
                      onClick={() => moveDown(index)}
                      disabled={index === actions.length - 1}
                      className="p-0.5 hover:bg-gray-200 dark:hover:bg-gray-600 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                      title="Move down"
                    >
                      <GripVertical className="w-3.5 h-3.5 text-gray-400 -rotate-90" />
                    </button>
                  </div>

                  {/* Action Icon & Label */}
                  <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center bg-gradient-to-r ${action.color}`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="flex-1 text-sm font-medium text-gray-900 dark:text-white">
                    {action.label}
                  </span>

                  {/* Toggle */}
                  <button
                    onClick={() => toggleAction(action.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      action.enabled
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                        : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                    }`}
                  >
                    {action.enabled ? (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        Visible
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        Hidden
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
          <div className="flex items-center justify-between gap-3">
            <button
              onClick={handleReset}
              className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors"
            >
              Reset to Default
            </button>
            <div className="flex gap-2">
              <button
                onClick={onClose}
                className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
