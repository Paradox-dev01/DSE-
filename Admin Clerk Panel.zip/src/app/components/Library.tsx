import { useState } from 'react';
import { Search, BookOpen, UserCheck, AlertCircle } from 'lucide-react';

const mockBooks = [
  { id: 'BK001', title: 'Physics Textbook - Class 10', author: 'NCERT', isbn: '978-81-7450-787-4', copies: 50, available: 35, borrowed: 15 },
  { id: 'BK002', title: 'Mathematics Guide', author: 'R.D. Sharma', isbn: '978-81-8488-487-0', copies: 40, available: 28, borrowed: 12 },
  { id: 'BK003', title: 'English Grammar', author: 'Wren & Martin', isbn: '978-93-5040-021-0', copies: 45, available: 40, borrowed: 5 },
];

const mockIssued = [
  { id: 'IS001', studentId: 'STD001', studentName: 'Aarav Kumar', bookTitle: 'Physics Textbook - Class 10', issueDate: '2026-05-10', dueDate: '2026-05-24', status: 'Active' },
  { id: 'IS002', studentId: 'STD003', studentName: 'Arjun Patel', bookTitle: 'Mathematics Guide', issueDate: '2026-05-08', dueDate: '2026-05-22', status: 'Overdue' },
];

export default function Library() {
  const [activeTab, setActiveTab] = useState<'books' | 'issued'>('books');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredBooks = mockBooks.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Library Management</h2>
        <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">Manage books and track issued books</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 dark:bg-blue-900/30 p-2.5 rounded-lg">
              <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">Total Books</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">135</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 dark:bg-green-900/30 p-2.5 rounded-lg">
              <UserCheck className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">Available</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">103</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-orange-100 dark:bg-orange-900/30 p-2.5 rounded-lg">
              <BookOpen className="w-5 h-5 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">Issued</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">32</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-red-100 dark:bg-red-900/30 p-2.5 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">Overdue</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">1</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
          <input
            type="text"
            placeholder="Search books..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
        <div className="flex border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setActiveTab('books')}
            className={`px-4 py-2 text-xs font-medium transition-colors ${
              activeTab === 'books'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            Books Catalog
          </button>
          <button
            onClick={() => setActiveTab('issued')}
            className={`px-4 py-2 text-xs font-medium transition-colors ${
              activeTab === 'issued'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            Issued Books
          </button>
        </div>

        <div className="p-4">
          {activeTab === 'books' ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                  <tr>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Book ID</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Title</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Author</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">ISBN</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Available</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Borrowed</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {filteredBooks.map((book) => (
                    <tr key={book.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                      <td className="px-4 py-2.5 text-xs font-medium text-gray-900 dark:text-white">{book.id}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{book.title}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{book.author}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{book.isbn}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{book.copies}</td>
                      <td className="px-4 py-2.5 text-xs text-green-600 dark:text-green-400 font-medium">{book.available}</td>
                      <td className="px-4 py-2.5 text-xs text-orange-600 dark:text-orange-400 font-medium">{book.borrowed}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                  <tr>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Issue ID</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Student</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Book Title</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Issue Date</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Due Date</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {mockIssued.map((issue) => (
                    <tr key={issue.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                      <td className="px-4 py-2.5 text-xs font-medium text-gray-900 dark:text-white">{issue.id}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">
                        {issue.studentName}<br />
                        <span className="text-[10px] text-gray-500">{issue.studentId}</span>
                      </td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{issue.bookTitle}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{issue.issueDate}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{issue.dueDate}</td>
                      <td className="px-4 py-2.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                          issue.status === 'Active'
                            ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                            : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                        }`}>
                          {issue.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
