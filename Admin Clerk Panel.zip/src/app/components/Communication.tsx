import { useState } from 'react';
import { Send, Upload, Users, MessageSquare, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import ConfirmDialog from './ConfirmDialog';

export default function Communication() {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [audience, setAudience] = useState('all');
  const [channel, setChannel] = useState<string[]>([]);
  const [noticeToDelete, setNoticeToDelete] = useState<number | null>(null);
  const [recentNotices, setRecentNotices] = useState([
    { id: 1, title: 'Holiday Notice', date: '2026-05-20', audience: 'All', channels: ['SMS', 'App'] },
    { id: 2, title: 'Exam Schedule Released', date: '2026-05-18', audience: 'Class 10', channels: ['Email', 'App'] },
    { id: 3, title: 'Parent Teacher Meeting', date: '2026-05-15', audience: 'All', channels: ['SMS', 'Email', 'App'] },
  ]);

  const handleSend = () => {
    if (!title || !message) {
      toast.error('Please fill in all required fields');
      return;
    }
    if (channel.length === 0) {
      toast.error('Please select at least one channel');
      return;
    }

    const newNotice = {
      id: Date.now(),
      title,
      date: new Date().toISOString().split('T')[0],
      audience: audience === 'all' ? 'All' : audience.replace('class-', 'Class '),
      channels: [...channel],
    };

    setRecentNotices([newNotice, ...recentNotices]);
    toast.success(`Notice sent successfully via ${channel.join(', ')}`);
    setTitle('');
    setMessage('');
    setChannel([]);
  };

  const toggleChannel = (ch: string) => {
    if (channel.includes(ch)) {
      setChannel(channel.filter((c) => c !== ch));
    } else {
      setChannel([...channel, ch]);
    }
  };

  const handleDeleteNotice = () => {
    if (noticeToDelete) {
      setRecentNotices(recentNotices.filter(n => n.id !== noticeToDelete));
      toast.success('Notice deleted from all recipients');
      setNoticeToDelete(null);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Communication</h2>
        <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">Send notices and announcements to students and parents</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Send Notice Form */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Send Notice</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Notice title"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                Message <span className="text-red-500">*</span>
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter your message here..."
                rows={6}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Attach File (Optional)</label>
              <button className="w-full px-3 py-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg hover:border-blue-500 dark:hover:border-blue-400 text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-xs flex items-center justify-center gap-2">
                <Upload className="w-4 h-4" />
                Click to upload
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Audience</label>
              <select
                value={audience}
                onChange={(e) => setAudience(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
              >
                <option value="all">All Students & Parents</option>
                <option value="class-10">Class 10 Only</option>
                <option value="class-9">Class 9 Only</option>
                <option value="class-8">Class 8 Only</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Channels</label>
              <div className="grid grid-cols-3 gap-2">
                {['SMS', 'Email', 'App'].map((ch) => (
                  <button
                    key={ch}
                    onClick={() => toggleChannel(ch)}
                    className={`px-3 py-2 border-2 rounded-lg text-xs font-medium transition-all ${
                      channel.includes(ch)
                        ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                        : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-400'
                    }`}
                  >
                    {ch}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleSend}
              className="w-full px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              Send Notice
            </button>
          </div>
        </div>

        {/* Recent Notices */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Broadcast History</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {recentNotices.length === 0 ? (
              <div className="py-8 text-center text-xs text-gray-500 dark:text-gray-400">
                No broadcasts yet
              </div>
            ) : (
              recentNotices.map((notice) => (
                <div key={notice.id} className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <p className="text-xs font-medium text-gray-900 dark:text-white">{notice.title}</p>
                      <p className="text-[10px] text-gray-600 dark:text-gray-400 mt-0.5">{notice.date}</p>
                      <div className="flex items-center gap-1 mt-1.5">
                        <Users className="w-3 h-3 text-gray-500 dark:text-gray-400" />
                        <span className="text-[10px] text-gray-600 dark:text-gray-400">{notice.audience}</span>
                      </div>
                      <div className="flex gap-1 mt-1.5">
                        {notice.channels.map((ch) => (
                          <span key={ch} className="px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded text-[10px] font-medium">
                            {ch}
                          </span>
                        ))}
                      </div>
                    </div>
                    <button
                      onClick={() => setNoticeToDelete(notice.id)}
                      className="p-1.5 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                      title="Delete from everyone"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation */}
      {noticeToDelete && (
        <ConfirmDialog
          title="Delete Notice from Everyone"
          message="Are you sure you want to delete this notice? This will remove it from all recipients and cannot be undone."
          confirmText="Delete from All"
          cancelText="Cancel"
          variant="danger"
          onConfirm={handleDeleteNotice}
          onCancel={() => setNoticeToDelete(null)}
        />
      )}
    </div>
  );
}
