import { useState } from 'react';
import { Calendar, Copy, Save, CheckCircle, Download } from 'lucide-react';
import { useData } from '../context/DataContext';
import { toast } from 'sonner';
import LoadingSpinner from './LoadingSpinner';

type AttendanceStatus = 'P' | 'A' | 'L' | null;

export default function Attendance() {
  const { students, saveAttendance: saveAttendanceToContext } = useData();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedClass, setSelectedClass] = useState('10');
  const [selectedSection, setSelectedSection] = useState('A');
  const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>({});
  const [saving, setSaving] = useState(false);

  const filteredStudents = students.filter(
    (s) => s.class === selectedClass && s.section === selectedSection && s.status === 'Active'
  );

  const markAttendance = (studentId: string, status: AttendanceStatus) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: prev[studentId] === status ? null : status,
    }));
  };

  const markAllPresent = () => {
    const allPresent: Record<string, AttendanceStatus> = {};
    filteredStudents.forEach((student) => {
      allPresent[student.id] = 'P';
    });
    setAttendance(allPresent);
    toast.success('All students marked as present');
  };

  const copyPreviousDay = () => {
    toast.info('Previous day attendance copied (feature coming soon)');
  };

  const saveAttendance = async () => {
    setSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const records = Object.entries(attendance).map(([studentId, status]) => ({
      studentId,
      status: status || 'A',
    }));

    saveAttendanceToContext({
      date: selectedDate,
      class: selectedClass,
      section: selectedSection,
      records: records as any,
    });

    setSaving(false);
    toast.success('Attendance saved successfully! Guardians will be notified via SMS.');
  };

  const handleExportAttendance = () => {
    const csvContent = [
      ['Date', 'Class', 'Section', 'Student ID', 'Student Name', 'Status'].join(','),
      ...filteredStudents.map((student) => [
        selectedDate,
        selectedClass,
        selectedSection,
        student.id,
        student.name,
        attendance[student.id] || 'Not Marked',
      ].join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance-${selectedClass}-${selectedSection}-${selectedDate}.csv`;
    a.click();
    toast.success('Attendance exported successfully');
  };

  const presentCount = Object.values(attendance).filter((s) => s === 'P').length;
  const absentCount = Object.values(attendance).filter((s) => s === 'A').length;
  const lateCount = Object.values(attendance).filter((s) => s === 'L').length;
  const unmarked = filteredStudents.length - presentCount - absentCount - lateCount;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">Attendance Management</h2>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Mark daily attendance for students • Class {selectedClass}-{selectedSection}
        </p>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Date</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Class</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="10">Class 10</option>
              <option value="9">Class 9</option>
              <option value="8">Class 8</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Section</label>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="A">A</option>
              <option value="B">B</option>
              <option value="C">C</option>
            </select>
          </div>
          <div className="flex items-end gap-2">
            <button
              onClick={markAllPresent}
              className="flex-1 px-4 py-2 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg hover:from-green-700 hover:to-green-600 text-sm font-medium shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              All Present
            </button>
            <button
              onClick={copyPreviousDay}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              title="Copy from previous day"
            >
              <Copy className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400">Total Students</p>
          <p className="text-2xl font-semibold text-gray-900 dark:text-white mt-1">{filteredStudents.length}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400">Present</p>
          <p className="text-2xl font-semibold text-green-600 dark:text-green-400 mt-1">{presentCount}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400">Absent</p>
          <p className="text-2xl font-semibold text-red-600 dark:text-red-400 mt-1">{absentCount}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400">Late</p>
          <p className="text-2xl font-semibold text-orange-600 dark:text-orange-400 mt-1">{lateCount}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400">Unmarked</p>
          <p className="text-2xl font-semibold text-gray-600 dark:text-gray-400 mt-1">{unmarked}</p>
        </div>
      </div>

      {/* Attendance Grid */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700">
        {saving ? (
          <div className="py-12">
            <LoadingSpinner size="lg" text="Saving attendance..." />
          </div>
        ) : filteredStudents.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-gray-600 dark:text-gray-400">No students found for Class {selectedClass}-{selectedSection}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Student
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Roll No.
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Present
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Absent
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Late
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {filteredStudents.map((student) => {
                  const status = attendance[student.id];
                  return (
                    <tr key={student.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">{student.name}</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">{student.id}</div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">
                        {student.roll}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => markAttendance(student.id, 'P')}
                          className={`w-12 h-12 rounded-lg font-semibold transition-all shadow-md hover:shadow-lg ${
                            status === 'P'
                              ? 'bg-gradient-to-br from-green-600 to-green-500 text-white scale-110'
                              : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                          }`}
                        >
                          P
                        </button>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => markAttendance(student.id, 'A')}
                          className={`w-12 h-12 rounded-lg font-semibold transition-all shadow-md hover:shadow-lg ${
                            status === 'A'
                              ? 'bg-gradient-to-br from-red-600 to-red-500 text-white scale-110'
                              : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                          }`}
                        >
                          A
                        </button>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => markAttendance(student.id, 'L')}
                          className={`w-12 h-12 rounded-lg font-semibold transition-all shadow-md hover:shadow-lg ${
                            status === 'L'
                              ? 'bg-gradient-to-br from-orange-600 to-orange-500 text-white scale-110'
                              : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                          }`}
                        >
                          L
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <button
          onClick={handleExportAttendance}
          disabled={filteredStudents.length === 0}
          className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 text-sm font-medium flex items-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download className="w-4 h-4" />
          Export
        </button>
        <button
          onClick={saveAttendance}
          disabled={saving || filteredStudents.length === 0}
          className="px-6 py-2 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-lg hover:from-blue-700 hover:to-blue-600 text-sm font-medium flex items-center gap-2 shadow-md hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Save className="w-4 h-4" />
          Save Attendance
        </button>
      </div>
    </div>
  );
}
