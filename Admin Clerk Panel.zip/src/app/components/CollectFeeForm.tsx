import { useState } from 'react';
import { X, Search, DollarSign, CheckCircle, AlertCircle } from 'lucide-react';
import { useData } from '../context/DataContext';
import { toast } from 'sonner';
import LoadingSpinner from './LoadingSpinner';

interface CollectFeeFormProps {
  onClose: () => void;
  onSubmit: () => void;
}

export default function CollectFeeForm({ onClose, onSubmit }: CollectFeeFormProps) {
  const { students, feeRecords, addPayment } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [loading, setLoading] = useState(false);

  const selectedStudent = selectedStudentId ? students.find((s) => s.id === selectedStudentId) : null;
  const feeRecord = selectedStudentId ? feeRecords.find((r) => r.studentId === selectedStudentId) : null;

  const handleSearch = () => {
    const student = students.find(
      (s) =>
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.id.toLowerCase().includes(searchTerm.toLowerCase())
    );
    if (student) {
      setSelectedStudentId(student.id);
    } else {
      toast.error('Student not found');
    }
  };

  const handleSubmit = async () => {
    if (!selectedStudentId || !amount || !paymentMethod) {
      toast.error('Please fill all required fields');
      return;
    }

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      toast.error('Invalid amount');
      return;
    }

    if (feeRecord && amountNum > feeRecord.due) {
      toast.error('Amount exceeds due amount');
      return;
    }

    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));

    addPayment(selectedStudentId, amountNum, paymentMethod);
    setLoading(false);
    toast.success('Payment collected successfully! Receipt sent to guardian via SMS.');
    onSubmit();
    onClose();
  };

  const breakdown = feeRecord
    ? [
        { type: 'Tuition Fee', amount: feeRecord.totalFee * 0.7 },
        { type: 'Transport Fee', amount: feeRecord.totalFee * 0.2 },
        { type: 'Exam Fee', amount: feeRecord.totalFee * 0.1 },
      ]
    : [];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Collect Payment</h2>
          <button
            onClick={onClose}
            disabled={loading}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-150px)] space-y-6">
          {loading ? (
            <div className="py-12">
              <LoadingSpinner size="lg" text="Processing payment..." />
            </div>
          ) : (
            <>
              {/* Step 1: Search Student */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Search Student <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
                    <input
                      type="text"
                      placeholder="Enter student name or ID..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                    />
                  </div>
                  <button
                    onClick={handleSearch}
                    className="px-6 py-2 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-lg hover:from-blue-700 hover:to-blue-600 font-medium shadow-md hover:shadow-lg transition-all"
                  >
                    Search
                  </button>
                </div>
              </div>

              {/* Step 2: Student Details & Dues */}
              {selectedStudent && feeRecord && (
                <>
                  <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white">{selectedStudent.name}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {selectedStudent.id} • Class {selectedStudent.class}-{selectedStudent.section}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600 dark:text-gray-400">Total Due</p>
                        <p className="text-2xl font-semibold text-red-600 dark:text-red-400">
                          ₹{feeRecord.due.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Fee Breakdown */}
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white mb-3">Fee Breakdown</h4>
                    <div className="space-y-2">
                      {breakdown.map((item, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
                        >
                          <span className="text-sm text-gray-700 dark:text-gray-300">{item.type}</span>
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            ₹{Math.round(item.amount).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Step 3: Enter Amount */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Amount to Collect <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500" />
                      <input
                        type="number"
                        placeholder="Enter amount"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                      />
                    </div>
                    <div className="mt-2 flex gap-2">
                      <button
                        onClick={() => setAmount(feeRecord.due.toString())}
                        className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 text-sm transition-colors"
                      >
                        Full Amount
                      </button>
                      <button
                        onClick={() => setAmount(Math.round(feeRecord.due / 2).toString())}
                        className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 text-sm transition-colors"
                      >
                        Half Amount
                      </button>
                    </div>
                    {amount && parseFloat(amount) > feeRecord.due && (
                      <p className="mt-2 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" />
                        Amount exceeds due amount
                      </p>
                    )}
                  </div>

                  {/* Step 4: Payment Method */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Payment Method <span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-3 gap-3">
                      {['Cash', 'Mobile', 'Bank'].map((method) => (
                        <button
                          key={method}
                          onClick={() => setPaymentMethod(method)}
                          className={`px-4 py-3 border-2 rounded-lg font-medium transition-all ${
                            paymentMethod === method
                              ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 shadow-md'
                              : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-400 dark:hover:border-gray-500'
                          }`}
                        >
                          {method}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Summary */}
                  <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                      Payment Summary
                    </h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Amount Collecting:</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          ₹{amount ? Number(amount).toLocaleString() : '0'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Remaining Due:</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          ₹
                          {amount
                            ? Math.max(0, feeRecord.due - Number(amount)).toLocaleString()
                            : feeRecord.due.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Payment Method:</span>
                        <span className="font-medium text-gray-900 dark:text-white">{paymentMethod || '-'}</span>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/30">
          <button
            onClick={onClose}
            disabled={loading}
            className="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!selectedStudentId || !amount || !paymentMethod || loading}
            className="px-6 py-2 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg hover:from-green-700 hover:to-green-600 font-medium shadow-md hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Confirm Payment
          </button>
        </div>
      </div>
    </div>
  );
}
