import { useState } from 'react';
import { Users, ClipboardCheck, DollarSign, AlertCircle, Calendar, TrendingUp, ArrowUpRight, Bell, X, ListTodo, UserPlus, FileText, Settings } from 'lucide-react';
import { useData } from '../context/DataContext';
import { QuickAction } from './QuickActionsSettings';

interface DashboardProps {
  onQuickAction: (action: string) => void;
  onNavigate: (section: string) => void;
  quickActions: QuickAction[];
  onCustomizeActions: () => void;
}

const iconMap: Record<string, any> = {
  'ListTodo': ListTodo,
  'UserPlus': UserPlus,
  'DollarSign': DollarSign,
  'ClipboardCheck': ClipboardCheck,
  'FileText': FileText,
};

export default function Dashboard({ onQuickAction, onNavigate, quickActions, onCustomizeActions }: DashboardProps) {
  const { students, feeRecords } = useData();

  const [notices, setNotices] = useState([
    { id: 1, title: 'Annual Sports Day', date: '2026-05-25', type: 'Event', priority: 'High', screen: 'communication' },
    { id: 2, title: 'Parent-Teacher Meeting', date: '2026-05-28', type: 'Meeting', priority: 'High', screen: 'communication' },
    { id: 3, title: 'Fee Submission Deadline', date: '2026-05-30', type: 'Reminder', priority: 'Medium', screen: 'fees' },
    { id: 4, title: 'Holiday - Memorial Day', date: '2026-05-31', type: 'Holiday', priority: 'Low', screen: 'routine' },
  ]);

  const handleNoticeClick = (screen: string) => {
    onNavigate(screen);
  };

  const handleDeleteNotice = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotices(notices.filter(n => n.id !== id));
  };

  const activeStudents = students.filter((s) => s.status === 'Active').length;
  const totalCollectedToday = 45280;
  const totalDue = feeRecords.reduce((sum, record) => sum + record.due, 0);

  const stats = [
    {
      title: 'Total Students',
      value: activeStudents.toString(),
      subtitle: `${students.length} total enrolled`,
      icon: Users,
      color: 'from-blue-600 to-blue-500',
      change: '+12%',
      changeType: 'positive',
    },
    {
      title: 'Attendance Pending',
      value: '8',
      subtitle: 'Classes to mark',
      icon: ClipboardCheck,
      color: 'from-orange-600 to-orange-500',
      change: '3 today',
      changeType: 'neutral',
    },
    {
      title: 'Fees Collected Today',
      value: `₹${totalCollectedToday.toLocaleString()}`,
      subtitle: '23 transactions',
      icon: DollarSign,
      color: 'from-green-600 to-green-500',
      change: '+8%',
      changeType: 'positive',
    },
    {
      title: 'Total Due',
      value: `₹${totalDue.toLocaleString()}`,
      subtitle: 'Across all students',
      icon: AlertCircle,
      color: 'from-red-600 to-red-500',
      change: '-5%',
      changeType: 'positive',
    },
  ];

  const pendingTasks = [
    { task: 'Submit Math exam marks for Class 10-A', priority: 'High', time: '2 hours ago', action: 'View' },
    { task: 'Approve 5 admission applications', priority: 'High', time: '4 hours ago', action: 'Review' },
    { task: 'Mark attendance for Class 8-B', priority: 'Medium', time: '1 day ago', action: 'Mark' },
    { task: 'Process 3 refund requests', priority: 'Low', time: '2 days ago', action: 'Process' },
  ];

  const upcomingExams = [
    { exam: 'Midterm Exam - Math', class: 'Class 10', date: 'Apr 25, 2026', daysLeft: 6 },
    { exam: 'Quarterly Exam - Science', class: 'Class 9', date: 'Apr 28, 2026', daysLeft: 9 },
    { exam: 'Unit Test - English', class: 'Class 8', date: 'May 2, 2026', daysLeft: 13 },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Dashboard</h2>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">Welcome back! Here's what's happening today.</p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-gray-600 dark:text-gray-400">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Last updated: Just now</span>
        </div>
      </div>

      {/* Quick Actions and Notice Board */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Quick Actions */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Quick Actions</h3>
            <button
              onClick={onCustomizeActions}
              className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              title="Customize quick actions"
            >
              <Settings className="w-4 h-4 text-gray-600 dark:text-gray-400" />
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {quickActions.filter(action => action.enabled).map((action) => {
              const Icon = iconMap[action.icon];
              return (
                <button
                  key={action.id}
                  onClick={() => onQuickAction(action.id)}
                  className={`px-4 py-2 bg-gradient-to-r ${action.color} text-white rounded-lg hover:shadow-lg text-sm font-medium shadow-md transition-all flex items-center gap-2`}
                >
                  <Icon className="w-4 h-4" />
                  {action.label}
                </button>
              );
            })}
            {quickActions.filter(action => action.enabled).length === 0 && (
              <div className="text-sm text-gray-500 dark:text-gray-400 py-4">
                No quick actions enabled. Click the settings icon to customize.
              </div>
            )}
          </div>
        </div>

        {/* Notice Board */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-2">
            <Bell className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Notice Board</h3>
          </div>
          <div className="p-3 max-h-40 overflow-y-auto">
            {notices.length === 0 ? (
              <div className="py-8 text-center text-xs text-gray-500 dark:text-gray-400">
                No notices
              </div>
            ) : (
              <div className="space-y-2">
                {notices.map((notice) => (
                  <div
                    key={notice.id}
                    onClick={() => handleNoticeClick(notice.screen)}
                    className="w-full bg-blue-50 dark:bg-blue-900/20 rounded-lg p-2 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0 text-left">
                        <p className="text-xs font-medium text-gray-900 dark:text-white truncate">{notice.title}</p>
                        <p className="text-[10px] text-gray-600 dark:text-gray-400">{notice.date}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-medium whitespace-nowrap ${
                          notice.priority === 'High'
                            ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                            : notice.priority === 'Medium'
                            ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-400'
                        }`}>
                          {notice.priority}
                        </span>
                        <button
                          onClick={(e) => handleDeleteNotice(notice.id, e)}
                          className="p-0.5 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                          title="Delete notice"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow p-4 border border-gray-100 dark:border-gray-700">
              <div className="flex items-center justify-between mb-3">
                <div className={`bg-gradient-to-br ${stat.color} p-2.5 rounded-lg shadow-md`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <div className={`flex items-center gap-0.5 text-xs font-medium ${
                  stat.changeType === 'positive' ? 'text-green-600 dark:text-green-400' : 'text-gray-600 dark:text-gray-400'
                }`}>
                  {stat.changeType === 'positive' && <ArrowUpRight className="w-3.5 h-3.5" />}
                  {stat.change}
                </div>
              </div>
              <h3 className="text-gray-600 dark:text-gray-400 text-xs mb-0.5">{stat.title}</h3>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white mb-0.5">{stat.value}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">{stat.subtitle}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Pending Tasks */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Pending Tasks</h3>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {pendingTasks.map((item, index) => (
              <div key={index} className="p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{item.task}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{item.time}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                        item.priority === 'High'
                          ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                          : item.priority === 'Medium'
                          ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-400'
                      }`}
                    >
                      {item.priority}
                    </span>
                    <button className="px-2.5 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-[10px] font-medium">
                      {item.action}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Exams */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Upcoming Exams</h3>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {upcomingExams.map((exam, index) => (
              <div key={index} className="p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                <div className="flex items-start gap-2">
                  <Calendar className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{exam.exam}</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">{exam.class}</p>
                    <div className="flex items-center justify-between mt-1.5">
                      <p className="text-xs text-gray-500 dark:text-gray-500">{exam.date}</p>
                      <span className="text-[10px] font-medium text-blue-600 dark:text-blue-400">{exam.daysLeft} days</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
