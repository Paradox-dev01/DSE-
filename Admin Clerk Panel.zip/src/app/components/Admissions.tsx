import { useState } from 'react';
import { Search, Filter, CheckCircle, XCircle, Clock, FileCheck } from 'lucide-react';
import { useData } from '../context/DataContext';
import { toast } from 'sonner';

const mockAdmissions = [
  { id: 'ADM001', name: 'Rahul Verma', class: '10', section: 'A', status: 'Pending Docs', guardianPhone: '+91 9876501234', appliedDate: '2026-05-15' },
  { id: 'ADM002', name: 'Sneha Patel', class: '9', section: 'B', status: 'Verified', guardianPhone: '+91 9876501235', appliedDate: '2026-05-16' },
  { id: 'ADM003', name: 'Amit Kumar', class: '8', section: 'A', status: 'New', guardianPhone: '+91 9876501236', appliedDate: '2026-05-18' },
  { id: 'ADM004', name: 'Priya Sharma', class: '10', section: 'B', status: 'Pending Docs', guardianPhone: '+91 9876501237', appliedDate: '2026-05-19' },
];

export default function Admissions() {
  const { addStudent, students } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [admissions, setAdmissions] = useState(mockAdmissions);

  const filteredAdmissions = admissions.filter((adm) => {
    const matchesSearch = adm.name.toLowerCase().includes(searchTerm.toLowerCase()) || adm.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || adm.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const handleApprove = (admission: any) => {
    const newStudentId = `STD${String(students.length + 1).padStart(3, '0')}`;
    const newStudent = {
      id: newStudentId,
      name: admission.name,
      class: admission.class,
      section: admission.section,
      roll: String(Math.floor(Math.random() * 40) + 1).padStart(2, '0'),
      status: 'Active' as const,
      dob: '2010-01-01',
      gender: 'Male',
      address: 'Address',
      phone: admission.guardianPhone,
      guardianName: 'Guardian',
      guardianPhone: admission.guardianPhone,
      guardianEmail: 'guardian@email.com',
      admissionDate: new Date().toISOString().split('T')[0],
    };

    addStudent(newStudent);
    setAdmissions(admissions.filter((a) => a.id !== admission.id));
    toast.success(`Admission approved! Student ID: ${newStudentId}`);
  };

  const handleReject = (admissionId: string) => {
    setAdmissions(admissions.filter((a) => a.id !== admissionId));
    toast.error('Admission rejected');
  };

  const statusCounts = {
    new: admissions.filter((a) => a.status === 'New').length,
    pendingDocs: admissions.filter((a) => a.status === 'Pending Docs').length,
    verified: admissions.filter((a) => a.status === 'Verified').length,
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Admissions</h2>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">Manage admission applications • {filteredAdmissions.length} applications</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 dark:bg-blue-900/30 p-2.5 rounded-lg">
              <FileCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">Total Applications</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">{admissions.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-orange-100 dark:bg-orange-900/30 p-2.5 rounded-lg">
              <Clock className="w-5 h-5 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">New</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">{statusCounts.new}</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-yellow-100 dark:bg-yellow-900/30 p-2.5 rounded-lg">
              <Clock className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">Pending Docs</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">{statusCounts.pendingDocs}</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 dark:bg-green-900/30 p-2.5 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-xs text-gray-600 dark:text-gray-400">Verified</p>
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">{statusCounts.verified}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
            <input
              type="text"
              placeholder="Search by name or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
            />
          </div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
          >
            <option value="all">All Status</option>
            <option value="New">New</option>
            <option value="Pending Docs">Pending Docs</option>
            <option value="Verified">Verified</option>
          </select>
        </div>
      </div>

      {/* Admissions List */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">ID</th>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Class</th>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Guardian Phone</th>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Applied Date</th>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredAdmissions.map((admission) => (
                <tr key={admission.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <td className="px-4 py-2.5 text-xs font-medium text-gray-900 dark:text-white">{admission.id}</td>
                  <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{admission.name}</td>
                  <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{admission.class}-{admission.section}</td>
                  <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{admission.guardianPhone}</td>
                  <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{admission.appliedDate}</td>
                  <td className="px-4 py-2.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                      admission.status === 'Verified' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400' :
                      admission.status === 'Pending Docs' ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400' :
                      'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400'
                    }`}>
                      {admission.status}
                    </span>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleApprove(admission)}
                        className="px-2.5 py-1 bg-green-600 text-white rounded-lg hover:bg-green-700 text-[10px] font-medium flex items-center gap-1"
                      >
                        <CheckCircle className="w-3 h-3" />
                        Approve
                      </button>
                      <button
                        onClick={() => handleReject(admission.id)}
                        className="px-2.5 py-1 bg-red-600 text-white rounded-lg hover:bg-red-700 text-[10px] font-medium flex items-center gap-1"
                      >
                        <XCircle className="w-3 h-3" />
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
