import { useState } from 'react';
import { Download, Upload, Save, Calendar } from 'lucide-react';
import { toast } from 'sonner';

type RoutineType = 'class' | 'teacher';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const periods = ['9:00-10:00', '10:00-11:00', '11:00-12:00', '12:00-1:00', '2:00-3:00', '3:00-4:00'];

const mockClassRoutine: Record<string, Record<string, string>> = {
  'Monday': { '9:00-10:00': 'Math - Mr. Sharma', '10:00-11:00': 'English - Ms. Patel', '11:00-12:00': 'Science - Dr. Kumar', '12:00-1:00': 'Break', '2:00-3:00': 'History - Mr. Singh', '3:00-4:00': 'PT - Mr. Reddy' },
  'Tuesday': { '9:00-10:00': 'Science - Dr. Kumar', '10:00-11:00': 'Math - Mr. Sharma', '11:00-12:00': 'English - Ms. Patel', '12:00-1:00': 'Break', '2:00-3:00': 'Geography - Ms. Verma', '3:00-4:00': 'Art - Ms. Desai' },
};

export default function Routine() {
  const [routineType, setRoutineType] = useState<RoutineType>('class');
  const [selectedClass, setSelectedClass] = useState('10');
  const [selectedSection, setSelectedSection] = useState('A');
  const [selectedTeacher, setSelectedTeacher] = useState('Mr. Sharma');
  const [routine, setRoutine] = useState(mockClassRoutine);

  const handleExport = () => {
    const csvContent = [
      ['Day', ...periods].join(','),
      ...days.map((day) => [day, ...periods.map((period) => routine[day]?.[period] || '')].join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `routine-${routineType}-${routineType === 'class' ? `${selectedClass}-${selectedSection}` : selectedTeacher}.csv`;
    a.click();
    toast.success('Routine exported successfully');
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const csv = event.target?.result as string;
          const lines = csv.split('\n');
          const newRoutine: Record<string, Record<string, string>> = {};

          const headers = lines[0].split(',').slice(1);

          for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;

            const cells = line.split(',');
            const day = cells[0];
            newRoutine[day] = {};

            for (let j = 0; j < headers.length; j++) {
              newRoutine[day][headers[j]] = cells[j + 1] || '';
            }
          }

          setRoutine(newRoutine);
          toast.success('Routine imported successfully');
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  const handleSave = () => {
    toast.success('Routine saved successfully');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Routine Management</h2>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">Create and manage class and teacher schedules</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleImport}
            className="px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 text-xs font-medium flex items-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" />
            Import
          </button>
          <button
            onClick={handleExport}
            className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-xs font-medium flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            Export
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-100 dark:border-gray-700">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">View Type</label>
            <select
              value={routineType}
              onChange={(e) => setRoutineType(e.target.value as RoutineType)}
              className="w-full px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
            >
              <option value="class">Class Routine</option>
              <option value="teacher">Teacher Schedule</option>
            </select>
          </div>
          {routineType === 'class' ? (
            <>
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Class</label>
                <select
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
                >
                  <option value="10">Class 10</option>
                  <option value="9">Class 9</option>
                  <option value="8">Class 8</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Section</label>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
                >
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                </select>
              </div>
            </>
          ) : (
            <div className="col-span-2">
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">Teacher</label>
              <select
                value={selectedTeacher}
                onChange={(e) => setSelectedTeacher(e.target.value)}
                className="w-full px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
              >
                <option value="Mr. Sharma">Mr. Sharma - Mathematics</option>
                <option value="Ms. Patel">Ms. Patel - English</option>
                <option value="Dr. Kumar">Dr. Kumar - Science</option>
              </select>
            </div>
          )}
          <div className="flex items-end">
            <button
              onClick={handleSave}
              className="w-full px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 text-xs font-medium flex items-center justify-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              Save
            </button>
          </div>
        </div>
      </div>

      {/* Routine Grid */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Day / Period</th>
                {periods.map((period) => (
                  <th key={period} className="px-4 py-2 text-center text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{period}</th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {days.map((day) => (
                <tr key={day} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="px-4 py-2.5 text-xs font-medium text-gray-900 dark:text-white">{day}</td>
                  {periods.map((period) => (
                    <td key={period} className="px-4 py-2.5 text-center">
                      <div className="text-xs text-gray-900 dark:text-white bg-blue-50 dark:bg-blue-900/20 px-2 py-1.5 rounded border border-blue-200 dark:border-blue-800">
                        {routine[day]?.[period] || '-'}
                      </div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
