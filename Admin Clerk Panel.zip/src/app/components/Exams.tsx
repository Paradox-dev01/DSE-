import { useState } from 'react';
import { Plus, Edit, FileText, Download, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

const mockExams = [
  { id: 'EX001', name: 'Midterm Exam', class: '10-A', startDate: '2026-06-01', endDate: '2026-06-10', status: 'Upcoming', totalMarks: 500 },
  { id: 'EX002', name: 'Quarterly Exam', class: '9-B', startDate: '2026-05-25', endDate: '2026-06-05', status: 'Ongoing', totalMarks: 450 },
  { id: 'EX003', name: 'Unit Test', class: '8-A', startDate: '2026-04-15', endDate: '2026-04-20', status: 'Completed', totalMarks: 200 },
];

const mockMarks = [
  { studentId: 'STD001', studentName: 'Aarav Kumar', math: 85, science: 90, english: 78, total: 253, percentage: 84.3 },
  { studentId: 'STD002', studentName: 'Diya Sharma', math: 92, science: 88, english: 85, total: 265, percentage: 88.3 },
  { studentId: 'STD003', studentName: 'Arjun Patel', math: 78, science: 82, english: 80, total: 240, percentage: 80.0 },
];

export default function Exams() {
  const [activeTab, setActiveTab] = useState<'exams' | 'marks'>('exams');
  const [selectedExam, setSelectedExam] = useState('EX003');

  const handleCreateExam = () => {
    toast.success('Create exam feature coming soon');
  };

  const handleExportMarks = () => {
    const csvContent = [
      ['Student ID', 'Name', 'Math', 'Science', 'English', 'Total', 'Percentage'].join(','),
      ...mockMarks.map((m) => [m.studentId, m.studentName, m.math, m.science, m.english, m.total, m.percentage].join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'exam-marks.csv';
    a.click();
    toast.success('Marks exported successfully');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Exams & Marks</h2>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">Manage exams and enter marks</p>
        </div>
        <button
          onClick={handleCreateExam}
          className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-xs font-medium flex items-center gap-1.5"
        >
          <Plus className="w-3.5 h-3.5" />
          Create Exam
        </button>
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
        <div className="flex border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setActiveTab('exams')}
            className={`px-4 py-2 text-xs font-medium transition-colors ${
              activeTab === 'exams'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            Exams
          </button>
          <button
            onClick={() => setActiveTab('marks')}
            className={`px-4 py-2 text-xs font-medium transition-colors ${
              activeTab === 'marks'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            Marks Entry
          </button>
        </div>

        <div className="p-4">
          {activeTab === 'exams' ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                  <tr>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Exam ID</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Class</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Start Date</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">End Date</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {mockExams.map((exam) => (
                    <tr key={exam.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                      <td className="px-4 py-2.5 text-xs font-medium text-gray-900 dark:text-white">{exam.id}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{exam.name}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{exam.class}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{exam.startDate}</td>
                      <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{exam.endDate}</td>
                      <td className="px-4 py-2.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                          exam.status === 'Completed' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400' :
                          exam.status === 'Ongoing' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400' :
                          'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'
                        }`}>
                          {exam.status}
                        </span>
                      </td>
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-1">
                          <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                            <Edit className="w-3.5 h-3.5 text-gray-600 dark:text-gray-400" />
                          </button>
                          <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                            <FileText className="w-3.5 h-3.5 text-gray-600 dark:text-gray-400" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <select
                  value={selectedExam}
                  onChange={(e) => setSelectedExam(e.target.value)}
                  className="px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white"
                >
                  {mockExams.filter(e => e.status === 'Completed').map((exam) => (
                    <option key={exam.id} value={exam.id}>{exam.name} - {exam.class}</option>
                  ))}
                </select>
                <button
                  onClick={handleExportMarks}
                  className="px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 text-xs font-medium flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export Marks
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                    <tr>
                      <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Student ID</th>
                      <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Name</th>
                      <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Math</th>
                      <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Science</th>
                      <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">English</th>
                      <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total</th>
                      <th className="px-4 py-2 text-left text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">%</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {mockMarks.map((mark) => (
                      <tr key={mark.studentId} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                        <td className="px-4 py-2.5 text-xs font-medium text-gray-900 dark:text-white">{mark.studentId}</td>
                        <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{mark.studentName}</td>
                        <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{mark.math}</td>
                        <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{mark.science}</td>
                        <td className="px-4 py-2.5 text-xs text-gray-900 dark:text-white">{mark.english}</td>
                        <td className="px-4 py-2.5 text-xs font-medium text-gray-900 dark:text-white">{mark.total}</td>
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-1">
                            <TrendingUp className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                            <span className="text-xs font-medium text-green-600 dark:text-green-400">{mark.percentage}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
