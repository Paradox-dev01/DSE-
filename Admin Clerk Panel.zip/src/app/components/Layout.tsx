import { useState } from 'react';
import {
  Home,
  Users,
  UserPlus,
  ClipboardCheck,
  Calendar,
  FileText,
  DollarSign,
  Award,
  GraduationCap,
  MessageSquare,
  Bus,
  BookOpen,
  Search,
  Bell,
  Plus,
  Menu,
  X,
  Moon,
  Sun,
  Settings,
  LogOut,
  User,
  ArrowLeft,
  Send,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface LayoutProps {
  children: React.ReactNode;
  activeSection: string;
  onSectionChange: (section: string) => void;
  onQuickAction: (action: string) => void;
  onProfileAction?: (action: string) => void;
}

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'students', label: 'Students', icon: Users },
  { id: 'admissions', label: 'Admissions', icon: UserPlus },
  { id: 'attendance', label: 'Attendance', icon: ClipboardCheck },
  { id: 'routine', label: 'Routine', icon: Calendar },
  { id: 'exams', label: 'Exams & Marks', icon: FileText },
  { id: 'fees', label: 'Fees & Payments', icon: DollarSign },
  { id: 'certificates', label: 'Certificates', icon: Award },
  { id: 'teachers', label: 'Teachers & Staff', icon: GraduationCap },
  { id: 'communication', label: 'Communication', icon: MessageSquare },
  { id: 'transport', label: 'Transport', icon: Bus },
  { id: 'library', label: 'Library', icon: BookOpen },
];

export default function Layout({ children, activeSection, onSectionChange, onQuickAction, onProfileAction }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showQuickCreate, setShowQuickCreate] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, message: 'New admission pending verification', type: 'warning', unread: true, screen: 'admissions' },
    { id: 2, message: 'Fee payment received for STD001', type: 'success', unread: true, screen: 'fees' },
    { id: 3, message: 'Attendance not marked for Class 8-B', type: 'error', unread: false, screen: 'attendance' },
  ]);
  const [showNotifications, setShowNotifications] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const handleNotificationClick = (screen: string) => {
    onSectionChange(screen);
    setShowNotifications(false);
  };

  const handleDeleteNotification = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const currentTime = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const unreadCount = notifications.filter((n) => n.unread).length;

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors">
      {/* Top Bar */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50 shadow-sm">
        <div className="flex items-center justify-between px-4 py-2">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-gray-700 dark:text-gray-300"
            >
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-500 rounded-lg flex items-center justify-center shadow-lg">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div className="hidden md:block">
                <h1 className="text-sm font-semibold text-gray-900 dark:text-white">Springfield Academy</h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">{currentDate} • {currentTime}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Global Search */}
            <div className="hidden md:flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg px-2.5 py-1.5 w-48">
              <Search className="w-3.5 h-3.5 text-gray-400 dark:text-gray-500" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent border-none outline-none ml-2 w-full text-xs text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-gray-700 dark:text-gray-300 transition-colors"
              title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
            >
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>

            {/* Quick Create */}
            <div className="relative">
              <button
                onClick={() => setShowQuickCreate(!showQuickCreate)}
                className="px-2.5 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-1.5 shadow-md text-xs"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden md:inline">Quick Create</span>
              </button>
              {showQuickCreate && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setShowQuickCreate(false)}
                  />
                  <div className="absolute right-0 mt-2 w-52 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 z-20 max-h-96 overflow-y-auto">
                    {/* Checklist */}
                    <button
                      onClick={() => {
                        onQuickAction('checklist');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs border-b border-gray-200 dark:border-gray-700"
                    >
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      Open Checklist
                    </button>

                    {/* Students Section */}
                    <div className="px-2 py-1.5 bg-gray-50 dark:bg-gray-700/50">
                      <p className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Students</p>
                    </div>
                    <button
                      onClick={() => {
                        onQuickAction('add-student');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <Users className="w-3.5 h-3.5" />
                      Add Student
                    </button>
                    <button
                      onClick={() => {
                        onSectionChange('admissions');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      New Admission
                    </button>
                    <button
                      onClick={() => {
                        onSectionChange('certificates');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <Award className="w-3.5 h-3.5" />
                      Issue Certificate
                    </button>

                    {/* Academic Section */}
                    <div className="px-2 py-1.5 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700">
                      <p className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Academic</p>
                    </div>
                    <button
                      onClick={() => {
                        onQuickAction('mark-attendance');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      Mark Attendance
                    </button>
                    <button
                      onClick={() => {
                        onQuickAction('create-exam');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Create Exam
                    </button>
                    <button
                      onClick={() => {
                        onSectionChange('routine');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      Manage Routine
                    </button>

                    {/* Finance Section */}
                    <div className="px-2 py-1.5 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700">
                      <p className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Finance</p>
                    </div>
                    <button
                      onClick={() => {
                        onQuickAction('collect-fee');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <DollarSign className="w-3.5 h-3.5" />
                      Collect Fee
                    </button>

                    {/* Staff & Communication */}
                    <div className="px-2 py-1.5 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700">
                      <p className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Staff & Communication</p>
                    </div>
                    <button
                      onClick={() => {
                        onSectionChange('teachers');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <GraduationCap className="w-3.5 h-3.5" />
                      Add Teacher/Staff
                    </button>
                    <button
                      onClick={() => {
                        onSectionChange('communication');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      Send Notice
                    </button>

                    {/* Facilities */}
                    <div className="px-2 py-1.5 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700">
                      <p className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Facilities</p>
                    </div>
                    <button
                      onClick={() => {
                        onSectionChange('library');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      Manage Library
                    </button>
                    <button
                      onClick={() => {
                        onSectionChange('transport');
                        setShowQuickCreate(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <Bus className="w-3.5 h-3.5" />
                      Manage Transport
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg relative text-gray-700 dark:text-gray-300"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center font-semibold">
                    {unreadCount}
                  </span>
                )}
              </button>
              {showNotifications && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setShowNotifications(false)}
                  />
                  <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 z-20">
                    <div className="p-3 border-b border-gray-200 dark:border-gray-700">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Notifications</h3>
                    </div>
                    <div className="max-h-80 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="p-8 text-center text-xs text-gray-500 dark:text-gray-400">
                          No notifications
                        </div>
                      ) : (
                        notifications.map((notif) => (
                          <div
                            key={notif.id}
                            onClick={() => handleNotificationClick(notif.screen)}
                            className={`p-3 border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors ${
                              notif.unread ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <p className="text-xs text-gray-900 dark:text-white flex-1">{notif.message}</p>
                              <button
                                onClick={(e) => handleDeleteNotification(notif.id, e)}
                                className="text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                                title="Delete notification"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Profile */}
            <div className="relative ml-1">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg px-1.5 py-1 transition-colors"
              >
                <div className="w-7 h-7 bg-gradient-to-br from-blue-600 to-purple-600 text-white rounded-full flex items-center justify-center text-xs font-semibold shadow-md">
                  A
                </div>
                <span className="hidden lg:inline text-xs font-medium text-gray-900 dark:text-white">Admin</span>
              </button>
              {showProfileMenu && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setShowProfileMenu(false)}
                  />
                  <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 z-20">
                    <button
                      onClick={() => {
                        onProfileAction?.('profile');
                        setShowProfileMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <User className="w-3.5 h-3.5" />
                      Profile
                    </button>
                    <button
                      onClick={() => {
                        onProfileAction?.('settings');
                        setShowProfileMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-700 dark:text-gray-300 transition-colors text-xs"
                    >
                      <Settings className="w-3.5 h-3.5" />
                      Settings
                    </button>
                    <button
                      onClick={() => {
                        onProfileAction?.('logout');
                        setShowProfileMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 text-red-600 dark:text-red-400 transition-colors border-t border-gray-200 dark:border-gray-700 text-xs"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Logout
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside
          className={`${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-40 w-56 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-transform duration-300 flex flex-col mt-[53px] lg:mt-0 shadow-lg lg:shadow-none`}
        >
          <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSectionChange(item.id);
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all text-sm ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium shadow-md'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900">
          <div className="p-4">
            {activeSection !== 'dashboard' && (
              <button
                onClick={() => onSectionChange('dashboard')}
                className="mb-4 flex items-center gap-2 px-3 py-1.5 text-sm text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-800 rounded-lg transition-colors border border-gray-200 dark:border-gray-700"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Dashboard
              </button>
            )}
            {children}
          </div>
        </main>
      </div>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30 mt-[53px] backdrop-blur-sm"
        />
      )}
    </div>
  );
}
