import { createContext, useContext, useState, ReactNode } from 'react';

export interface Student {
  id: string;
  name: string;
  class: string;
  section: string;
  roll: string;
  status: 'Active' | 'Inactive';
  dob: string;
  gender: string;
  address: string;
  phone: string;
  guardianName: string;
  guardianPhone: string;
  guardianEmail: string;
  admissionDate: string;
  photo?: string;
}

export interface FeeRecord {
  id: string;
  studentId: string;
  studentName: string;
  class: string;
  totalFee: number;
  paid: number;
  due: number;
  status: 'Paid' | 'Partial' | 'Pending';
  transactions: Transaction[];
}

export interface Transaction {
  id: string;
  amount: number;
  method: string;
  date: string;
  receiptNo: string;
}

export interface AttendanceRecord {
  date: string;
  class: string;
  section: string;
  records: { studentId: string; status: 'P' | 'A' | 'L' }[];
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  department: string;
  phone: string;
  email: string;
  status: 'Active' | 'Inactive';
}

export interface Exam {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  classes: string[];
  subjects: string[];
  status: 'Draft' | 'Published' | 'Completed';
}

interface DataContextType {
  students: Student[];
  addStudent: (student: Student) => void;
  updateStudent: (id: string, student: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  feeRecords: FeeRecord[];
  addPayment: (studentId: string, amount: number, method: string) => void;
  attendanceRecords: AttendanceRecord[];
  saveAttendance: (record: AttendanceRecord) => void;
  teachers: Teacher[];
  addTeacher: (teacher: Teacher) => void;
  exams: Exam[];
  addExam: (exam: Exam) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const initialStudents: Student[] = [
  {
    id: 'STD001',
    name: 'Aarav Kumar',
    class: '10',
    section: 'A',
    roll: '15',
    status: 'Active',
    dob: '2010-05-15',
    gender: 'Male',
    address: '123 Main Street, Springfield',
    phone: '+91 9876543210',
    guardianName: 'Rajesh Kumar',
    guardianPhone: '+91 9876543211',
    guardianEmail: 'rajesh@email.com',
    admissionDate: '2024-04-01',
  },
  {
    id: 'STD002',
    name: 'Diya Sharma',
    class: '10',
    section: 'B',
    roll: '08',
    status: 'Active',
    dob: '2010-08-22',
    gender: 'Female',
    address: '456 Park Avenue, Springfield',
    phone: '+91 9876543220',
    guardianName: 'Amit Sharma',
    guardianPhone: '+91 9876543221',
    guardianEmail: 'amit@email.com',
    admissionDate: '2024-04-01',
  },
  {
    id: 'STD003',
    name: 'Arjun Patel',
    class: '9',
    section: 'A',
    roll: '22',
    status: 'Active',
    dob: '2011-03-10',
    gender: 'Male',
    address: '789 Oak Road, Springfield',
    phone: '+91 9876543230',
    guardianName: 'Vijay Patel',
    guardianPhone: '+91 9876543231',
    guardianEmail: 'vijay@email.com',
    admissionDate: '2024-04-01',
  },
  {
    id: 'STD004',
    name: 'Priya Singh',
    class: '9',
    section: 'B',
    roll: '12',
    status: 'Active',
    dob: '2011-11-30',
    gender: 'Female',
    address: '321 Elm Street, Springfield',
    phone: '+91 9876543240',
    guardianName: 'Suresh Singh',
    guardianPhone: '+91 9876543241',
    guardianEmail: 'suresh@email.com',
    admissionDate: '2024-04-01',
  },
  {
    id: 'STD005',
    name: 'Rohan Gupta',
    class: '8',
    section: 'A',
    roll: '05',
    status: 'Active',
    dob: '2012-07-18',
    gender: 'Male',
    address: '654 Maple Drive, Springfield',
    phone: '+91 9876543250',
    guardianName: 'Anil Gupta',
    guardianPhone: '+91 9876543251',
    guardianEmail: 'anil@email.com',
    admissionDate: '2024-04-01',
  },
  {
    id: 'STD006',
    name: 'Ananya Desai',
    class: '8',
    section: 'B',
    roll: '18',
    status: 'Inactive',
    dob: '2012-01-25',
    gender: 'Female',
    address: '987 Pine Lane, Springfield',
    phone: '+91 9876543260',
    guardianName: 'Kiran Desai',
    guardianPhone: '+91 9876543261',
    guardianEmail: 'kiran@email.com',
    admissionDate: '2024-04-01',
  },
];

const initialFeeRecords: FeeRecord[] = [
  {
    id: 'INV001',
    studentId: 'STD001',
    studentName: 'Aarav Kumar',
    class: '10-A',
    totalFee: 25000,
    paid: 15000,
    due: 10000,
    status: 'Partial',
    transactions: [
      {
        id: 'TXN001',
        amount: 15000,
        method: 'Cash',
        date: '2026-03-15',
        receiptNo: 'REC001',
      },
    ],
  },
  {
    id: 'INV002',
    studentId: 'STD002',
    studentName: 'Diya Sharma',
    class: '10-B',
    totalFee: 25000,
    paid: 25000,
    due: 0,
    status: 'Paid',
    transactions: [
      {
        id: 'TXN002',
        amount: 25000,
        method: 'Bank',
        date: '2026-04-01',
        receiptNo: 'REC002',
      },
    ],
  },
  {
    id: 'INV003',
    studentId: 'STD003',
    studentName: 'Arjun Patel',
    class: '9-A',
    totalFee: 22000,
    paid: 0,
    due: 22000,
    status: 'Pending',
    transactions: [],
  },
];

const initialTeachers: Teacher[] = [
  {
    id: 'TCH001',
    name: 'Dr. Meera Reddy',
    subject: 'Mathematics',
    department: 'Science',
    phone: '+91 9876501234',
    email: 'meera@school.com',
    status: 'Active',
  },
  {
    id: 'TCH002',
    name: 'Prof. Arun Nair',
    subject: 'Physics',
    department: 'Science',
    phone: '+91 9876501235',
    email: 'arun@school.com',
    status: 'Active',
  },
];

export function DataProvider({ children }: { children: ReactNode }) {
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [feeRecords, setFeeRecords] = useState<FeeRecord[]>(initialFeeRecords);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>(initialTeachers);
  const [exams, setExams] = useState<Exam[]>([]);

  const addStudent = (student: Student) => {
    setStudents((prev) => [...prev, student]);

    const newFeeRecord: FeeRecord = {
      id: `INV${String(feeRecords.length + 1).padStart(3, '0')}`,
      studentId: student.id,
      studentName: student.name,
      class: `${student.class}-${student.section}`,
      totalFee: parseInt(student.class) >= 10 ? 25000 : 22000,
      paid: 0,
      due: parseInt(student.class) >= 10 ? 25000 : 22000,
      status: 'Pending',
      transactions: [],
    };
    setFeeRecords((prev) => [...prev, newFeeRecord]);
  };

  const updateStudent = (id: string, updates: Partial<Student>) => {
    setStudents((prev) =>
      prev.map((student) => (student.id === id ? { ...student, ...updates } : student))
    );
  };

  const deleteStudent = (id: string) => {
    setStudents((prev) => prev.filter((student) => student.id !== id));
  };

  const addPayment = (studentId: string, amount: number, method: string) => {
    setFeeRecords((prev) =>
      prev.map((record) => {
        if (record.studentId === studentId) {
          const newPaid = record.paid + amount;
          const newDue = record.totalFee - newPaid;
          const newTransaction: Transaction = {
            id: `TXN${Date.now()}`,
            amount,
            method,
            date: new Date().toISOString().split('T')[0],
            receiptNo: `REC${Date.now()}`,
          };
          return {
            ...record,
            paid: newPaid,
            due: newDue,
            status: newDue === 0 ? 'Paid' : 'Partial',
            transactions: [...record.transactions, newTransaction],
          };
        }
        return record;
      })
    );
  };

  const saveAttendance = (record: AttendanceRecord) => {
    setAttendanceRecords((prev) => {
      const existing = prev.findIndex(
        (r) => r.date === record.date && r.class === record.class && r.section === record.section
      );
      if (existing >= 0) {
        const updated = [...prev];
        updated[existing] = record;
        return updated;
      }
      return [...prev, record];
    });
  };

  const addTeacher = (teacher: Teacher) => {
    setTeachers((prev) => [...prev, teacher]);
  };

  const addExam = (exam: Exam) => {
    setExams((prev) => [...prev, exam]);
  };

  return (
    <DataContext.Provider
      value={{
        students,
        addStudent,
        updateStudent,
        deleteStudent,
        feeRecords,
        addPayment,
        attendanceRecords,
        saveAttendance,
        teachers,
        addTeacher,
        exams,
        addExam,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within DataProvider');
  }
  return context;
}
